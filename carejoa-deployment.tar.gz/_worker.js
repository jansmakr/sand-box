var zr=Object.defineProperty;var At=e=>{throw TypeError(e)};var Vr=(e,r,i)=>r in e?zr(e,r,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[r]=i;var x=(e,r,i)=>Vr(e,typeof r!="symbol"?r+"":r,i),nt=(e,r,i)=>r.has(e)||At("Cannot "+i);var f=(e,r,i)=>(nt(e,r,"read from private field"),i?i.call(e):r.get(e)),w=(e,r,i)=>r.has(e)?At("Cannot add the same private member more than once"):r instanceof WeakSet?r.add(e):r.set(e,i),v=(e,r,i,s)=>(nt(e,r,"write to private field"),s?s.call(e,i):r.set(e,i),i),L=(e,r,i)=>(nt(e,r,"access private method"),i);var Nt=(e,r,i,s)=>({set _(a){v(e,r,a,i)},get _(){return f(e,r,s)}});var nr={Stringify:1},D=(e,r)=>{const i=new String(e);return i.isEscaped=!0,i.callbacks=r,i},Yr=/[&<>'"]/,lr=async(e,r)=>{let i="";r||(r=[]);const s=await Promise.all(e);for(let a=s.length-1;i+=s[a],a--,!(a<0);a--){let n=s[a];typeof n=="object"&&r.push(...n.callbacks||[]);const o=n.isEscaped;if(n=await(typeof n=="object"?n.toString():n),typeof n=="object"&&r.push(...n.callbacks||[]),n.isEscaped??o)i+=n;else{const c=[i];re(n,c),i=c[0]}}return D(i,r)},re=(e,r)=>{const i=e.search(Yr);if(i===-1){r[0]+=e;return}let s,a,n=0;for(a=i;a<e.length;a++){switch(e.charCodeAt(a)){case 34:s="&quot;";break;case 39:s="&#39;";break;case 38:s="&amp;";break;case 60:s="&lt;";break;case 62:s="&gt;";break;default:continue}r[0]+=e.substring(n,a)+s,n=a+1}r[0]+=e.substring(n,a)},or=e=>{const r=e.callbacks;if(!(r!=null&&r.length))return e;const i=[e],s={};return r.forEach(a=>a({phase:nr.Stringify,buffer:i,context:s})),i[0]},cr=async(e,r,i,s,a)=>{typeof e=="object"&&!(e instanceof String)&&(e instanceof Promise||(e=e.toString()),e instanceof Promise&&(e=await e));const n=e.callbacks;return n!=null&&n.length?(a?a[0]+=e:a=[e],Promise.all(n.map(c=>c({phase:r,buffer:a,context:s}))).then(c=>Promise.all(c.filter(Boolean).map(l=>cr(l,r,!1,s,a))).then(()=>a[0]))):Promise.resolve(e)},Gr=(e,...r)=>{const i=[""];for(let s=0,a=e.length-1;s<a;s++){i[0]+=e[s];const n=Array.isArray(r[s])?r[s].flat(1/0):[r[s]];for(let o=0,c=n.length;o<c;o++){const l=n[o];if(typeof l=="string")re(l,i);else if(typeof l=="number")i[0]+=l;else{if(typeof l=="boolean"||l===null||l===void 0)continue;if(typeof l=="object"&&l.isEscaped)if(l.callbacks)i.unshift("",l);else{const d=l.toString();d instanceof Promise?i.unshift("",d):i[0]+=d}else l instanceof Promise?i.unshift("",l):re(l.toString(),i)}}}return i[0]+=e.at(-1),i.length===1?"callbacks"in i?D(or(D(i[0],i.callbacks))):D(i[0]):lr(i,i.callbacks)},St=Symbol("RENDERER"),xt=Symbol("ERROR_HANDLER"),k=Symbol("STASH"),dr=Symbol("INTERNAL"),Zr=Symbol("MEMO"),Qe=Symbol("PERMALINK"),jt=e=>(e[dr]=!0,e),ur=e=>({value:r,children:i})=>{if(!i)return;const s={children:[{tag:jt(()=>{e.push(r)}),props:{}}]};Array.isArray(i)?s.children.push(...i.flat()):s.children.push(i),s.children.push({tag:jt(()=>{e.pop()}),props:{}});const a={tag:"",props:s,type:""};return a[xt]=n=>{throw e.pop(),n},a},fr=e=>{const r=[e],i=ur(r);return i.values=r,i.Provider=i,we.push(i),i},we=[],_t=e=>{const r=[e],i=s=>{r.push(s.value);let a;try{a=s.children?(Array.isArray(s.children)?new mr("",{},s.children):s.children).toString():""}finally{r.pop()}return a instanceof Promise?a.then(n=>D(n,n.callbacks)):D(a)};return i.values=r,i.Provider=i,i[St]=ur(r),we.push(i),i},_e=e=>e.values.at(-1),Ke={title:[],script:["src"],style:["data-href"],link:["href"],meta:["name","httpEquiv","charset","itemProp"]},bt={},We="data-precedence",Fe=e=>Array.isArray(e)?e:[e],Ot=new WeakMap,Mt=(e,r,i,s)=>({buffer:a,context:n})=>{if(!a)return;const o=Ot.get(n)||{};Ot.set(n,o);const c=o[e]||(o[e]=[]);let l=!1;const d=Ke[e];if(d.length>0){e:for(const[,u]of c)for(const g of d)if(((u==null?void 0:u[g])??null)===(i==null?void 0:i[g])){l=!0;break e}}if(l?a[0]=a[0].replaceAll(r,""):d.length>0?c.push([r,i,s]):c.unshift([r,i,s]),a[0].indexOf("</head>")!==-1){let u;if(s===void 0)u=c.map(([g])=>g);else{const g=[];u=c.map(([p,,m])=>{let y=g.indexOf(m);return y===-1&&(g.push(m),y=g.length-1),[p,y]}).sort((p,m)=>p[1]-m[1]).map(([p])=>p)}u.forEach(g=>{a[0]=a[0].replaceAll(g,"")}),a[0]=a[0].replace(/(?=<\/head>)/,u.join(""))}},Pe=(e,r,i)=>D(new U(e,i,Fe(r??[])).toString()),Ue=(e,r,i,s)=>{if("itemProp"in i)return Pe(e,r,i);let{precedence:a,blocking:n,...o}=i;a=s?a??"":void 0,s&&(o[We]=a);const c=new U(e,o,Fe(r||[])).toString();return c instanceof Promise?c.then(l=>D(c,[...l.callbacks||[],Mt(e,l,o,a)])):D(c,[Mt(e,c,o,a)])},Jr=({children:e,...r})=>{const i=Lt();if(i){const s=_e(i);if(s==="svg"||s==="head")return new U("title",r,Fe(e??[]))}return Ue("title",e,r,!1)},Qr=({children:e,...r})=>{const i=Lt();return["src","async"].some(s=>!r[s])||i&&_e(i)==="head"?Pe("script",e,r):Ue("script",e,r,!1)},ei=({children:e,...r})=>["href","precedence"].every(i=>i in r)?(r["data-href"]=r.href,delete r.href,Ue("style",e,r,!0)):Pe("style",e,r),ti=({children:e,...r})=>["onLoad","onError"].some(i=>i in r)||r.rel==="stylesheet"&&(!("precedence"in r)||"disabled"in r)?Pe("link",e,r):Ue("link",e,r,"precedence"in r),ri=({children:e,...r})=>{const i=Lt();return i&&_e(i)==="head"?Pe("meta",e,r):Ue("meta",e,r,!1)},gr=(e,{children:r,...i})=>new U(e,i,Fe(r??[])),ii=e=>(typeof e.action=="function"&&(e.action=Qe in e.action?e.action[Qe]:void 0),gr("form",e)),pr=(e,r)=>(typeof r.formAction=="function"&&(r.formAction=Qe in r.formAction?r.formAction[Qe]:void 0),gr(e,r)),si=e=>pr("input",e),ai=e=>pr("button",e);const lt=Object.freeze(Object.defineProperty({__proto__:null,button:ai,form:ii,input:si,link:ti,meta:ri,script:Qr,style:ei,title:Jr},Symbol.toStringTag,{value:"Module"}));var ni=new Map([["className","class"],["htmlFor","for"],["crossOrigin","crossorigin"],["httpEquiv","http-equiv"],["itemProp","itemprop"],["fetchPriority","fetchpriority"],["noModule","nomodule"],["formAction","formaction"]]),et=e=>ni.get(e)||e,hr=(e,r)=>{for(const[i,s]of Object.entries(e)){const a=i[0]==="-"||!/[A-Z]/.test(i)?i:i.replace(/[A-Z]/g,n=>`-${n.toLowerCase()}`);r(a,s==null?null:typeof s=="number"?a.match(/^(?:a|border-im|column(?:-c|s)|flex(?:$|-[^b])|grid-(?:ar|[^a])|font-w|li|or|sca|st|ta|wido|z)|ty$/)?`${s}`:`${s}px`:s)}},Re=void 0,Lt=()=>Re,li=e=>/[A-Z]/.test(e)&&e.match(/^(?:al|basel|clip(?:Path|Rule)$|co|do|fill|fl|fo|gl|let|lig|i|marker[EMS]|o|pai|pointe|sh|st[or]|text[^L]|tr|u|ve|w)/)?e.replace(/([A-Z])/g,"-$1").toLowerCase():e,oi=["area","base","br","col","embed","hr","img","input","keygen","link","meta","param","source","track","wbr"],ci=["allowfullscreen","async","autofocus","autoplay","checked","controls","default","defer","disabled","download","formnovalidate","hidden","inert","ismap","itemscope","loop","multiple","muted","nomodule","novalidate","open","playsinline","readonly","required","reversed","selected"],It=(e,r)=>{for(let i=0,s=e.length;i<s;i++){const a=e[i];if(typeof a=="string")re(a,r);else{if(typeof a=="boolean"||a===null||a===void 0)continue;a instanceof U?a.toStringToBuffer(r):typeof a=="number"||a.isEscaped?r[0]+=a:a instanceof Promise?r.unshift("",a):It(a,r)}}},U=class{constructor(e,r,i){x(this,"tag");x(this,"props");x(this,"key");x(this,"children");x(this,"isEscaped",!0);x(this,"localContexts");this.tag=e,this.props=r,this.children=i}get type(){return this.tag}get ref(){return this.props.ref||null}toString(){var r,i;const e=[""];(r=this.localContexts)==null||r.forEach(([s,a])=>{s.values.push(a)});try{this.toStringToBuffer(e)}finally{(i=this.localContexts)==null||i.forEach(([s])=>{s.values.pop()})}return e.length===1?"callbacks"in e?or(D(e[0],e.callbacks)).toString():e[0]:lr(e,e.callbacks)}toStringToBuffer(e){const r=this.tag,i=this.props;let{children:s}=this;e[0]+=`<${r}`;const a=Re&&_e(Re)==="svg"?n=>li(et(n)):n=>et(n);for(let[n,o]of Object.entries(i))if(n=a(n),n!=="children"){if(n==="style"&&typeof o=="object"){let c="";hr(o,(l,d)=>{d!=null&&(c+=`${c?";":""}${l}:${d}`)}),e[0]+=' style="',re(c,e),e[0]+='"'}else if(typeof o=="string")e[0]+=` ${n}="`,re(o,e),e[0]+='"';else if(o!=null)if(typeof o=="number"||o.isEscaped)e[0]+=` ${n}="${o}"`;else if(typeof o=="boolean"&&ci.includes(n))o&&(e[0]+=` ${n}=""`);else if(n==="dangerouslySetInnerHTML"){if(s.length>0)throw new Error("Can only set one of `children` or `props.dangerouslySetInnerHTML`.");s=[D(o.__html)]}else if(o instanceof Promise)e[0]+=` ${n}="`,e.unshift('"',o);else if(typeof o=="function"){if(!n.startsWith("on")&&n!=="ref")throw new Error(`Invalid prop '${n}' of type 'function' supplied to '${r}'.`)}else e[0]+=` ${n}="`,re(o.toString(),e),e[0]+='"'}if(oi.includes(r)&&s.length===0){e[0]+="/>";return}e[0]+=">",It(s,e),e[0]+=`</${r}>`}},ot=class extends U{toStringToBuffer(e){const{children:r}=this,i=this.tag.call(null,{...this.props,children:r.length<=1?r[0]:r});if(!(typeof i=="boolean"||i==null))if(i instanceof Promise)if(we.length===0)e.unshift("",i);else{const s=we.map(a=>[a,a.values.at(-1)]);e.unshift("",i.then(a=>(a instanceof U&&(a.localContexts=s),a)))}else i instanceof U?i.toStringToBuffer(e):typeof i=="number"||i.isEscaped?(e[0]+=i,i.callbacks&&(e.callbacks||(e.callbacks=[]),e.callbacks.push(...i.callbacks))):re(i,e)}},mr=class extends U{toStringToBuffer(e){It(this.children,e)}},Bt=(e,r,...i)=>{r??(r={}),i.length&&(r.children=i.length===1?i[0]:i);const s=r.key;delete r.key;const a=ze(e,r,i);return a.key=s,a},Dt=!1,ze=(e,r,i)=>{if(!Dt){for(const s in bt)lt[s][St]=bt[s];Dt=!0}return typeof e=="function"?new ot(e,r,i):lt[e]?new ot(lt[e],r,i):e==="svg"||e==="head"?(Re||(Re=_t("")),new U(e,r,[new ot(Re,{value:e},i)])):new U(e,r,i)},di=({children:e})=>new mr("",{children:e},Array.isArray(e)?e:e?[e]:[]);function t(e,r,i){let s;if(!r||!("children"in r))s=ze(e,r,[]);else{const a=r.children;s=Array.isArray(a)?ze(e,r,a):ze(e,r,[a])}return s.key=i,s}var $t=(e,r,i)=>(s,a)=>{let n=-1;return o(0);async function o(c){if(c<=n)throw new Error("next() called multiple times");n=c;let l,d=!1,u;if(e[c]?(u=e[c][0][0],s.req.routeIndex=c):u=c===e.length&&a||void 0,u)try{l=await u(s,()=>o(c+1))}catch(g){if(g instanceof Error&&r)s.error=g,l=await r(g,s),d=!0;else throw g}else s.finalized===!1&&i&&(l=await i(s));return l&&(s.finalized===!1||d)&&(s.res=l),s}},ui=Symbol(),fi=async(e,r=Object.create(null))=>{const{all:i=!1,dot:s=!1}=r,n=(e instanceof Er?e.raw.headers:e.headers).get("Content-Type");return n!=null&&n.startsWith("multipart/form-data")||n!=null&&n.startsWith("application/x-www-form-urlencoded")?gi(e,{all:i,dot:s}):{}};async function gi(e,r){const i=await e.formData();return i?pi(i,r):{}}function pi(e,r){const i=Object.create(null);return e.forEach((s,a)=>{r.all||a.endsWith("[]")?hi(i,a,s):i[a]=s}),r.dot&&Object.entries(i).forEach(([s,a])=>{s.includes(".")&&(mi(i,s,a),delete i[s])}),i}var hi=(e,r,i)=>{e[r]!==void 0?Array.isArray(e[r])?e[r].push(i):e[r]=[e[r],i]:r.endsWith("[]")?e[r]=[i]:e[r]=i},mi=(e,r,i)=>{let s=e;const a=r.split(".");a.forEach((n,o)=>{o===a.length-1?s[n]=i:((!s[n]||typeof s[n]!="object"||Array.isArray(s[n])||s[n]instanceof File)&&(s[n]=Object.create(null)),s=s[n])})},yr=e=>{const r=e.split("/");return r[0]===""&&r.shift(),r},yi=e=>{const{groups:r,path:i}=xi(e),s=yr(i);return bi(s,r)},xi=e=>{const r=[];return e=e.replace(/\{[^}]+\}/g,(i,s)=>{const a=`@${s}`;return r.push([a,i]),a}),{groups:r,path:e}},bi=(e,r)=>{for(let i=r.length-1;i>=0;i--){const[s]=r[i];for(let a=e.length-1;a>=0;a--)if(e[a].includes(s)){e[a]=e[a].replace(s,r[i][1]);break}}return e},He={},vi=(e,r)=>{if(e==="*")return"*";const i=e.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);if(i){const s=`${e}#${r}`;return He[s]||(i[2]?He[s]=r&&r[0]!==":"&&r[0]!=="*"?[s,i[1],new RegExp(`^${i[2]}(?=/${r})`)]:[e,i[1],new RegExp(`^${i[2]}$`)]:He[s]=[e,i[1],!0]),He[s]}return null},st=(e,r)=>{try{return r(e)}catch{return e.replace(/(?:%[0-9A-Fa-f]{2})+/g,i=>{try{return r(i)}catch{return i}})}},Ei=e=>st(e,decodeURI),xr=e=>{const r=e.url,i=r.indexOf("/",r.indexOf(":")+4);let s=i;for(;s<r.length;s++){const a=r.charCodeAt(s);if(a===37){const n=r.indexOf("?",s),o=r.slice(i,n===-1?void 0:n);return Ei(o.includes("%25")?o.replace(/%25/g,"%2525"):o)}else if(a===63)break}return r.slice(i,s)},wi=e=>{const r=xr(e);return r.length>1&&r.at(-1)==="/"?r.slice(0,-1):r},pe=(e,r,...i)=>(i.length&&(r=pe(r,...i)),`${(e==null?void 0:e[0])==="/"?"":"/"}${e}${r==="/"?"":`${(e==null?void 0:e.at(-1))==="/"?"":"/"}${(r==null?void 0:r[0])==="/"?r.slice(1):r}`}`),br=e=>{if(e.charCodeAt(e.length-1)!==63||!e.includes(":"))return null;const r=e.split("/"),i=[];let s="";return r.forEach(a=>{if(a!==""&&!/\:/.test(a))s+="/"+a;else if(/\:/.test(a))if(/\?/.test(a)){i.length===0&&s===""?i.push("/"):i.push(s);const n=a.replace("?","");s+="/"+n,i.push(s)}else s+="/"+a}),i.filter((a,n,o)=>o.indexOf(a)===n)},ct=e=>/[%+]/.test(e)?(e.indexOf("+")!==-1&&(e=e.replace(/\+/g," ")),e.indexOf("%")!==-1?st(e,kt):e):e,vr=(e,r,i)=>{let s;if(!i&&r&&!/[%+]/.test(r)){let o=e.indexOf(`?${r}`,8);for(o===-1&&(o=e.indexOf(`&${r}`,8));o!==-1;){const c=e.charCodeAt(o+r.length+1);if(c===61){const l=o+r.length+2,d=e.indexOf("&",l);return ct(e.slice(l,d===-1?void 0:d))}else if(c==38||isNaN(c))return"";o=e.indexOf(`&${r}`,o+1)}if(s=/[%+]/.test(e),!s)return}const a={};s??(s=/[%+]/.test(e));let n=e.indexOf("?",8);for(;n!==-1;){const o=e.indexOf("&",n+1);let c=e.indexOf("=",n);c>o&&o!==-1&&(c=-1);let l=e.slice(n+1,c===-1?o===-1?void 0:o:c);if(s&&(l=ct(l)),n=o,l==="")continue;let d;c===-1?d="":(d=e.slice(c+1,o===-1?void 0:o),s&&(d=ct(d))),i?(a[l]&&Array.isArray(a[l])||(a[l]=[]),a[l].push(d)):a[l]??(a[l]=d)}return r?a[r]:a},Ti=vr,Si=(e,r)=>vr(e,r,!0),kt=decodeURIComponent,Ft=e=>st(e,kt),ye,B,V,wr,Tr,vt,G,Zt,Er=(Zt=class{constructor(e,r="/",i=[[]]){w(this,V);x(this,"raw");w(this,ye);w(this,B);x(this,"routeIndex",0);x(this,"path");x(this,"bodyCache",{});w(this,G,e=>{const{bodyCache:r,raw:i}=this,s=r[e];if(s)return s;const a=Object.keys(r)[0];return a?r[a].then(n=>(a==="json"&&(n=JSON.stringify(n)),new Response(n)[e]())):r[e]=i[e]()});this.raw=e,this.path=r,v(this,B,i),v(this,ye,{})}param(e){return e?L(this,V,wr).call(this,e):L(this,V,Tr).call(this)}query(e){return Ti(this.url,e)}queries(e){return Si(this.url,e)}header(e){if(e)return this.raw.headers.get(e)??void 0;const r={};return this.raw.headers.forEach((i,s)=>{r[s]=i}),r}async parseBody(e){var r;return(r=this.bodyCache).parsedBody??(r.parsedBody=await fi(this,e))}json(){return f(this,G).call(this,"text").then(e=>JSON.parse(e))}text(){return f(this,G).call(this,"text")}arrayBuffer(){return f(this,G).call(this,"arrayBuffer")}blob(){return f(this,G).call(this,"blob")}formData(){return f(this,G).call(this,"formData")}addValidatedData(e,r){f(this,ye)[e]=r}valid(e){return f(this,ye)[e]}get url(){return this.raw.url}get method(){return this.raw.method}get[ui](){return f(this,B)}get matchedRoutes(){return f(this,B)[0].map(([[,e]])=>e)}get routePath(){return f(this,B)[0].map(([[,e]])=>e)[this.routeIndex].path}},ye=new WeakMap,B=new WeakMap,V=new WeakSet,wr=function(e){const r=f(this,B)[0][this.routeIndex][1][e],i=L(this,V,vt).call(this,r);return i&&/\%/.test(i)?Ft(i):i},Tr=function(){const e={},r=Object.keys(f(this,B)[0][this.routeIndex][1]);for(const i of r){const s=L(this,V,vt).call(this,f(this,B)[0][this.routeIndex][1][i]);s!==void 0&&(e[i]=/\%/.test(s)?Ft(s):s)}return e},vt=function(e){return f(this,B)[1]?f(this,B)[1][e]:e},G=new WeakMap,Zt),_i="text/plain; charset=UTF-8",dt=(e,r)=>({"Content-Type":e,...r}),je,Oe,X,xe,K,O,Me,be,ve,ne,Be,De,Z,he,Jt,Li=(Jt=class{constructor(e,r){w(this,Z);w(this,je);w(this,Oe);x(this,"env",{});w(this,X);x(this,"finalized",!1);x(this,"error");w(this,xe);w(this,K);w(this,O);w(this,Me);w(this,be);w(this,ve);w(this,ne);w(this,Be);w(this,De);x(this,"render",(...e)=>(f(this,be)??v(this,be,r=>this.html(r)),f(this,be).call(this,...e)));x(this,"setLayout",e=>v(this,Me,e));x(this,"getLayout",()=>f(this,Me));x(this,"setRenderer",e=>{v(this,be,e)});x(this,"header",(e,r,i)=>{this.finalized&&v(this,O,new Response(f(this,O).body,f(this,O)));const s=f(this,O)?f(this,O).headers:f(this,ne)??v(this,ne,new Headers);r===void 0?s.delete(e):i!=null&&i.append?s.append(e,r):s.set(e,r)});x(this,"status",e=>{v(this,xe,e)});x(this,"set",(e,r)=>{f(this,X)??v(this,X,new Map),f(this,X).set(e,r)});x(this,"get",e=>f(this,X)?f(this,X).get(e):void 0);x(this,"newResponse",(...e)=>L(this,Z,he).call(this,...e));x(this,"body",(e,r,i)=>L(this,Z,he).call(this,e,r,i));x(this,"text",(e,r,i)=>!f(this,ne)&&!f(this,xe)&&!r&&!i&&!this.finalized?new Response(e):L(this,Z,he).call(this,e,r,dt(_i,i)));x(this,"json",(e,r,i)=>L(this,Z,he).call(this,JSON.stringify(e),r,dt("application/json",i)));x(this,"html",(e,r,i)=>{const s=a=>L(this,Z,he).call(this,a,r,dt("text/html; charset=UTF-8",i));return typeof e=="object"?cr(e,nr.Stringify,!1,{}).then(s):s(e)});x(this,"redirect",(e,r)=>{const i=String(e);return this.header("Location",/[^\x00-\xFF]/.test(i)?encodeURI(i):i),this.newResponse(null,r??302)});x(this,"notFound",()=>(f(this,ve)??v(this,ve,()=>new Response),f(this,ve).call(this,this)));v(this,je,e),r&&(v(this,K,r.executionCtx),this.env=r.env,v(this,ve,r.notFoundHandler),v(this,De,r.path),v(this,Be,r.matchResult))}get req(){return f(this,Oe)??v(this,Oe,new Er(f(this,je),f(this,De),f(this,Be))),f(this,Oe)}get event(){if(f(this,K)&&"respondWith"in f(this,K))return f(this,K);throw Error("This context has no FetchEvent")}get executionCtx(){if(f(this,K))return f(this,K);throw Error("This context has no ExecutionContext")}get res(){return f(this,O)||v(this,O,new Response(null,{headers:f(this,ne)??v(this,ne,new Headers)}))}set res(e){if(f(this,O)&&e){e=new Response(e.body,e);for(const[r,i]of f(this,O).headers.entries())if(r!=="content-type")if(r==="set-cookie"){const s=f(this,O).headers.getSetCookie();e.headers.delete("set-cookie");for(const a of s)e.headers.append("set-cookie",a)}else e.headers.set(r,i)}v(this,O,e),this.finalized=!0}get var(){return f(this,X)?Object.fromEntries(f(this,X)):{}}},je=new WeakMap,Oe=new WeakMap,X=new WeakMap,xe=new WeakMap,K=new WeakMap,O=new WeakMap,Me=new WeakMap,be=new WeakMap,ve=new WeakMap,ne=new WeakMap,Be=new WeakMap,De=new WeakMap,Z=new WeakSet,he=function(e,r,i){const s=f(this,O)?new Headers(f(this,O).headers):f(this,ne)??new Headers;if(typeof r=="object"&&"headers"in r){const n=r.headers instanceof Headers?r.headers:new Headers(r.headers);for(const[o,c]of n)o.toLowerCase()==="set-cookie"?s.append(o,c):s.set(o,c)}if(i)for(const[n,o]of Object.entries(i))if(typeof o=="string")s.set(n,o);else{s.delete(n);for(const c of o)s.append(n,c)}const a=typeof r=="number"?r:(r==null?void 0:r.status)??f(this,xe);return new Response(e,{status:a,headers:s})},Jt),C="ALL",Ii="all",ki=["get","post","put","delete","options","patch"],Sr="Can not add a route since the matcher is already built.",_r=class extends Error{},Ci="__COMPOSED_HANDLER",Ri=e=>e.text("404 Not Found",404),Pt=(e,r)=>{if("getResponse"in e){const i=e.getResponse();return r.newResponse(i.body,i)}return console.error(e),r.text("Internal Server Error",500)},$,R,Ir,F,se,Ve,Ye,Qt,Lr=(Qt=class{constructor(r={}){w(this,R);x(this,"get");x(this,"post");x(this,"put");x(this,"delete");x(this,"options");x(this,"patch");x(this,"all");x(this,"on");x(this,"use");x(this,"router");x(this,"getPath");x(this,"_basePath","/");w(this,$,"/");x(this,"routes",[]);w(this,F,Ri);x(this,"errorHandler",Pt);x(this,"onError",r=>(this.errorHandler=r,this));x(this,"notFound",r=>(v(this,F,r),this));x(this,"fetch",(r,...i)=>L(this,R,Ye).call(this,r,i[1],i[0],r.method));x(this,"request",(r,i,s,a)=>r instanceof Request?this.fetch(i?new Request(r,i):r,s,a):(r=r.toString(),this.fetch(new Request(/^https?:\/\//.test(r)?r:`http://localhost${pe("/",r)}`,i),s,a)));x(this,"fire",()=>{addEventListener("fetch",r=>{r.respondWith(L(this,R,Ye).call(this,r.request,r,void 0,r.request.method))})});[...ki,Ii].forEach(n=>{this[n]=(o,...c)=>(typeof o=="string"?v(this,$,o):L(this,R,se).call(this,n,f(this,$),o),c.forEach(l=>{L(this,R,se).call(this,n,f(this,$),l)}),this)}),this.on=(n,o,...c)=>{for(const l of[o].flat()){v(this,$,l);for(const d of[n].flat())c.map(u=>{L(this,R,se).call(this,d.toUpperCase(),f(this,$),u)})}return this},this.use=(n,...o)=>(typeof n=="string"?v(this,$,n):(v(this,$,"*"),o.unshift(n)),o.forEach(c=>{L(this,R,se).call(this,C,f(this,$),c)}),this);const{strict:s,...a}=r;Object.assign(this,a),this.getPath=s??!0?r.getPath??xr:wi}route(r,i){const s=this.basePath(r);return i.routes.map(a=>{var o;let n;i.errorHandler===Pt?n=a.handler:(n=async(c,l)=>(await $t([],i.errorHandler)(c,()=>a.handler(c,l))).res,n[Ci]=a.handler),L(o=s,R,se).call(o,a.method,a.path,n)}),this}basePath(r){const i=L(this,R,Ir).call(this);return i._basePath=pe(this._basePath,r),i}mount(r,i,s){let a,n;s&&(typeof s=="function"?n=s:(n=s.optionHandler,s.replaceRequest===!1?a=l=>l:a=s.replaceRequest));const o=n?l=>{const d=n(l);return Array.isArray(d)?d:[d]}:l=>{let d;try{d=l.executionCtx}catch{}return[l.env,d]};a||(a=(()=>{const l=pe(this._basePath,r),d=l==="/"?0:l.length;return u=>{const g=new URL(u.url);return g.pathname=g.pathname.slice(d)||"/",new Request(g,u)}})());const c=async(l,d)=>{const u=await i(a(l.req.raw),...o(l));if(u)return u;await d()};return L(this,R,se).call(this,C,pe(r,"*"),c),this}},$=new WeakMap,R=new WeakSet,Ir=function(){const r=new Lr({router:this.router,getPath:this.getPath});return r.errorHandler=this.errorHandler,v(r,F,f(this,F)),r.routes=this.routes,r},F=new WeakMap,se=function(r,i,s){r=r.toUpperCase(),i=pe(this._basePath,i);const a={basePath:this._basePath,path:i,method:r,handler:s};this.router.add(r,i,[s,a]),this.routes.push(a)},Ve=function(r,i){if(r instanceof Error)return this.errorHandler(r,i);throw r},Ye=function(r,i,s,a){if(a==="HEAD")return(async()=>new Response(null,await L(this,R,Ye).call(this,r,i,s,"GET")))();const n=this.getPath(r,{env:s}),o=this.router.match(a,n),c=new Li(r,{path:n,matchResult:o,env:s,executionCtx:i,notFoundHandler:f(this,F)});if(o[0].length===1){let d;try{d=o[0][0][0][0](c,async()=>{c.res=await f(this,F).call(this,c)})}catch(u){return L(this,R,Ve).call(this,u,c)}return d instanceof Promise?d.then(u=>u||(c.finalized?c.res:f(this,F).call(this,c))).catch(u=>L(this,R,Ve).call(this,u,c)):d??f(this,F).call(this,c)}const l=$t(o[0],this.errorHandler,f(this,F));return(async()=>{try{const d=await l(c);if(!d.finalized)throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");return d.res}catch(d){return L(this,R,Ve).call(this,d,c)}})()},Qt),tt="[^/]+",ke=".*",Ce="(?:|/.*)",me=Symbol(),Ai=new Set(".\\+*[^]$()");function Ni(e,r){return e.length===1?r.length===1?e<r?-1:1:-1:r.length===1||e===ke||e===Ce?1:r===ke||r===Ce?-1:e===tt?1:r===tt?-1:e.length===r.length?e<r?-1:1:r.length-e.length}var le,oe,P,er,Et=(er=class{constructor(){w(this,le);w(this,oe);w(this,P,Object.create(null))}insert(r,i,s,a,n){if(r.length===0){if(f(this,le)!==void 0)throw me;if(n)return;v(this,le,i);return}const[o,...c]=r,l=o==="*"?c.length===0?["","",ke]:["","",tt]:o==="/*"?["","",Ce]:o.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);let d;if(l){const u=l[1];let g=l[2]||tt;if(u&&l[2]&&(g===".*"||(g=g.replace(/^\((?!\?:)(?=[^)]+\)$)/,"(?:"),/\((?!\?:)/.test(g))))throw me;if(d=f(this,P)[g],!d){if(Object.keys(f(this,P)).some(p=>p!==ke&&p!==Ce))throw me;if(n)return;d=f(this,P)[g]=new Et,u!==""&&v(d,oe,a.varIndex++)}!n&&u!==""&&s.push([u,f(d,oe)])}else if(d=f(this,P)[o],!d){if(Object.keys(f(this,P)).some(u=>u.length>1&&u!==ke&&u!==Ce))throw me;if(n)return;d=f(this,P)[o]=new Et}d.insert(c,i,s,a,n)}buildRegExpStr(){const i=Object.keys(f(this,P)).sort(Ni).map(s=>{const a=f(this,P)[s];return(typeof f(a,oe)=="number"?`(${s})@${f(a,oe)}`:Ai.has(s)?`\\${s}`:s)+a.buildRegExpStr()});return typeof f(this,le)=="number"&&i.unshift(`#${f(this,le)}`),i.length===0?"":i.length===1?i[0]:"(?:"+i.join("|")+")"}},le=new WeakMap,oe=new WeakMap,P=new WeakMap,er),it,$e,tr,ji=(tr=class{constructor(){w(this,it,{varIndex:0});w(this,$e,new Et)}insert(e,r,i){const s=[],a=[];for(let o=0;;){let c=!1;if(e=e.replace(/\{[^}]+\}/g,l=>{const d=`@\\${o}`;return a[o]=[d,l],o++,c=!0,d}),!c)break}const n=e.match(/(?::[^\/]+)|(?:\/\*$)|./g)||[];for(let o=a.length-1;o>=0;o--){const[c]=a[o];for(let l=n.length-1;l>=0;l--)if(n[l].indexOf(c)!==-1){n[l]=n[l].replace(c,a[o][1]);break}}return f(this,$e).insert(n,r,s,f(this,it),i),s}buildRegExp(){let e=f(this,$e).buildRegExpStr();if(e==="")return[/^$/,[],[]];let r=0;const i=[],s=[];return e=e.replace(/#(\d+)|@(\d+)|\.\*\$/g,(a,n,o)=>n!==void 0?(i[++r]=Number(n),"$()"):(o!==void 0&&(s[Number(o)]=++r),"")),[new RegExp(`^${e}`),i,s]}},it=new WeakMap,$e=new WeakMap,tr),kr=[],Oi=[/^$/,[],Object.create(null)],Ge=Object.create(null);function Cr(e){return Ge[e]??(Ge[e]=new RegExp(e==="*"?"":`^${e.replace(/\/\*$|([.\\+*[^\]$()])/g,(r,i)=>i?`\\${i}`:"(?:|/.*)")}$`))}function Mi(){Ge=Object.create(null)}function Bi(e){var d;const r=new ji,i=[];if(e.length===0)return Oi;const s=e.map(u=>[!/\*|\/:/.test(u[0]),...u]).sort(([u,g],[p,m])=>u?1:p?-1:g.length-m.length),a=Object.create(null);for(let u=0,g=-1,p=s.length;u<p;u++){const[m,y,h]=s[u];m?a[y]=[h.map(([E])=>[E,Object.create(null)]),kr]:g++;let b;try{b=r.insert(y,g,m)}catch(E){throw E===me?new _r(y):E}m||(i[g]=h.map(([E,S])=>{const I=Object.create(null);for(S-=1;S>=0;S--){const[_,N]=b[S];I[_]=N}return[E,I]}))}const[n,o,c]=r.buildRegExp();for(let u=0,g=i.length;u<g;u++)for(let p=0,m=i[u].length;p<m;p++){const y=(d=i[u][p])==null?void 0:d[1];if(!y)continue;const h=Object.keys(y);for(let b=0,E=h.length;b<E;b++)y[h[b]]=c[y[h[b]]]}const l=[];for(const u in o)l[u]=i[o[u]];return[n,l,a]}function fe(e,r){if(e){for(const i of Object.keys(e).sort((s,a)=>a.length-s.length))if(Cr(i).test(r))return[...e[i]]}}var J,Q,Se,Rr,Ar,rr,Di=(rr=class{constructor(){w(this,Se);x(this,"name","RegExpRouter");w(this,J);w(this,Q);v(this,J,{[C]:Object.create(null)}),v(this,Q,{[C]:Object.create(null)})}add(e,r,i){var c;const s=f(this,J),a=f(this,Q);if(!s||!a)throw new Error(Sr);s[e]||[s,a].forEach(l=>{l[e]=Object.create(null),Object.keys(l[C]).forEach(d=>{l[e][d]=[...l[C][d]]})}),r==="/*"&&(r="*");const n=(r.match(/\/:/g)||[]).length;if(/\*$/.test(r)){const l=Cr(r);e===C?Object.keys(s).forEach(d=>{var u;(u=s[d])[r]||(u[r]=fe(s[d],r)||fe(s[C],r)||[])}):(c=s[e])[r]||(c[r]=fe(s[e],r)||fe(s[C],r)||[]),Object.keys(s).forEach(d=>{(e===C||e===d)&&Object.keys(s[d]).forEach(u=>{l.test(u)&&s[d][u].push([i,n])})}),Object.keys(a).forEach(d=>{(e===C||e===d)&&Object.keys(a[d]).forEach(u=>l.test(u)&&a[d][u].push([i,n]))});return}const o=br(r)||[r];for(let l=0,d=o.length;l<d;l++){const u=o[l];Object.keys(a).forEach(g=>{var p;(e===C||e===g)&&((p=a[g])[u]||(p[u]=[...fe(s[g],u)||fe(s[C],u)||[]]),a[g][u].push([i,n-d+l+1]))})}}match(e,r){Mi();const i=L(this,Se,Rr).call(this);return this.match=(s,a)=>{const n=i[s]||i[C],o=n[2][a];if(o)return o;const c=a.match(n[0]);if(!c)return[[],kr];const l=c.indexOf("",1);return[n[1][l],c]},this.match(e,r)}},J=new WeakMap,Q=new WeakMap,Se=new WeakSet,Rr=function(){const e=Object.create(null);return Object.keys(f(this,Q)).concat(Object.keys(f(this,J))).forEach(r=>{e[r]||(e[r]=L(this,Se,Ar).call(this,r))}),v(this,J,v(this,Q,void 0)),e},Ar=function(e){const r=[];let i=e===C;return[f(this,J),f(this,Q)].forEach(s=>{const a=s[e]?Object.keys(s[e]).map(n=>[n,s[e][n]]):[];a.length!==0?(i||(i=!0),r.push(...a)):e!==C&&r.push(...Object.keys(s[C]).map(n=>[n,s[C][n]]))}),i?Bi(r):null},rr),ee,W,ir,$i=(ir=class{constructor(e){x(this,"name","SmartRouter");w(this,ee,[]);w(this,W,[]);v(this,ee,e.routers)}add(e,r,i){if(!f(this,W))throw new Error(Sr);f(this,W).push([e,r,i])}match(e,r){if(!f(this,W))throw new Error("Fatal error");const i=f(this,ee),s=f(this,W),a=i.length;let n=0,o;for(;n<a;n++){const c=i[n];try{for(let l=0,d=s.length;l<d;l++)c.add(...s[l]);o=c.match(e,r)}catch(l){if(l instanceof _r)continue;throw l}this.match=c.match.bind(c),v(this,ee,[c]),v(this,W,void 0);break}if(n===a)throw new Error("Fatal error");return this.name=`SmartRouter + ${this.activeRouter.name}`,o}get activeRouter(){if(f(this,W)||f(this,ee).length!==1)throw new Error("No active router has been determined yet.");return f(this,ee)[0]}},ee=new WeakMap,W=new WeakMap,ir),Le=Object.create(null),te,j,ce,Ee,A,z,ae,sr,Nr=(sr=class{constructor(e,r,i){w(this,z);w(this,te);w(this,j);w(this,ce);w(this,Ee,0);w(this,A,Le);if(v(this,j,i||Object.create(null)),v(this,te,[]),e&&r){const s=Object.create(null);s[e]={handler:r,possibleKeys:[],score:0},v(this,te,[s])}v(this,ce,[])}insert(e,r,i){v(this,Ee,++Nt(this,Ee)._);let s=this;const a=yi(r),n=[];for(let o=0,c=a.length;o<c;o++){const l=a[o],d=a[o+1],u=vi(l,d),g=Array.isArray(u)?u[0]:l;if(g in f(s,j)){s=f(s,j)[g],u&&n.push(u[1]);continue}f(s,j)[g]=new Nr,u&&(f(s,ce).push(u),n.push(u[1])),s=f(s,j)[g]}return f(s,te).push({[e]:{handler:i,possibleKeys:n.filter((o,c,l)=>l.indexOf(o)===c),score:f(this,Ee)}}),s}search(e,r){var c;const i=[];v(this,A,Le);let a=[this];const n=yr(r),o=[];for(let l=0,d=n.length;l<d;l++){const u=n[l],g=l===d-1,p=[];for(let m=0,y=a.length;m<y;m++){const h=a[m],b=f(h,j)[u];b&&(v(b,A,f(h,A)),g?(f(b,j)["*"]&&i.push(...L(this,z,ae).call(this,f(b,j)["*"],e,f(h,A))),i.push(...L(this,z,ae).call(this,b,e,f(h,A)))):p.push(b));for(let E=0,S=f(h,ce).length;E<S;E++){const I=f(h,ce)[E],_=f(h,A)===Le?{}:{...f(h,A)};if(I==="*"){const Y=f(h,j)["*"];Y&&(i.push(...L(this,z,ae).call(this,Y,e,f(h,A))),v(Y,A,_),p.push(Y));continue}const[N,ue,ie]=I;if(!u&&!(ie instanceof RegExp))continue;const q=f(h,j)[N],Wr=n.slice(l).join("/");if(ie instanceof RegExp){const Y=ie.exec(Wr);if(Y){if(_[ue]=Y[0],i.push(...L(this,z,ae).call(this,q,e,f(h,A),_)),Object.keys(f(q,j)).length){v(q,A,_);const at=((c=Y[0].match(/\//))==null?void 0:c.length)??0;(o[at]||(o[at]=[])).push(q)}continue}}(ie===!0||ie.test(u))&&(_[ue]=u,g?(i.push(...L(this,z,ae).call(this,q,e,_,f(h,A))),f(q,j)["*"]&&i.push(...L(this,z,ae).call(this,f(q,j)["*"],e,_,f(h,A)))):(v(q,A,_),p.push(q)))}}a=p.concat(o.shift()??[])}return i.length>1&&i.sort((l,d)=>l.score-d.score),[i.map(({handler:l,params:d})=>[l,d])]}},te=new WeakMap,j=new WeakMap,ce=new WeakMap,Ee=new WeakMap,A=new WeakMap,z=new WeakSet,ae=function(e,r,i,s){const a=[];for(let n=0,o=f(e,te).length;n<o;n++){const c=f(e,te)[n],l=c[r]||c[C],d={};if(l!==void 0&&(l.params=Object.create(null),a.push(l),i!==Le||s&&s!==Le))for(let u=0,g=l.possibleKeys.length;u<g;u++){const p=l.possibleKeys[u],m=d[l.score];l.params[p]=s!=null&&s[p]&&!m?s[p]:i[p]??(s==null?void 0:s[p]),d[l.score]=!0}}return a},sr),de,ar,Fi=(ar=class{constructor(){x(this,"name","TrieRouter");w(this,de);v(this,de,new Nr)}add(e,r,i){const s=br(r);if(s){for(let a=0,n=s.length;a<n;a++)f(this,de).insert(e,s[a],i);return}f(this,de).insert(e,r,i)}match(e,r){return f(this,de).search(e,r)}},de=new WeakMap,ar),jr=class extends Lr{constructor(e={}){super(e),this.router=e.router??new $i({routers:[new Di,new Fi]})}},Ae="_hp",Pi={Change:"Input",DoubleClick:"DblClick"},Ui={svg:"2000/svg",math:"1998/Math/MathML"},Ne=[],wt=new WeakMap,Te=void 0,qi=()=>Te,H=e=>"t"in e,ut={onClick:["click",!1]},Ut=e=>{if(!e.startsWith("on"))return;if(ut[e])return ut[e];const r=e.match(/^on([A-Z][a-zA-Z]+?(?:PointerCapture)?)(Capture)?$/);if(r){const[,i,s]=r;return ut[e]=[(Pi[i]||i).toLowerCase(),!!s]}},qt=(e,r)=>Te&&e instanceof SVGElement&&/[A-Z]/.test(r)&&(r in e.style||r.match(/^(?:o|pai|str|u|ve)/))?r.replace(/([A-Z])/g,"-$1").toLowerCase():r,Hi=(e,r,i)=>{var s;r||(r={});for(let a in r){const n=r[a];if(a!=="children"&&(!i||i[a]!==n)){a=et(a);const o=Ut(a);if(o){if((i==null?void 0:i[a])!==n&&(i&&e.removeEventListener(o[0],i[a],o[1]),n!=null)){if(typeof n!="function")throw new Error(`Event handler for "${a}" is not a function`);e.addEventListener(o[0],n,o[1])}}else if(a==="dangerouslySetInnerHTML"&&n)e.innerHTML=n.__html;else if(a==="ref"){let c;typeof n=="function"?c=n(e)||(()=>n(null)):n&&"current"in n&&(n.current=e,c=()=>n.current=null),wt.set(e,c)}else if(a==="style"){const c=e.style;typeof n=="string"?c.cssText=n:(c.cssText="",n!=null&&hr(n,c.setProperty.bind(c)))}else{if(a==="value"){const l=e.nodeName;if(l==="INPUT"||l==="TEXTAREA"||l==="SELECT"){if(e.value=n==null||n===!1?null:n,l==="TEXTAREA"){e.textContent=n;continue}else if(l==="SELECT"){e.selectedIndex===-1&&(e.selectedIndex=0);continue}}}else(a==="checked"&&e.nodeName==="INPUT"||a==="selected"&&e.nodeName==="OPTION")&&(e[a]=n);const c=qt(e,a);n==null||n===!1?e.removeAttribute(c):n===!0?e.setAttribute(c,""):typeof n=="string"||typeof n=="number"?e.setAttribute(c,n):e.setAttribute(c,n.toString())}}}if(i)for(let a in i){const n=i[a];if(a!=="children"&&!(a in r)){a=et(a);const o=Ut(a);o?e.removeEventListener(o[0],n,o[1]):a==="ref"?(s=wt.get(e))==null||s():e.removeAttribute(qt(e,a))}}},Xi=(e,r)=>{r[k][0]=0,Ne.push([e,r]);const i=r.tag[St]||r.tag,s=i.defaultProps?{...i.defaultProps,...r.props}:r.props;try{return[i.call(null,s)]}finally{Ne.pop()}},Or=(e,r,i,s,a)=>{var n,o;(n=e.vR)!=null&&n.length&&(s.push(...e.vR),delete e.vR),typeof e.tag=="function"&&((o=e[k][1][$r])==null||o.forEach(c=>a.push(c))),e.vC.forEach(c=>{var l;if(H(c))i.push(c);else if(typeof c.tag=="function"||c.tag===""){c.c=r;const d=i.length;if(Or(c,r,i,s,a),c.s){for(let u=d;u<i.length;u++)i[u].s=!0;c.s=!1}}else i.push(c),(l=c.vR)!=null&&l.length&&(s.push(...c.vR),delete c.vR)})},Ki=e=>{for(;;e=e.tag===Ae||!e.vC||!e.pP?e.nN:e.vC[0]){if(!e)return null;if(e.tag!==Ae&&e.e)return e.e}},Mr=e=>{var r,i,s,a,n,o;H(e)||((i=(r=e[k])==null?void 0:r[1][$r])==null||i.forEach(c=>{var l;return(l=c[2])==null?void 0:l.call(c)}),(s=wt.get(e.e))==null||s(),e.p===2&&((a=e.vC)==null||a.forEach(c=>c.p=2)),(n=e.vC)==null||n.forEach(Mr)),e.p||((o=e.e)==null||o.remove(),delete e.e),typeof e.tag=="function"&&(Ie.delete(e),Ze.delete(e),delete e[k][3],e.a=!0)},Br=(e,r,i)=>{e.c=r,Dr(e,r,i)},Ht=(e,r)=>{if(r){for(let i=0,s=e.length;i<s;i++)if(e[i]===r)return i}},Xt=Symbol(),Dr=(e,r,i)=>{var d;const s=[],a=[],n=[];Or(e,r,s,a,n),a.forEach(Mr);const o=i?void 0:r.childNodes;let c,l=null;if(i)c=-1;else if(!o.length)c=0;else{const u=Ht(o,Ki(e.nN));u!==void 0?(l=o[u],c=u):c=Ht(o,(d=s.find(g=>g.tag!==Ae&&g.e))==null?void 0:d.e)??-1,c===-1&&(i=!0)}for(let u=0,g=s.length;u<g;u++,c++){const p=s[u];let m;if(p.s&&p.e)m=p.e,p.s=!1;else{const y=i||!p.e;H(p)?(p.e&&p.d&&(p.e.textContent=p.t),p.d=!1,m=p.e||(p.e=document.createTextNode(p.t))):(m=p.e||(p.e=p.n?document.createElementNS(p.n,p.tag):document.createElement(p.tag)),Hi(m,p.props,p.pP),Dr(p,m,y))}p.tag===Ae?c--:i?m.parentNode||r.appendChild(m):o[c]!==m&&o[c-1]!==m&&(o[c+1]===m?r.appendChild(o[c]):r.insertBefore(m,l||o[c]||null))}if(e.pP&&delete e.pP,n.length){const u=[],g=[];n.forEach(([,p,,m,y])=>{p&&u.push(p),m&&g.push(m),y==null||y()}),u.forEach(p=>p()),g.length&&requestAnimationFrame(()=>{g.forEach(p=>p())})}},Wi=(e,r)=>!!(e&&e.length===r.length&&e.every((i,s)=>i[1]===r[s][1])),Ze=new WeakMap,Tt=(e,r,i)=>{var n,o,c,l,d,u;const s=!i&&r.pC;i&&(r.pC||(r.pC=r.vC));let a;try{i||(i=typeof r.tag=="function"?Xi(e,r):Fe(r.props.children)),((n=i[0])==null?void 0:n.tag)===""&&i[0][xt]&&(a=i[0][xt],e[5].push([e,a,r]));const g=s?[...r.pC]:r.vC?[...r.vC]:void 0,p=[];let m;for(let y=0;y<i.length;y++){Array.isArray(i[y])&&i.splice(y,1,...i[y].flat());let h=zi(i[y]);if(h){typeof h.tag=="function"&&!h.tag[dr]&&(we.length>0&&(h[k][2]=we.map(E=>[E,E.values.at(-1)])),(o=e[5])!=null&&o.length&&(h[k][3]=e[5].at(-1)));let b;if(g&&g.length){const E=g.findIndex(H(h)?S=>H(S):h.key!==void 0?S=>S.key===h.key&&S.tag===h.tag:S=>S.tag===h.tag);E!==-1&&(b=g[E],g.splice(E,1))}if(b)if(H(h))b.t!==h.t&&(b.t=h.t,b.d=!0),h=b;else{const E=b.pP=b.props;if(b.props=h.props,b.f||(b.f=h.f||r.f),typeof h.tag=="function"){const S=b[k][2];b[k][2]=h[k][2]||[],b[k][3]=h[k][3],!b.f&&((b.o||b)===h.o||(l=(c=b.tag)[Zr])!=null&&l.call(c,E,b.props))&&Wi(S,b[k][2])&&(b.s=!0)}h=b}else if(!H(h)&&Te){const E=_e(Te);E&&(h.n=E)}if(!H(h)&&!h.s&&(Tt(e,h),delete h.f),p.push(h),m&&!m.s&&!h.s)for(let E=m;E&&!H(E);E=(d=E.vC)==null?void 0:d.at(-1))E.nN=h;m=h}}r.vR=s?[...r.vC,...g||[]]:g||[],r.vC=p,s&&delete r.pC}catch(g){if(r.f=!0,g===Xt){if(a)return;throw g}const[p,m,y]=((u=r[k])==null?void 0:u[3])||[];if(m){const h=()=>Je([0,!1,e[2]],y),b=Ze.get(y)||[];b.push(h),Ze.set(y,b);const E=m(g,()=>{const S=Ze.get(y);if(S){const I=S.indexOf(h);if(I!==-1)return S.splice(I,1),h()}});if(E){if(e[0]===1)e[1]=!0;else if(Tt(e,y,[E]),(m.length===1||e!==p)&&y.c){Br(y,y.c,!1);return}throw Xt}}throw g}finally{a&&e[5].pop()}},zi=e=>{if(!(e==null||typeof e=="boolean")){if(typeof e=="string"||typeof e=="number")return{t:e.toString(),d:!0};if("vR"in e&&(e={tag:e.tag,props:e.props,key:e.key,f:e.f,type:e.tag,ref:e.props.ref,o:e.o||e}),typeof e.tag=="function")e[k]=[0,[]];else{const r=Ui[e.tag];r&&(Te||(Te=fr("")),e.props.children=[{tag:Te,props:{value:e.n=`http://www.w3.org/${r}`,children:e.props.children}}])}return e}},Kt=(e,r)=>{var i,s;(i=r[k][2])==null||i.forEach(([a,n])=>{a.values.push(n)});try{Tt(e,r,void 0)}catch{return}if(r.a){delete r.a;return}(s=r[k][2])==null||s.forEach(([a])=>{a.values.pop()}),(e[0]!==1||!e[1])&&Br(r,r.c,!1)},Ie=new WeakMap,Wt=[],Je=async(e,r)=>{e[5]||(e[5]=[]);const i=Ie.get(r);i&&i[0](void 0);let s;const a=new Promise(n=>s=n);if(Ie.set(r,[s,()=>{e[2]?e[2](e,r,n=>{Kt(n,r)}).then(()=>s(r)):(Kt(e,r),s(r))}]),Wt.length)Wt.at(-1).add(r);else{await Promise.resolve();const n=Ie.get(r);n&&(Ie.delete(r),n[1]())}return a},Vi=(e,r,i)=>({tag:Ae,props:{children:e},key:i,e:r,p:1}),ft=0,$r=1,gt=2,pt=3,ht=new WeakMap,Fr=(e,r)=>!e||!r||e.length!==r.length||r.some((i,s)=>i!==e[s]),Yi=void 0,zt=[],Gi=e=>{var o;const r=()=>typeof e=="function"?e():e,i=Ne.at(-1);if(!i)return[r(),()=>{}];const[,s]=i,a=(o=s[k][1])[ft]||(o[ft]=[]),n=s[k][0]++;return a[n]||(a[n]=[r(),c=>{const l=Yi,d=a[n];if(typeof c=="function"&&(c=c(d[0])),!Object.is(c,d[0]))if(d[0]=c,zt.length){const[u,g]=zt.at(-1);Promise.all([u===3?s:Je([u,!1,l],s),g]).then(([p])=>{if(!p||!(u===2||u===3))return;const m=p.vC;requestAnimationFrame(()=>{setTimeout(()=>{m===p.vC&&Je([u===3?1:0,!1,l],p)})})})}else Je([0,!1,l],s)}])},Ct=(e,r)=>{var c;const i=Ne.at(-1);if(!i)return e;const[,s]=i,a=(c=s[k][1])[gt]||(c[gt]=[]),n=s[k][0]++,o=a[n];return Fr(o==null?void 0:o[1],r)?a[n]=[e,r]:e=a[n][0],e},Zi=e=>{const r=ht.get(e);if(r){if(r.length===2)throw r[1];return r[0]}throw e.then(i=>ht.set(e,[i]),i=>ht.set(e,[void 0,i])),e},Ji=(e,r)=>{var c;const i=Ne.at(-1);if(!i)return e();const[,s]=i,a=(c=s[k][1])[pt]||(c[pt]=[]),n=s[k][0]++,o=a[n];return Fr(o==null?void 0:o[1],r)&&(a[n]=[e(),r]),a[n][0]},Qi=fr({pending:!1,data:null,method:null,action:null}),Vt=new Set,es=e=>{Vt.add(e),e.finally(()=>Vt.delete(e))},Rt=(e,r)=>Ji(()=>i=>{let s;e&&(typeof e=="function"?s=e(i)||(()=>{e(null)}):e&&"current"in e&&(e.current=i,s=()=>{e.current=null}));const a=r(i);return()=>{a==null||a(),s==null||s()}},[e]),ge=Object.create(null),Xe=Object.create(null),qe=(e,r,i,s,a)=>{if(r!=null&&r.itemProp)return{tag:e,props:r,type:e,ref:r.ref};const n=document.head;let{onLoad:o,onError:c,precedence:l,blocking:d,...u}=r,g=null,p=!1;const m=Ke[e];let y;if(m.length>0){const S=n.querySelectorAll(e);e:for(const I of S)for(const _ of Ke[e])if(I.getAttribute(_)===r[_]){g=I;break e}if(!g){const I=m.reduce((_,N)=>r[N]===void 0?_:`${_}-${N}-${r[N]}`,e);p=!Xe[I],g=Xe[I]||(Xe[I]=(()=>{const _=document.createElement(e);for(const N of m)r[N]!==void 0&&_.setAttribute(N,r[N]),r.rel&&_.setAttribute("rel",r.rel);return _})())}}else y=n.querySelectorAll(e);l=s?l??"":void 0,s&&(u[We]=l);const h=Ct(S=>{if(m.length>0){let I=!1;for(const _ of n.querySelectorAll(e)){if(I&&_.getAttribute(We)!==l){n.insertBefore(S,_);return}_.getAttribute(We)===l&&(I=!0)}n.appendChild(S)}else if(y){let I=!1;for(const _ of y)if(_===S){I=!0;break}I||n.insertBefore(S,n.contains(y[0])?y[0]:n.querySelector(e)),y=void 0}},[l]),b=Rt(r.ref,S=>{var N;const I=m[0];if(i===2&&(S.innerHTML=""),(p||y)&&h(S),!c&&!o)return;let _=ge[N=S.getAttribute(I)]||(ge[N]=new Promise((ue,ie)=>{S.addEventListener("load",ue),S.addEventListener("error",ie)}));o&&(_=_.then(o)),c&&(_=_.catch(c)),_.catch(()=>{})});if(a&&d==="render"){const S=Ke[e][0];if(r[S]){const I=r[S],_=ge[I]||(ge[I]=new Promise((N,ue)=>{h(g),g.addEventListener("load",N),g.addEventListener("error",ue)}));Zi(_)}}const E={tag:e,type:e,props:{...u,ref:b},ref:b};return E.p=i,g&&(E.e=g),Vi(E,n)},ts=e=>{const r=qi(),i=r&&_e(r);return i!=null&&i.endsWith("svg")?{tag:"title",props:e,type:"title",ref:e.ref}:qe("title",e,void 0,!1,!1)},rs=e=>!e||["src","async"].some(r=>!e[r])?{tag:"script",props:e,type:"script",ref:e.ref}:qe("script",e,1,!1,!0),is=e=>!e||!["href","precedence"].every(r=>r in e)?{tag:"style",props:e,type:"style",ref:e.ref}:(e["data-href"]=e.href,delete e.href,qe("style",e,2,!0,!0)),ss=e=>!e||["onLoad","onError"].some(r=>r in e)||e.rel==="stylesheet"&&(!("precedence"in e)||"disabled"in e)?{tag:"link",props:e,type:"link",ref:e.ref}:qe("link",e,1,"precedence"in e,!0),as=e=>qe("meta",e,void 0,!1,!1),Pr=Symbol(),ns=e=>{const{action:r,...i}=e;typeof r!="function"&&(i.action=r);const[s,a]=Gi([null,!1]),n=Ct(async d=>{const u=d.isTrusted?r:d.detail[Pr];if(typeof u!="function")return;d.preventDefault();const g=new FormData(d.target);a([g,!0]);const p=u(g);p instanceof Promise&&(es(p),await p),a([null,!0])},[]),o=Rt(e.ref,d=>(d.addEventListener("submit",n),()=>{d.removeEventListener("submit",n)})),[c,l]=s;return s[1]=!1,{tag:Qi,props:{value:{pending:c!==null,data:c,method:c?"post":null,action:c?r:null},children:{tag:"form",props:{...i,ref:o},type:"form",ref:o}},f:l}},Ur=(e,{formAction:r,...i})=>{if(typeof r=="function"){const s=Ct(a=>{a.preventDefault(),a.currentTarget.form.dispatchEvent(new CustomEvent("submit",{detail:{[Pr]:r}}))},[]);i.ref=Rt(i.ref,a=>(a.addEventListener("click",s),()=>{a.removeEventListener("click",s)}))}return{tag:e,props:i,type:e,ref:i.ref}},ls=e=>Ur("input",e),os=e=>Ur("button",e);Object.assign(bt,{title:ts,script:rs,style:is,link:ss,meta:as,form:ns,input:ls,button:os});_t(null);new TextEncoder;var cs=_t(null),ds=(e,r,i,s)=>(a,n)=>{const o="<!DOCTYPE html>",c=i?Bt(d=>i(d,e),{Layout:r,...n},a):a,l=Gr`${D(o)}${Bt(cs.Provider,{value:e},c)}`;return e.html(l)},us=(e,r)=>function(s,a){const n=s.getLayout()??di;return e&&s.setLayout(o=>e({...o,Layout:n},s)),s.setRenderer(ds(s,n,e)),a()};const fs=us(({children:e})=>t("html",{lang:"ko",children:[t("head",{children:[t("meta",{charset:"UTF-8"}),t("meta",{name:"viewport",content:"width=device-width, initial-scale=1.0"}),t("title",{children:"케어조아 - 전국 요양원/요양병원 실시간 비교 견적"}),t("meta",{name:"description",content:"전국 14,000개 이상의 요양원, 요양병원, 노인요양시설을 한눈에 비교하고 실시간 견적을 받아보세요. 지역별 요양시설 검색부터 맞춤 상담까지 무료로 제공합니다."}),t("meta",{name:"keywords",content:"요양원, 요양병원, 노인요양시설, 실버타운, 요양원 비용, 요양병원 비교, 요양시설 견적, 케어조아, 노인돌봄, 장기요양보험"}),t("meta",{name:"author",content:"케어조아"}),t("link",{rel:"canonical",href:"https://carejoa.kr"}),t("meta",{property:"og:type",content:"website"}),t("meta",{property:"og:site_name",content:"케어조아"}),t("meta",{property:"og:title",content:"케어조아 - 전국 요양시설 비교 플랫폼"}),t("meta",{property:"og:description",content:"전국 14,000개 이상의 요양시설을 한눈에 비교하고 맞춤 견적을 받아보세요."}),t("meta",{property:"og:url",content:"https://carejoa.kr"}),t("meta",{property:"og:image",content:"https://page.gensparksite.com/v1/base64_upload/b39dca8586af1dacd6d8417554313896"}),t("meta",{property:"og:image:width",content:"1200"}),t("meta",{property:"og:image:height",content:"630"}),t("meta",{property:"og:locale",content:"ko_KR"}),t("meta",{name:"twitter:card",content:"summary_large_image"}),t("meta",{name:"twitter:title",content:"케어조아 - 전국 요양시설 비교 플랫폼"}),t("meta",{name:"twitter:description",content:"전국 14,000개 이상의 요양시설을 한눈에 비교하고 맞춤 견적을 받아보세요."}),t("meta",{name:"twitter:image",content:"https://page.gensparksite.com/v1/base64_upload/b39dca8586af1dacd6d8417554313896"}),t("meta",{name:"theme-color",content:"#0d9488"}),t("meta",{name:"mobile-web-app-capable",content:"yes"}),t("meta",{name:"apple-mobile-web-app-capable",content:"yes"}),t("meta",{name:"apple-mobile-web-app-status-bar-style",content:"black-translucent"}),t("meta",{name:"apple-mobile-web-app-title",content:"케어조아"}),t("meta",{name:"naver-site-verification",content:"5cc01115b78cdcac6d30bc8ce080f4290c212043"}),t("script",{async:!0,src:"https://www.googletagmanager.com/gtag/js?id=G-KWGGQN7LR3"}),t("script",{dangerouslySetInnerHTML:{__html:`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-KWGGQN7LR3', {
              page_path: window.location.pathname,
              send_page_view: true
            });
            
            // 커스텀 이벤트 함수
            window.trackEvent = function(eventName, eventParams) {
              gtag('event', eventName, eventParams);
            };
          `}}),t("link",{rel:"icon",href:"data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>❤️</text></svg>"}),t("link",{href:"/static/tailwind.css",rel:"stylesheet"}),t("link",{href:"https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css",rel:"stylesheet"}),t("link",{href:"/static/style.css",rel:"stylesheet"}),t("script",{type:"application/ld+json",dangerouslySetInnerHTML:{__html:JSON.stringify({"@context":"https://schema.org","@type":"WebSite",name:"케어조아",alternateName:"CareJoa",url:"https://carejoa.kr",description:"전국 요양원, 요양병원, 노인요양시설 비교 및 견적 플랫폼",inLanguage:"ko-KR",potentialAction:{"@type":"SearchAction",target:{"@type":"EntryPoint",urlTemplate:"https://carejoa.kr/search?q={search_term_string}"},"query-input":"required name=search_term_string"}})}}),t("script",{type:"application/ld+json",dangerouslySetInnerHTML:{__html:JSON.stringify({"@context":"https://schema.org","@type":"Organization",name:"케어조아",url:"https://carejoa.kr",logo:"https://page.gensparksite.com/v1/base64_upload/b39dca8586af1dacd6d8417554313896",description:"요양시설 비교 및 맞춤 견적 서비스",address:{"@type":"PostalAddress",addressCountry:"KR",addressLocality:"대한민국"},contactPoint:{"@type":"ContactPoint",contactType:"고객지원",availableLanguage:["Korean"]},sameAs:["https://open.kakao.com/o/siR7YBUh"]})}}),t("script",{type:"application/ld+json",dangerouslySetInnerHTML:{__html:JSON.stringify({"@context":"https://schema.org","@type":"Service",serviceType:"요양시설 비교 및 견적 서비스",provider:{"@type":"Organization",name:"케어조아"},areaServed:{"@type":"Country",name:"대한민국"},audience:{"@type":"Audience",audienceType:"요양시설을 찾는 보호자, 환자 가족"},offers:{"@type":"Offer",price:"0",priceCurrency:"KRW",description:"무료 요양시설 비교 및 견적 상담"}})}}),t("style",{children:`
          body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif;
          }
        `})]}),t("body",{class:"bg-gray-50 min-h-screen",children:[e,t("script",{src:"https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"}),t("script",{dangerouslySetInnerHTML:{__html:`
          if ('serviceWorker' in navigator) {
            navigator.serviceWorker.getRegistrations().then(function(registrations) {
              for(let registration of registrations) {
                registration.unregister();
              }
            });
          }
        `}}),t("script",{src:"/static/app.js"})]})]}));var gs=e=>{const i={...{origin:"*",allowMethods:["GET","HEAD","PUT","POST","DELETE","PATCH"],allowHeaders:[],exposeHeaders:[]},...e},s=(n=>typeof n=="string"?n==="*"?()=>n:o=>n===o?o:null:typeof n=="function"?n:o=>n.includes(o)?o:null)(i.origin),a=(n=>typeof n=="function"?n:Array.isArray(n)?()=>n:()=>[])(i.allowMethods);return async function(o,c){var u;function l(g,p){o.res.headers.set(g,p)}const d=await s(o.req.header("origin")||"",o);if(d&&l("Access-Control-Allow-Origin",d),i.origin!=="*"){const g=o.req.header("Vary");g?l("Vary",g):l("Vary","Origin")}if(i.credentials&&l("Access-Control-Allow-Credentials","true"),(u=i.exposeHeaders)!=null&&u.length&&l("Access-Control-Expose-Headers",i.exposeHeaders.join(",")),o.req.method==="OPTIONS"){i.maxAge!=null&&l("Access-Control-Max-Age",i.maxAge.toString());const g=await a(o.req.header("origin")||"",o);g.length&&l("Access-Control-Allow-Methods",g.join(","));let p=i.allowHeaders;if(!(p!=null&&p.length)){const m=o.req.header("Access-Control-Request-Headers");m&&(p=m.split(/\s*,\s*/))}return p!=null&&p.length&&(l("Access-Control-Allow-Headers",p.join(",")),o.res.headers.append("Vary","Access-Control-Request-Headers")),o.res.headers.delete("Content-Length"),o.res.headers.delete("Content-Type"),new Response(null,{headers:o.res.headers,status:204,statusText:"No Content"})}await c()}},ps=/^\s*(?:text\/(?!event-stream(?:[;\s]|$))[^;\s]+|application\/(?:javascript|json|xml|xml-dtd|ecmascript|dart|postscript|rtf|tar|toml|vnd\.dart|vnd\.ms-fontobject|vnd\.ms-opentype|wasm|x-httpd-php|x-javascript|x-ns-proxy-autoconfig|x-sh|x-tar|x-virtualbox-hdd|x-virtualbox-ova|x-virtualbox-ovf|x-virtualbox-vbox|x-virtualbox-vdi|x-virtualbox-vhd|x-virtualbox-vmdk|x-www-form-urlencoded)|font\/(?:otf|ttf)|image\/(?:bmp|vnd\.adobe\.photoshop|vnd\.microsoft\.icon|vnd\.ms-dds|x-icon|x-ms-bmp)|message\/rfc822|model\/gltf-binary|x-shader\/x-fragment|x-shader\/x-vertex|[^;\s]+?\+(?:json|text|xml|yaml))(?:[;\s]|$)/i,Yt=(e,r=ms)=>{const i=/\.([a-zA-Z0-9]+?)$/,s=e.match(i);if(!s)return;let a=r[s[1]];return a&&a.startsWith("text")&&(a+="; charset=utf-8"),a},hs={aac:"audio/aac",avi:"video/x-msvideo",avif:"image/avif",av1:"video/av1",bin:"application/octet-stream",bmp:"image/bmp",css:"text/css",csv:"text/csv",eot:"application/vnd.ms-fontobject",epub:"application/epub+zip",gif:"image/gif",gz:"application/gzip",htm:"text/html",html:"text/html",ico:"image/x-icon",ics:"text/calendar",jpeg:"image/jpeg",jpg:"image/jpeg",js:"text/javascript",json:"application/json",jsonld:"application/ld+json",map:"application/json",mid:"audio/x-midi",midi:"audio/x-midi",mjs:"text/javascript",mp3:"audio/mpeg",mp4:"video/mp4",mpeg:"video/mpeg",oga:"audio/ogg",ogv:"video/ogg",ogx:"application/ogg",opus:"audio/opus",otf:"font/otf",pdf:"application/pdf",png:"image/png",rtf:"application/rtf",svg:"image/svg+xml",tif:"image/tiff",tiff:"image/tiff",ts:"video/mp2t",ttf:"font/ttf",txt:"text/plain",wasm:"application/wasm",webm:"video/webm",weba:"audio/webm",webmanifest:"application/manifest+json",webp:"image/webp",woff:"font/woff",woff2:"font/woff2",xhtml:"application/xhtml+xml",xml:"application/xml",zip:"application/zip","3gp":"video/3gpp","3g2":"video/3gpp2",gltf:"model/gltf+json",glb:"model/gltf-binary"},ms=hs,ys=(...e)=>{let r=e.filter(a=>a!=="").join("/");r=r.replace(new RegExp("(?<=\\/)\\/+","g"),"");const i=r.split("/"),s=[];for(const a of i)a===".."&&s.length>0&&s.at(-1)!==".."?s.pop():a!=="."&&s.push(a);return s.join("/")||"."},qr={br:".br",zstd:".zst",gzip:".gz"},xs=Object.keys(qr),bs="index.html",vs=e=>{const r=e.root??"./",i=e.path,s=e.join??ys;return async(a,n)=>{var u,g,p,m;if(a.finalized)return n();let o;if(e.path)o=e.path;else try{if(o=decodeURIComponent(a.req.path),/(?:^|[\/\\])\.\.(?:$|[\/\\])/.test(o))throw new Error}catch{return await((u=e.onNotFound)==null?void 0:u.call(e,a.req.path,a)),n()}let c=s(r,!i&&e.rewriteRequestPath?e.rewriteRequestPath(o):o);e.isDir&&await e.isDir(c)&&(c=s(c,bs));const l=e.getContent;let d=await l(c,a);if(d instanceof Response)return a.newResponse(d.body,d);if(d){const y=e.mimes&&Yt(c,e.mimes)||Yt(c);if(a.header("Content-Type",y||"application/octet-stream"),e.precompressed&&(!y||ps.test(y))){const h=new Set((g=a.req.header("Accept-Encoding"))==null?void 0:g.split(",").map(b=>b.trim()));for(const b of xs){if(!h.has(b))continue;const E=await l(c+qr[b],a);if(E){d=E,a.header("Content-Encoding",b),a.header("Vary","Accept-Encoding",{append:!0});break}}}return await((p=e.onFound)==null?void 0:p.call(e,c,a)),a.body(d)}await((m=e.onNotFound)==null?void 0:m.call(e,c,a)),await n()}},Es=async(e,r)=>{let i;r&&r.manifest?typeof r.manifest=="string"?i=JSON.parse(r.manifest):i=r.manifest:typeof __STATIC_CONTENT_MANIFEST=="string"?i=JSON.parse(__STATIC_CONTENT_MANIFEST):i=__STATIC_CONTENT_MANIFEST;let s;r&&r.namespace?s=r.namespace:s=__STATIC_CONTENT;const a=i[e]||e;if(!a)return null;const n=await s.get(a,{type:"stream"});return n||null},ws=e=>async function(i,s){return vs({...e,getContent:async n=>Es(n,{manifest:e.manifest,namespace:e.namespace?e.namespace:i.env?i.env.__STATIC_CONTENT:void 0})})(i,s)},Ts=e=>ws(e),Ss=/^[\w!#$%&'*.^`|~+-]+$/,_s=/^[ !#-:<-[\]-~]*$/,Ls=(e,r)=>{if(e.indexOf(r)===-1)return{};const i=e.trim().split(";"),s={};for(let a of i){a=a.trim();const n=a.indexOf("=");if(n===-1)continue;const o=a.substring(0,n).trim();if(r!==o||!Ss.test(o))continue;let c=a.substring(n+1).trim();if(c.startsWith('"')&&c.endsWith('"')&&(c=c.slice(1,-1)),_s.test(c)){s[o]=c.indexOf("%")!==-1?st(c,kt):c;break}}return s},Is=(e,r,i={})=>{let s=`${e}=${r}`;if(e.startsWith("__Secure-")&&!i.secure)throw new Error("__Secure- Cookie must have Secure attributes");if(e.startsWith("__Host-")){if(!i.secure)throw new Error("__Host- Cookie must have Secure attributes");if(i.path!=="/")throw new Error('__Host- Cookie must have Path attributes with "/"');if(i.domain)throw new Error("__Host- Cookie must not have Domain attributes")}if(i&&typeof i.maxAge=="number"&&i.maxAge>=0){if(i.maxAge>3456e4)throw new Error("Cookies Max-Age SHOULD NOT be greater than 400 days (34560000 seconds) in duration.");s+=`; Max-Age=${i.maxAge|0}`}if(i.domain&&i.prefix!=="host"&&(s+=`; Domain=${i.domain}`),i.path&&(s+=`; Path=${i.path}`),i.expires){if(i.expires.getTime()-Date.now()>3456e7)throw new Error("Cookies Expires SHOULD NOT be greater than 400 days (34560000 seconds) in the future.");s+=`; Expires=${i.expires.toUTCString()}`}if(i.httpOnly&&(s+="; HttpOnly"),i.secure&&(s+="; Secure"),i.sameSite&&(s+=`; SameSite=${i.sameSite.charAt(0).toUpperCase()+i.sameSite.slice(1)}`),i.priority&&(s+=`; Priority=${i.priority.charAt(0).toUpperCase()+i.priority.slice(1)}`),i.partitioned){if(!i.secure)throw new Error("Partitioned Cookie must have Secure attributes");s+="; Partitioned"}return s},mt=(e,r,i)=>(r=encodeURIComponent(r),Is(e,r,i)),Hr=(e,r,i)=>{const s=e.req.raw.headers.get("Cookie");{if(!s)return;let a=r;return Ls(s,a)[a]}},ks=(e,r,i)=>{let s;return(i==null?void 0:i.prefix)==="secure"?s=mt("__Secure-"+e,r,{path:"/",...i,secure:!0}):(i==null?void 0:i.prefix)==="host"?s=mt("__Host-"+e,r,{...i,path:"/",secure:!0,domain:void 0}):s=mt(e,r,{path:"/",...i}),s},Xr=(e,r,i,s)=>{const a=ks(r,i,s);e.header("Set-Cookie",a,{append:!0})};const T=new jr,rt={sessionKey:"admin_session"};async function M(e){const r=Hr(e,rt.sessionKey);if(!r)return!1;const{DB:i}=e.env,s=new Date().toISOString();return!!await i.prepare("SELECT session_id FROM admin_sessions WHERE session_id = ? AND expires_at > ?").bind(r,s).first()}function Cs(){return"session_"+Date.now()+"_"+Math.random().toString(36).substring(2)}let yt=!1;T.use("*",async(e,r)=>{if(!yt&&e.env.DB)try{console.log("🔧 자동 데이터베이스 초기화 시작...");const{DB:i}=e.env;await i.prepare("CREATE TABLE IF NOT EXISTS admin_sessions (session_id TEXT PRIMARY KEY, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, expires_at DATETIME NOT NULL)").run(),await i.prepare("CREATE TABLE IF NOT EXISTS partners (id TEXT PRIMARY KEY, facility_name TEXT NOT NULL, facility_type TEXT NOT NULL, facility_sido TEXT, facility_sigungu TEXT, facility_address TEXT, manager_name TEXT NOT NULL, manager_phone TEXT NOT NULL, region_key TEXT, is_regional_center INTEGER DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP)").run(),await i.prepare("CREATE TABLE IF NOT EXISTS family_care (id TEXT PRIMARY KEY, guardian_name TEXT NOT NULL, guardian_phone TEXT NOT NULL, patient_name TEXT NOT NULL, patient_age INTEGER, region TEXT, requirements TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)").run(),await i.prepare("CREATE TABLE IF NOT EXISTS regional_centers (id TEXT PRIMARY KEY, region_key TEXT NOT NULL, partner_id TEXT NOT NULL, facility_name TEXT NOT NULL, facility_type TEXT NOT NULL, manager_name TEXT NOT NULL, manager_phone TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)").run(),await i.prepare("CREATE TABLE IF NOT EXISTS facilities (id INTEGER PRIMARY KEY AUTOINCREMENT, facility_type TEXT NOT NULL, name TEXT NOT NULL, postal_code TEXT, address TEXT NOT NULL, phone TEXT, latitude REAL NOT NULL, longitude REAL NOT NULL, sido TEXT NOT NULL, sigungu TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP)").run(),yt=!0,console.log("✅ 데이터베이스 자동 초기화 완료")}catch(i){console.error("⚠️ 데이터베이스 초기화 경고:",i),yt=!0}await r()});T.use("/api/*",gs());T.use("/static/*",Ts({root:"./public"}));T.get("/robots.txt",e=>e.text(`# robots.txt for carejoa.kr

# 모든 검색 엔진 허용
User-agent: *
Allow: /

# 크롤링 속도 제한 (초당 1회)
Crawl-delay: 1

# 관리자 페이지 차단
Disallow: /admin
Disallow: /api/admin/*

# 사이트맵 위치
Sitemap: https://carejoa.kr/sitemap.xml

# 주요 검색엔진별 설정
User-agent: Googlebot
Allow: /

User-agent: Yeti
Allow: /

User-agent: Bingbot
Allow: /

User-agent: Slurp
Allow: /`,200,{"Content-Type":"text/plain; charset=utf-8"}));T.get("/sitemap.xml",e=>e.text(`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
        http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
  
  <!-- 메인 페이지 -->
  <url>
    <loc>https://carejoa.kr/</loc>
    <lastmod>2025-10-23</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  
  <!-- 요양시설 검색 페이지 -->
  <url>
    <loc>https://carejoa.kr/search</loc>
    <lastmod>2025-10-23</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  
  <!-- 가족간병 등록 페이지 -->
  <url>
    <loc>https://carejoa.kr/family-care-register</loc>
    <lastmod>2025-10-23</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  
  <!-- 파트너 등록 페이지 -->
  <url>
    <loc>https://carejoa.kr/partner-register</loc>
    <lastmod>2025-10-23</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  
  <!-- 지역 파트너 등록 페이지 -->
  <url>
    <loc>https://carejoa.kr/regional-partner-register</loc>
    <lastmod>2025-10-23</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  
</urlset>`,200,{"Content-Type":"application/xml; charset=utf-8"}));T.use(fs);T.get("/",e=>e.render(t("div",{children:[t("header",{class:"bg-white shadow-sm border-b",children:t("div",{class:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:t("div",{class:"flex justify-between items-center h-16",children:[t("div",{class:"flex items-center",children:[t("img",{src:"https://page.gensparksite.com/v1/base64_upload/b39dca8586af1dacd6d8417554313896",alt:"케어조아 로고",class:"h-8 w-auto mr-3"}),t("h1",{class:"text-2xl font-bold text-teal-600",children:"케어조아"})]}),t("nav",{class:"hidden md:flex space-x-2 lg:space-x-3 text-sm",children:[t("a",{href:"#partner-section",class:"bg-red-600 text-white hover:bg-red-700 px-3 py-2 rounded-lg",children:[t("i",{class:"fas fa-hospital mr-1"}),"상급병원담당자"]}),t("a",{href:"#partner-section",class:"bg-blue-600 text-white hover:bg-blue-700 px-3 py-2 rounded-lg",children:[t("i",{class:"fas fa-building mr-1"}),"정부복지담당자"]}),t("a",{href:"/family-care-register",class:"bg-green-600 text-white hover:bg-green-700 px-3 py-2 rounded-lg",children:[t("i",{class:"fas fa-heart mr-1"}),"가족간병등록"]}),t("a",{href:"#partner-section",class:"bg-gray-600 text-white hover:bg-gray-700 px-3 py-2 rounded-lg",children:[t("i",{class:"fas fa-handshake mr-1"}),"요양시설입점"]}),t("a",{href:"/admin",class:"bg-gray-900 text-white hover:bg-black px-3 py-2 rounded-lg",children:[t("i",{class:"fas fa-shield-alt mr-1"}),"관리자"]})]})]})})}),t("section",{class:"relative bg-white",children:t("div",{class:"max-w-6xl mx-auto px-4 py-8 md:py-16",children:t("div",{class:"grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16 items-center",children:[t("div",{class:"space-y-6 md:space-y-8",children:[t("div",{children:[t("h1",{class:"text-3xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-4 md:mb-6 leading-tight",children:["이젠 찾지 말고",t("br",{}),t("span",{class:"text-red-600",children:"고르세요"}),t("br",{}),t("span",{class:"text-blue-600",children:"케어조아"})]}),t("p",{class:"text-base md:text-xl text-gray-600 mb-6 md:mb-8 leading-relaxed",children:["희망하는 지역의, 희망하는 시설만!",t("br",{class:"md:hidden"}),t("span",{class:"hidden md:inline",children:" "}),"입력하면",t("br",{}),"그 지역 ",t("strong",{class:"text-blue-600",children:"모든 시설의 정보를"}),t("br",{class:"md:hidden"}),t("span",{class:"hidden md:inline",children:" "}),"실시간으로 받아볼 수 있어요"]}),t("div",{class:"bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-xl p-3 md:p-4 mb-6",children:t("div",{class:"flex flex-col md:flex-row items-center justify-center text-center gap-1 md:gap-0",children:[t("div",{class:"flex items-center text-xs md:text-base",children:[t("i",{class:"fas fa-certificate text-blue-600 mr-1 md:mr-2 text-sm md:text-base"}),t("span",{class:"text-blue-800 font-semibold",children:"특허기반 실시간 요양"})]}),t("div",{class:"flex items-center text-xs md:text-base",children:[t("span",{class:"text-blue-800 font-semibold",children:"견적 및 상담 플랫폼"}),t("i",{class:"fas fa-check-circle text-green-600 ml-1 md:ml-2 text-sm md:text-base"})]})]})})]}),t("div",{class:"flex flex-col gap-3 md:gap-4 mb-8",children:[t("div",{class:"grid grid-cols-2 gap-3 md:gap-4",children:[t("a",{href:"https://play.google.com/store/apps/details?id=app.netlify.std_care_joa.twa",target:"_blank",rel:"noopener noreferrer",class:"flex flex-col items-center justify-center bg-gradient-to-br from-blue-500 to-blue-600 text-white p-6 md:p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105",children:[t("span",{class:"text-5xl md:text-6xl mb-3",children:"📱"}),t("span",{class:"text-sm md:text-lg font-bold text-center",children:"Android"}),t("span",{class:"text-xs md:text-base font-medium text-center text-blue-100",children:"앱 다운로드"})]}),t("a",{href:"https://www.carejoa.com",target:"_blank",rel:"noopener noreferrer",class:"flex flex-col items-center justify-center bg-gradient-to-br from-white to-gray-50 text-gray-900 p-6 md:p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 border-2 border-gray-200",children:[t("span",{class:"text-5xl md:text-6xl mb-3",children:"📋"}),t("span",{class:"text-sm md:text-lg font-bold text-center",children:"실시간 견적"}),t("span",{class:"text-xs md:text-base font-medium text-center text-gray-600",children:"상담 신청"})]})]}),t("div",{class:"grid grid-cols-2 gap-3 md:gap-4",children:[t("button",{onclick:"document.getElementById('regionalCallModal').classList.remove('hidden')",class:"flex flex-col items-center justify-center bg-gradient-to-br from-green-500 to-emerald-600 text-white p-4 md:p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105",children:[t("span",{class:"text-3xl md:text-4xl mb-2",children:"📞"}),t("span",{class:"text-xs md:text-base font-bold text-center",children:"지역별 전화상담"})]}),t("a",{href:"/facilities",class:"flex flex-col items-center justify-center bg-gradient-to-br from-purple-500 to-pink-500 text-white p-4 md:p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105",children:[t("span",{class:"text-3xl md:text-4xl mb-2",children:"🔍"}),t("span",{class:"text-xs md:text-base font-bold text-center",children:"전국 시설 찾기"})]})]})]}),t("div",{class:"grid grid-cols-3 sm:flex sm:flex-row items-center gap-2 sm:gap-6 text-xs md:text-base text-gray-600",children:[t("div",{class:"flex flex-col sm:flex-row items-center text-center sm:text-left",children:[t("span",{class:"text-xl md:text-2xl mb-1 sm:mb-0 sm:mr-2",children:"👥"}),t("span",{class:"font-medium whitespace-nowrap",children:["월 10만+",t("br",{class:"sm:hidden"}),"이용자"]})]}),t("div",{class:"flex flex-col sm:flex-row items-center text-center sm:text-left",children:[t("span",{class:"text-xl md:text-2xl mb-1 sm:mb-0 sm:mr-2",children:"🏥"}),t("span",{class:"font-medium whitespace-nowrap",children:["3,000+",t("br",{class:"sm:hidden"}),"등록시설"]})]}),t("div",{class:"flex flex-col sm:flex-row items-center text-center sm:text-left",children:[t("span",{class:"text-xl md:text-2xl mb-1 sm:mb-0 sm:mr-2",children:"⭐"}),t("span",{class:"font-medium whitespace-nowrap",children:["평균 4.5점",t("br",{class:"sm:hidden"}),"우수"]})]})]})]}),t("div",{class:"relative flex justify-center",children:t("img",{src:"https://page.gensparksite.com/v1/base64_upload/ede67a258a8e3e3dd08f322c99dbeda8",alt:"케어조아 앱",class:"w-64 md:w-80 rounded-3xl shadow-2xl"})})]})})}),t("section",{class:"py-12 md:py-16 bg-gradient-to-br from-teal-500 to-emerald-600",children:t("div",{class:"max-w-4xl mx-auto px-4",children:[t("div",{class:"bg-white rounded-3xl shadow-2xl p-6 md:p-10",children:[t("div",{class:"text-center mb-6 md:mb-8",children:[t("div",{class:"inline-block bg-gradient-to-r from-orange-400 to-red-500 text-white text-xs md:text-sm font-bold px-4 py-2 rounded-full mb-4 animate-pulse",children:"⚡ 30초 만에 견적 받기"}),t("h3",{class:"text-2xl md:text-4xl font-bold text-gray-900 mb-3",children:"무료 맞춤 견적 신청"}),t("p",{class:"text-sm md:text-lg text-gray-600",children:["간단한 정보만 입력하시면 ",t("strong",{class:"text-teal-600",children:"전문 상담사"}),"가 직접 연락드립니다"]})]}),t("form",{id:"quickEstimateForm",class:"space-y-4 md:space-y-6",children:[t("div",{class:"grid md:grid-cols-2 gap-4 md:gap-6",children:[t("div",{children:[t("label",{class:"block text-sm font-semibold text-gray-700 mb-2",children:[t("i",{class:"fas fa-user text-teal-500 mr-2"}),"보호자 성함*"]}),t("input",{type:"text",id:"quickName",required:!0,class:"w-full p-3 md:p-4 border-2 border-gray-200 rounded-xl focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all",placeholder:"홍길동"})]}),t("div",{children:[t("label",{class:"block text-sm font-semibold text-gray-700 mb-2",children:[t("i",{class:"fas fa-phone text-teal-500 mr-2"}),"연락처*"]}),t("input",{type:"tel",id:"quickPhone",required:!0,class:"w-full p-3 md:p-4 border-2 border-gray-200 rounded-xl focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all",placeholder:"010-0000-0000"})]})]}),t("div",{class:"grid md:grid-cols-2 gap-4 md:gap-6",children:[t("div",{children:[t("label",{class:"block text-sm font-semibold text-gray-700 mb-2",children:[t("i",{class:"fas fa-map-marker-alt text-teal-500 mr-2"}),"희망 지역*"]}),t("select",{id:"quickRegion",required:!0,class:"w-full p-3 md:p-4 border-2 border-gray-200 rounded-xl focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all",children:[t("option",{value:"",children:"지역을 선택하세요"}),t("option",{value:"서울",children:"서울특별시"}),t("option",{value:"부산",children:"부산광역시"}),t("option",{value:"대구",children:"대구광역시"}),t("option",{value:"인천",children:"인천광역시"}),t("option",{value:"광주",children:"광주광역시"}),t("option",{value:"대전",children:"대전광역시"}),t("option",{value:"울산",children:"울산광역시"}),t("option",{value:"세종",children:"세종특별자치시"}),t("option",{value:"경기",children:"경기도"}),t("option",{value:"강원",children:"강원특별자치도"}),t("option",{value:"충북",children:"충청북도"}),t("option",{value:"충남",children:"충청남도"}),t("option",{value:"전북",children:"전북특별자치도"}),t("option",{value:"전남",children:"전라남도"}),t("option",{value:"경북",children:"경상북도"}),t("option",{value:"경남",children:"경상남도"}),t("option",{value:"제주",children:"제주특별자치도"})]})]}),t("div",{children:[t("label",{class:"block text-sm font-semibold text-gray-700 mb-2",children:[t("i",{class:"fas fa-hospital text-teal-500 mr-2"}),"원하는 시설"]}),t("select",{id:"quickFacilityType",class:"w-full p-3 md:p-4 border-2 border-gray-200 rounded-xl focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all",children:[t("option",{value:"",children:"아직 모르겠어요"}),t("option",{value:"요양병원",children:"요양병원"}),t("option",{value:"요양원",children:"요양원"}),t("option",{value:"주간보호센터",children:"주간보호센터"}),t("option",{value:"재가복지센터",children:"재가복지센터"})]})]})]}),t("div",{class:"text-center pt-4",children:[t("button",{type:"submit",class:"w-full md:w-auto bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-600 hover:to-emerald-700 text-white text-lg md:text-xl font-bold px-12 md:px-16 py-4 md:py-5 rounded-xl shadow-lg hover:shadow-2xl transform hover:scale-105 transition-all duration-300",onclick:"if(window.trackEvent) trackEvent('quick_estimate_submit', {form_location: 'main_page'})",children:[t("i",{class:"fas fa-paper-plane mr-2"}),"무료 견적 받기 (30초 소요)"]}),t("p",{class:"text-xs md:text-sm text-gray-500 mt-3",children:[t("i",{class:"fas fa-lock mr-1"}),"개인정보는 안전하게 보호되며, 상담 목적으로만 사용됩니다"]})]})]})]}),t("div",{class:"mt-6 md:mt-8 grid grid-cols-3 gap-3 md:gap-4 text-center",children:[t("div",{class:"bg-white bg-opacity-20 backdrop-blur-sm rounded-xl p-3 md:p-4 text-white",children:[t("div",{class:"text-2xl md:text-3xl mb-2",children:"⚡"}),t("div",{class:"text-xs md:text-sm font-semibold",children:"30초 신청"})]}),t("div",{class:"bg-white bg-opacity-20 backdrop-blur-sm rounded-xl p-3 md:p-4 text-white",children:[t("div",{class:"text-2xl md:text-3xl mb-2",children:"💯"}),t("div",{class:"text-xs md:text-sm font-semibold",children:"100% 무료"})]}),t("div",{class:"bg-white bg-opacity-20 backdrop-blur-sm rounded-xl p-3 md:p-4 text-white",children:[t("div",{class:"text-2xl md:text-3xl mb-2",children:"📞"}),t("div",{class:"text-xs md:text-sm font-semibold",children:"즉시 상담"})]})]})]})}),t("div",{class:"fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 shadow-lg z-50 md:hidden",style:"padding-bottom: env(safe-area-inset-bottom);",children:t("div",{class:"flex justify-around items-center py-2 px-1",children:[t("a",{href:"https://www.carejoa.com",target:"_blank",rel:"noopener noreferrer",class:"flex flex-col items-center py-2 px-2 hover:bg-gray-50 rounded-lg transition-colors min-w-0 flex-1",children:[t("div",{class:"text-xl mb-1",children:"📋"}),t("span",{class:"text-[9px] text-gray-700 font-medium whitespace-nowrap",children:"견적상담"})]}),t("button",{onclick:"document.getElementById('regionalCallModal').classList.remove('hidden')",class:"flex flex-col items-center py-2 px-2 hover:bg-gray-50 rounded-lg transition-colors min-w-0 flex-1",children:[t("div",{class:"text-xl mb-1",children:"📞"}),t("span",{class:"text-[9px] text-gray-700 font-medium whitespace-nowrap",children:"전화상담"})]}),t("a",{href:"https://open.kakao.com/o/siR7YBUh",target:"_blank",rel:"noopener noreferrer",class:"flex flex-col items-center py-2 px-2 hover:bg-gray-50 rounded-lg transition-colors min-w-0 flex-1",children:[t("div",{class:"text-xl mb-1",children:"💬"}),t("span",{class:"text-[9px] text-gray-700 font-medium whitespace-nowrap",children:"채팅문의"})]}),t("a",{href:"https://www.carejoa.com",target:"_blank",rel:"noopener noreferrer",class:"flex flex-col items-center py-2 px-2 hover:bg-gray-50 rounded-lg transition-colors min-w-0 flex-1",children:[t("div",{class:"text-xl mb-1",children:"👤"}),t("span",{class:"text-[9px] text-gray-700 font-medium whitespace-nowrap",children:"마이페이지"})]})]})}),t("section",{class:"py-20",children:t("div",{class:"max-w-7xl mx-auto px-4",children:[t("div",{class:"text-center mb-16",children:t("h3",{class:"text-3xl font-bold text-gray-900 mb-4",children:[t("i",{class:"fas fa-certificate text-blue-600 mr-3"}),"케어조아만의 특별함"]})}),t("div",{class:"grid md:grid-cols-4 gap-6",children:[t("div",{class:"text-center p-6 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl",children:[t("div",{class:"w-16 h-16 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4",children:t("i",{class:"fas fa-calculator text-2xl text-white"})}),t("h4",{class:"text-xl font-bold mb-2",children:"실시간 견적"}),t("p",{class:"text-gray-600 text-sm",children:"간단한 정보 입력으로 맞춤형 견적을 즉시 확인"})]}),t("div",{class:"text-center p-6 bg-gradient-to-br from-green-50 to-green-100 rounded-xl",children:[t("div",{class:"w-16 h-16 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4",children:t("i",{class:"fas fa-shield-check text-2xl text-white"})}),t("h4",{class:"text-xl font-bold mb-2",children:"검증된 시설"}),t("p",{class:"text-gray-600 text-sm",children:"정부 인증 및 전문가 방문을 통해 검증"})]}),t("div",{class:"text-center p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl",children:[t("div",{class:"w-16 h-16 bg-gradient-to-r from-purple-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4",children:t("i",{class:"fas fa-user-md text-2xl text-white"})}),t("h4",{class:"text-xl font-bold mb-2",children:"전문 상담"}),t("p",{class:"text-gray-600 text-sm",children:"자격을 보유한 전문 상담사가 24시간 상담"})]}),t("div",{class:"text-center p-6 bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl",children:[t("div",{class:"w-16 h-16 bg-gradient-to-r from-orange-500 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-4",children:t("i",{class:"fas fa-heart text-2xl text-white"})}),t("h4",{class:"text-xl font-bold mb-2",children:"가족 같은 마음"}),t("p",{class:"text-gray-600 text-sm",children:"믿을 수 있는 곳을 찾기까지 끝까지 함께"})]})]})]})}),t("section",{class:"py-20 bg-gray-50",children:t("div",{class:"max-w-7xl mx-auto px-4",children:[t("div",{class:"text-center mb-16",children:t("h3",{class:"text-3xl font-bold text-gray-900 mb-4",children:["간단한 3단계로 ",t("span",{class:"text-teal-600",children:"완료!"})]})}),t("div",{class:"grid md:grid-cols-3 gap-8",children:[t("div",{class:"text-center relative",children:[t("div",{class:"w-20 h-20 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6",children:t("span",{class:"text-2xl font-bold text-white",children:"1"})}),t("h4",{class:"text-xl font-bold mb-4",children:"정보 입력"}),t("p",{class:"text-gray-600",children:"어르신의 기본 정보와 필요한 서비스를 입력"})]}),t("div",{class:"text-center relative",children:[t("div",{class:"w-20 h-20 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-6",children:t("span",{class:"text-2xl font-bold text-white",children:"2"})}),t("h4",{class:"text-xl font-bold mb-4",children:"견적 비교"}),t("p",{class:"text-gray-600",children:"실시간으로 매칭된 시설들을 비교"})]}),t("div",{class:"text-center",children:[t("div",{class:"w-20 h-20 bg-gradient-to-r from-purple-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6",children:t("span",{class:"text-2xl font-bold text-white",children:"3"})}),t("h4",{class:"text-xl font-bold mb-4",children:"전문 상담"}),t("p",{class:"text-gray-600",children:"전문 상담사와 1:1 맞춤 상담"})]})]})]})}),t("section",{class:"py-16 md:py-20 bg-white",children:t("div",{class:"max-w-7xl mx-auto px-4",children:[t("div",{class:"text-center mb-12 md:mb-16",children:[t("div",{class:"inline-block bg-gradient-to-r from-yellow-400 to-orange-500 text-white text-xs md:text-sm font-bold px-4 py-2 rounded-full mb-4",children:"⭐ 실제 이용 고객님들의 생생한 후기"}),t("h3",{class:"text-2xl md:text-4xl font-bold text-gray-900 mb-4",children:["케어조아와 함께한 ",t("span",{class:"text-teal-600",children:"따뜻한 이야기"})]}),t("p",{class:"text-sm md:text-lg text-gray-600",children:"10만 명 이상의 고객님들이 케어조아를 통해 최적의 요양시설을 찾으셨습니다"})]}),t("div",{class:"grid md:grid-cols-3 gap-6 md:gap-8",children:[t("div",{class:"bg-gradient-to-br from-blue-50 to-white rounded-2xl p-6 md:p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2",children:[t("div",{class:"flex items-center mb-4",children:[t("div",{class:"flex text-yellow-400 text-xl md:text-2xl",children:[t("i",{class:"fas fa-star"}),t("i",{class:"fas fa-star"}),t("i",{class:"fas fa-star"}),t("i",{class:"fas fa-star"}),t("i",{class:"fas fa-star"})]}),t("span",{class:"ml-2 text-sm md:text-base font-bold text-gray-700",children:"5.0"})]}),t("p",{class:"text-sm md:text-base text-gray-700 leading-relaxed mb-6",children:'"어머니께 맞는 요양원을 찾느라 몇 달을 고민했는데, 케어조아 덕분에 단 3일 만에 완벽한 곳을 찾았습니다. 상담사님이 정말 친절하고 전문적이셨어요. 어머니도 너무 만족하고 계십니다."'}),t("div",{class:"flex items-center",children:[t("div",{class:"w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-lg",children:"김"}),t("div",{class:"ml-3",children:[t("div",{class:"font-bold text-gray-900",children:"김민지 님"}),t("div",{class:"text-xs md:text-sm text-gray-500",children:"서울 강남구 · 요양원"})]})]})]}),t("div",{class:"bg-gradient-to-br from-green-50 to-white rounded-2xl p-6 md:p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2",children:[t("div",{class:"flex items-center mb-4",children:[t("div",{class:"flex text-yellow-400 text-xl md:text-2xl",children:[t("i",{class:"fas fa-star"}),t("i",{class:"fas fa-star"}),t("i",{class:"fas fa-star"}),t("i",{class:"fas fa-star"}),t("i",{class:"fas fa-star"})]}),t("span",{class:"ml-2 text-sm md:text-base font-bold text-gray-700",children:"5.0"})]}),t("p",{class:"text-sm md:text-base text-gray-700 leading-relaxed mb-6",children:'"여러 요양병원을 직접 방문하는 것도 힘들고 비교하기도 어려웠는데, 케어조아에서 한 번에 비교하고 견적까지 받을 수 있어서 너무 편했습니다. 시간과 비용을 많이 절약했어요!"'}),t("div",{class:"flex items-center",children:[t("div",{class:"w-12 h-12 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center text-white font-bold text-lg",children:"이"}),t("div",{class:"ml-3",children:[t("div",{class:"font-bold text-gray-900",children:"이정훈 님"}),t("div",{class:"text-xs md:text-sm text-gray-500",children:"부산 해운대구 · 요양병원"})]})]})]}),t("div",{class:"bg-gradient-to-br from-purple-50 to-white rounded-2xl p-6 md:p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2",children:[t("div",{class:"flex items-center mb-4",children:[t("div",{class:"flex text-yellow-400 text-xl md:text-2xl",children:[t("i",{class:"fas fa-star"}),t("i",{class:"fas fa-star"}),t("i",{class:"fas fa-star"}),t("i",{class:"fas fa-star"}),t("i",{class:"fas fa-star"})]}),t("span",{class:"ml-2 text-sm md:text-base font-bold text-gray-700",children:"5.0"})]}),t("p",{class:"text-sm md:text-base text-gray-700 leading-relaxed mb-6",children:'"처음에는 온라인으로 이런 중요한 결정을 하는 게 걱정됐는데, 상담사님이 직접 시설을 방문한 경험을 바탕으로 상세하게 설명해주셔서 안심이 되었습니다. 정말 감사드립니다."'}),t("div",{class:"flex items-center",children:[t("div",{class:"w-12 h-12 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg",children:"박"}),t("div",{class:"ml-3",children:[t("div",{class:"font-bold text-gray-900",children:"박수진 님"}),t("div",{class:"text-xs md:text-sm text-gray-500",children:"경기 성남시 · 주간보호센터"})]})]})]})]}),t("div",{class:"mt-12 md:mt-16 bg-gradient-to-r from-teal-500 to-emerald-600 rounded-2xl p-6 md:p-10",children:t("div",{class:"grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 text-center text-white",children:[t("div",{children:[t("div",{class:"text-3xl md:text-5xl font-bold mb-2",children:["4.8",t("span",{class:"text-2xl md:text-3xl",children:"/5.0"})]}),t("div",{class:"text-xs md:text-sm opacity-90",children:"평균 만족도"})]}),t("div",{children:[t("div",{class:"text-3xl md:text-5xl font-bold mb-2",children:"10만+"}),t("div",{class:"text-xs md:text-sm opacity-90",children:"누적 이용자"})]}),t("div",{children:[t("div",{class:"text-3xl md:text-5xl font-bold mb-2",children:"3,000+"}),t("div",{class:"text-xs md:text-sm opacity-90",children:"등록 시설"})]}),t("div",{children:[t("div",{class:"text-3xl md:text-5xl font-bold mb-2",children:"95%"}),t("div",{class:"text-xs md:text-sm opacity-90",children:"재이용 의향"})]})]})})]})}),t("section",{class:"py-12 bg-white",children:t("div",{class:"max-w-7xl mx-auto px-4",children:t("div",{class:"flex justify-center",children:t("a",{href:"https://youtu.be/lUQkWC8PRrM?si=l-AOOz72I0z0oWE1",target:"_blank",rel:"noopener noreferrer",class:"group relative block rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 w-full max-w-sm",children:[t("img",{src:"https://img.youtube.com/vi/lUQkWC8PRrM/hqdefault.jpg",alt:"케어조아 소개 영상",class:"w-full h-auto"}),t("div",{class:"absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-300 flex items-center justify-center",children:t("div",{class:"w-16 h-16 bg-red-600 rounded-full flex items-center justify-center opacity-90 group-hover:opacity-100 transition-opacity",children:t("i",{class:"fas fa-play text-white text-2xl ml-1"})})}),t("div",{class:"absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4",children:t("p",{class:"text-white text-sm font-semibold",children:[t("i",{class:"fab fa-youtube text-red-500 mr-2"}),"케어조아 소개 영상 보기"]})})]})})})}),t("section",{id:"partner-section",class:"py-20 bg-gradient-to-br from-teal-50 to-emerald-50",children:t("div",{class:"max-w-7xl mx-auto px-4",children:[t("div",{class:"text-center mb-12",children:[t("h3",{class:"text-3xl font-bold text-gray-900 mb-4",children:[t("i",{class:"fas fa-handshake text-teal-600 mr-3"}),"요양시설 및 관련기관 입점신청"]}),t("p",{class:"text-lg text-gray-600",children:"케어조아와 함께 더 많은 고객을 만나보세요"})]}),t("div",{class:"bg-white p-8 rounded-2xl shadow-lg max-w-4xl mx-auto",children:t("form",{id:"partnerForm",class:"space-y-6",children:[t("div",{class:"grid md:grid-cols-2 gap-6",children:[t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-building mr-1 text-blue-500"}),"시설명*"]}),t("input",{type:"text",id:"facilityName",required:!0,class:"w-full p-3 border rounded-lg",placeholder:"시설/서비스명"})]}),t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-tag mr-1 text-purple-500"}),"시설 유형*"]}),t("select",{id:"facilityType",required:!0,class:"w-full p-3 border rounded-lg",children:[t("option",{value:"",children:"선택하세요"}),t("option",{value:"상급종합병원",children:"상급종합병원"}),t("option",{value:"주민센터사회복지",children:"주민센터사회복지"}),t("option",{value:"요양원",children:"요양원"}),t("option",{value:"요양병원",children:"요양병원"}),t("option",{value:"주간보호센터",children:"주간보호센터"}),t("option",{value:"그룹홈",children:"그룹홈"}),t("option",{value:"재가복지센터",children:"재가복지센터"}),t("option",{value:"한의사왕진서비스",children:"한의사왕진서비스"}),t("option",{value:"기타",children:"기타"})]})]})]}),t("div",{class:"border-t pt-6",children:[t("h4",{class:"text-lg font-semibold text-gray-900 mb-4",children:[t("i",{class:"fas fa-map-marker-alt mr-2 text-red-500"}),"시설 주소"]}),t("div",{class:"grid md:grid-cols-2 gap-6 mb-4",children:[t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-map mr-1 text-blue-500"}),"시/도*"]}),t("select",{id:"facilitySido",required:!0,class:"w-full p-3 border rounded-lg",children:t("option",{value:"",children:"시/도를 선택하세요"})})]}),t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-map-marker mr-1 text-green-500"}),"시/군/구*"]}),t("select",{id:"facilitySigungu",required:!0,class:"w-full p-3 border rounded-lg",disabled:!0,children:t("option",{value:"",children:"시/군/구를 선택하세요"})})]})]}),t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-home mr-1 text-purple-500"}),"상세주소*"]}),t("input",{type:"text",id:"facilityAddress",required:!0,class:"w-full p-3 border rounded-lg",placeholder:"예: 강남대로 123, 케어빌딩 2층"})]})]}),t("div",{class:"grid md:grid-cols-2 gap-6",children:[t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-user mr-1 text-green-500"}),"담당자명*"]}),t("input",{type:"text",id:"managerName",required:!0,class:"w-full p-3 border rounded-lg"})]}),t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-phone mr-1 text-purple-500"}),"연락처*"]}),t("input",{type:"tel",id:"managerPhone",required:!0,class:"w-full p-3 border rounded-lg",placeholder:"010-0000-0000"})]})]}),t("div",{class:"text-center pt-6",children:t("button",{type:"submit",class:"bg-gradient-to-r from-teal-600 to-emerald-600 text-white px-12 py-4 rounded-lg hover:from-teal-700 hover:to-emerald-700 transform hover:scale-105 font-bold",children:[t("i",{class:"fas fa-handshake mr-2"}),"요양시설 및 관련기관 입점신청"]})})]})})]})}),t("footer",{class:"bg-gray-900 text-white py-12",children:t("div",{class:"max-w-7xl mx-auto px-4",children:[t("div",{class:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8",children:[t("div",{children:[t("h4",{class:"text-lg font-bold mb-4 flex items-center",children:[t("i",{class:"fas fa-heart mr-2 text-teal-400"}),"케어조아"]}),t("p",{class:"text-gray-400 text-sm",children:"내 집처럼 편안한 곳, 내 가족처럼 믿을 수 있는 곳"})]}),t("div",{children:[t("h5",{class:"font-semibold mb-4",children:"서비스"}),t("ul",{class:"space-y-2 text-sm text-gray-400",children:[t("li",{children:"실시간 견적"}),t("li",{children:"시설 검색"}),t("li",{children:"전문 상담"}),t("li",{children:"파트너 등록"})]})]}),t("div",{children:[t("h5",{class:"font-semibold mb-4",children:"고객지원"}),t("ul",{class:"space-y-3 text-sm text-gray-400",children:[t("li",{class:"flex items-center",children:[t("i",{class:"fas fa-phone mr-2 text-teal-400"}),t("a",{href:"tel:0507-1310-5873",children:"0507-1310-5873"})]}),t("li",{children:t("a",{href:"https://open.kakao.com/o/siR7YBUh",target:"_blank",class:"flex items-center",children:[t("i",{class:"fas fa-comment-dots mr-2 text-yellow-400"}),"카카오톡 상담"]})}),t("li",{class:"flex items-center",children:[t("i",{class:"fas fa-envelope mr-2 text-blue-400"}),"utuber@kakao.com"]})]})]}),t("div",{children:[t("h5",{class:"font-semibold mb-4",children:"앱 다운로드"}),t("div",{class:"space-y-3",children:[t("a",{href:"https://play.google.com/store/apps/details?id=app.netlify.std_care_joa.twa",target:"_blank",class:"flex items-center text-sm text-gray-400",children:[t("i",{class:"fab fa-android mr-2 text-green-400"}),"안드로이드 앱"]}),t("a",{href:"https://www.carejoa.com",target:"_blank",class:"flex items-center text-sm text-gray-400",children:[t("i",{class:"fas fa-globe mr-2 text-blue-400"}),"웹 서비스"]})]})]})]}),t("div",{class:"border-t border-gray-800 mt-8 pt-8 text-center",children:[t("p",{class:"text-sm text-blue-400 font-medium mb-3",children:[t("i",{class:"fas fa-certificate mr-1"}),"특허기반 실시간 요양 견적 및 상담 플랫폼"]}),t("p",{class:"text-xs text-gray-400",children:"© 2024 케어조아. All rights reserved."})]})]})}),t("a",{href:"https://open.kakao.com/o/siR7YBUh",target:"_blank",rel:"noopener noreferrer",class:"fixed bottom-20 md:bottom-6 right-4 md:right-6 z-40 bg-yellow-400 hover:bg-yellow-500 text-gray-900 w-14 h-14 md:w-16 md:h-16 rounded-full shadow-2xl flex items-center justify-center transition-all duration-300 transform hover:scale-110 group",onclick:"if(window.trackEvent) trackEvent('kakao_chat_click', {location: 'floating_button'})",children:[t("i",{class:"fas fa-comment-dots text-2xl md:text-3xl"}),t("span",{class:"absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full animate-pulse",children:"1:1"}),t("div",{class:"absolute bottom-full right-0 mb-2 px-3 py-2 bg-gray-900 text-white text-sm rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none",children:["카카오톡 상담",t("div",{class:"absolute top-full right-4 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"})]})]}),t("div",{id:"regionalCallModal",class:"hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4",children:t("div",{class:"bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto",children:[t("div",{class:"sticky top-0 bg-gradient-to-r from-green-500 to-emerald-500 text-white p-6 rounded-t-2xl",children:[t("div",{class:"flex justify-between items-center",children:[t("h3",{class:"text-2xl font-bold",children:[t("i",{class:"fas fa-phone-alt mr-2"}),"지역별 전화상담"]}),t("button",{onclick:"document.getElementById('regionalCallModal').classList.add('hidden')",class:"text-white hover:text-gray-200 text-2xl",children:t("i",{class:"fas fa-times"})})]}),t("p",{class:"text-green-100 mt-2",children:"내 지역의 대표 상담센터와 직접 통화하세요"})]}),t("div",{class:"p-6 space-y-6",children:[t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-map-marker-alt mr-1 text-green-500"}),"시/도 선택"]}),t("select",{id:"sidoSelect",class:"w-full p-3 border rounded-lg focus:ring-2 focus:ring-green-500",children:t("option",{value:"",children:"시/도를 선택하세요"})})]}),t("div",{id:"sigunguContainer",class:"hidden",children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-map-marker-alt mr-1 text-emerald-500"}),"시/군/구 선택"]}),t("select",{id:"sigunguSelect",class:"w-full p-3 border rounded-lg focus:ring-2 focus:ring-green-500",children:t("option",{value:"",children:"시/군/구를 선택하세요"})})]}),t("div",{id:"centerListContainer",class:"hidden",children:[t("h4",{class:"text-lg font-bold text-gray-900 mb-4",children:[t("i",{class:"fas fa-building mr-2 text-green-600"}),"대표 상담센터"]}),t("div",{id:"centerList",class:"space-y-3"})]}),t("div",{id:"noResultMessage",class:"hidden",children:t("div",{class:"bg-yellow-50 border border-yellow-200 rounded-lg p-4",children:t("p",{class:"text-yellow-800 text-center",children:[t("i",{class:"fas fa-info-circle mr-2"}),"해당 지역에 등록된 상담센터가 없습니다.",t("br",{}),"전체 상담은 ",t("a",{href:"tel:02-6677-4915",class:"text-blue-600 font-bold underline",children:"02-6677-4915"}),"로 연락주세요."]})})})]})]})}),t("script",{dangerouslySetInnerHTML:{__html:`
        // 전국 시도 및 시군구 데이터
        const regionData = {
          "서울특별시": ["강남구", "강동구", "강북구", "강서구", "관악구", "광진구", "구로구", "금천구", "노원구", "도봉구", "동대문구", "동작구", "마포구", "서대문구", "서초구", "성동구", "성북구", "송파구", "양천구", "영등포구", "용산구", "은평구", "종로구", "중구", "중랑구"],
          "부산광역시": ["강서구", "금정구", "기장군", "남구", "동구", "동래구", "부산진구", "북구", "사상구", "사하구", "서구", "수영구", "연제구", "영도구", "중구", "해운대구"],
          "대구광역시": ["남구", "달서구", "달성군", "동구", "북구", "서구", "수성구", "중구"],
          "인천광역시": ["강화군", "계양구", "남동구", "동구", "미추홀구", "부평구", "서구", "연수구", "옹진군", "중구"],
          "광주광역시": ["광산구", "남구", "동구", "북구", "서구"],
          "대전광역시": ["대덕구", "동구", "서구", "유성구", "중구"],
          "울산광역시": ["남구", "동구", "북구", "울주군", "중구"],
          "세종특별자치시": ["세종시"],
          "경기도": ["가평군", "고양시", "과천시", "광명시", "광주시", "구리시", "군포시", "김포시", "남양주시", "동두천시", "부천시", "성남시", "수원시", "시흥시", "안산시", "안성시", "안양시", "양주시", "양평군", "여주시", "연천군", "오산시", "용인시", "의왕시", "의정부시", "이천시", "파주시", "평택시", "포천시", "하남시", "화성시"],
          "강원도": ["강릉시", "고성군", "동해시", "삼척시", "속초시", "양구군", "양양군", "영월군", "원주시", "인제군", "정선군", "철원군", "춘천시", "태백시", "평창군", "홍천군", "화천군", "횡성군"],
          "충청북도": ["괴산군", "단양군", "보은군", "영동군", "옥천군", "음성군", "제천시", "증평군", "진천군", "청주시", "충주시"],
          "충청남도": ["계룡시", "공주시", "금산군", "논산시", "당진시", "보령시", "부여군", "서산시", "서천군", "아산시", "예산군", "천안시", "청양군", "태안군", "홍성군"],
          "전라북도": ["고창군", "군산시", "김제시", "남원시", "무주군", "부안군", "순창군", "완주군", "익산시", "임실군", "장수군", "전주시", "정읍시", "진안군"],
          "전라남도": ["강진군", "고흥군", "곡성군", "광양시", "구례군", "나주시", "담양군", "목포시", "무안군", "보성군", "순천시", "신안군", "여수시", "영광군", "영암군", "완도군", "장성군", "장흥군", "진도군", "함평군", "해남군", "화순군"],
          "경상북도": ["경산시", "경주시", "고령군", "구미시", "군위군", "김천시", "문경시", "봉화군", "상주시", "성주군", "안동시", "영덕군", "영양군", "영주시", "영천시", "예천군", "울릉군", "울진군", "의성군", "청도군", "청송군", "칠곡군", "포항시"],
          "경상남도": ["거제시", "거창군", "고성군", "김해시", "남해군", "밀양시", "사천시", "산청군", "양산시", "의령군", "진주시", "창녕군", "창원시", "통영시", "하동군", "함안군", "함양군", "합천군"],
          "제주특별자치도": ["서귀포시", "제주시"]
        };

        // 시도 선택 옵션 생성
        const sidoSelect = document.getElementById('sidoSelect');
        Object.keys(regionData).forEach(sido => {
          const option = document.createElement('option');
          option.value = sido;
          option.textContent = sido;
          sidoSelect.appendChild(option);
        });

        // 시도 선택 시 시군구 로드
        sidoSelect.addEventListener('change', function() {
          const sigunguContainer = document.getElementById('sigunguContainer');
          const sigunguSelect = document.getElementById('sigunguSelect');
          const sido = this.value;
          
          // 이전 선택 초기화
          sigunguSelect.innerHTML = '<option value="">시/군/구를 선택하세요</option>';
          document.getElementById('centerListContainer').classList.add('hidden');
          document.getElementById('noResultMessage').classList.add('hidden');
          
          if (sido) {
            sigunguContainer.classList.remove('hidden');
            regionData[sido].forEach(sigungu => {
              const option = document.createElement('option');
              option.value = sigungu;
              option.textContent = sigungu;
              sigunguSelect.appendChild(option);
            });
          } else {
            sigunguContainer.classList.add('hidden');
          }
        });

        // 시군구 선택 시 상담센터 로드
        document.getElementById('sigunguSelect').addEventListener('change', async function() {
          const sido = sidoSelect.value;
          const sigungu = this.value;
          
          if (!sido || !sigungu) return;
          
          const regionKey = sido + '_' + sigungu;
          
          try {
            const response = await axios.get('/api/regional-centers?region=' + encodeURIComponent(regionKey));
            const centers = response.data.centers || [];
            
            const centerListContainer = document.getElementById('centerListContainer');
            const centerList = document.getElementById('centerList');
            const noResultMessage = document.getElementById('noResultMessage');
            
            if (centers.length > 0) {
              centerList.innerHTML = centers.map(center => \`
                <div class="bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-xl p-4 hover:shadow-lg transition-shadow">
                  <div class="flex items-start justify-between">
                    <div class="flex-1">
                      <h5 class="font-bold text-lg text-gray-900 mb-2">
                        <i class="fas fa-building text-green-600 mr-2"></i>\${center.facilityName}
                      </h5>
                      <p class="text-sm text-gray-600 mb-3">
                        <i class="fas fa-tag text-purple-500 mr-1"></i>\${center.facilityType}
                      </p>
                      <div class="flex items-center mb-2">
                        <i class="fas fa-user text-blue-500 mr-2"></i>
                        <span class="text-sm text-gray-700">\${center.managerName}</span>
                      </div>
                    </div>
                    <a href="tel:\${center.managerPhone}" 
                       class="bg-gradient-to-r from-green-500 to-emerald-500 text-white px-6 py-3 rounded-lg hover:from-green-600 hover:to-emerald-600 transform hover:scale-105 transition-all shadow-md flex items-center">
                      <i class="fas fa-phone-alt mr-2"></i>
                      <span class="font-bold">\${center.managerPhone}</span>
                    </a>
                  </div>
                </div>
              \`).join('');
              centerListContainer.classList.remove('hidden');
              noResultMessage.classList.add('hidden');
            } else {
              centerListContainer.classList.add('hidden');
              noResultMessage.classList.remove('hidden');
            }
          } catch (error) {
            console.error('상담센터 로드 실패:', error);
            document.getElementById('centerListContainer').classList.add('hidden');
            document.getElementById('noResultMessage').classList.remove('hidden');
          }
        });

        // 시설 입점 폼 - 시도 옵션 생성
        const facilitySidoSelect = document.getElementById('facilitySido');
        Object.keys(regionData).forEach(sido => {
          const option = document.createElement('option');
          option.value = sido;
          option.textContent = sido;
          facilitySidoSelect.appendChild(option);
        });

        // 시설 입점 폼 - 시도 선택 시 시군구 로드
        facilitySidoSelect.addEventListener('change', function() {
          const facilitySigunguSelect = document.getElementById('facilitySigungu');
          const sido = this.value;
          
          facilitySigunguSelect.innerHTML = '<option value="">시/군/구를 선택하세요</option>';
          
          if (sido) {
            facilitySigunguSelect.disabled = false;
            regionData[sido].forEach(sigungu => {
              const option = document.createElement('option');
              option.value = sigungu;
              option.textContent = sigungu;
              facilitySigunguSelect.appendChild(option);
            });
          } else {
            facilitySigunguSelect.disabled = true;
          }
        });

        // 파트너 폼 제출
        document.getElementById('partnerForm').addEventListener('submit', async (e) => {
          e.preventDefault();
          const data = {
            facilityName: document.getElementById('facilityName').value,
            facilityType: document.getElementById('facilityType').value,
            facilitySido: document.getElementById('facilitySido').value,
            facilitySigungu: document.getElementById('facilitySigungu').value,
            facilityAddress: document.getElementById('facilityAddress').value,
            managerName: document.getElementById('managerName').value,
            managerPhone: document.getElementById('managerPhone').value,
          };
          
          try {
            const response = await axios.post('/api/partner', data);
            alert(response.data.message);
            e.target.reset();
            document.getElementById('facilitySigungu').disabled = true;
          } catch (error) {
            alert('신청 중 오류가 발생했습니다.');
          }
        });
        `}})]})));T.get("/family-care-register",e=>e.render(t("div",{children:[t("header",{class:"bg-white shadow-sm border-b",children:t("div",{class:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:t("div",{class:"flex justify-between items-center h-16",children:[t("a",{href:"/",class:"flex items-center",children:[t("img",{src:"https://page.gensparksite.com/v1/base64_upload/b39dca8586af1dacd6d8417554313896",alt:"케어조아 로고",class:"h-8 w-auto mr-3"}),t("h1",{class:"text-2xl font-bold text-teal-600",children:"케어조아"})]}),t("a",{href:"/",class:"text-gray-600 hover:text-gray-900",children:[t("i",{class:"fas fa-home mr-1"}),"홈으로"]})]})})}),t("section",{class:"py-16 bg-gradient-to-br from-green-50 to-emerald-50 min-h-screen",children:t("div",{class:"max-w-4xl mx-auto px-4",children:[t("div",{class:"text-center mb-12",children:[t("h2",{class:"text-4xl font-bold text-gray-900 mb-4",children:[t("i",{class:"fas fa-heart text-green-600 mr-3"}),"가족 간병 등록"]}),t("p",{class:"text-lg text-gray-600",children:"우리 가족을 위한 최적의 간병 서비스를 찾아드립니다"})]}),t("div",{class:"bg-white p-8 rounded-2xl shadow-lg",children:t("form",{id:"familyCareForm",class:"space-y-6",children:[t("div",{class:"grid md:grid-cols-2 gap-6",children:[t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-user mr-1 text-blue-500"}),"보호자 이름*"]}),t("input",{type:"text",id:"guardianName",required:!0,class:"w-full p-3 border rounded-lg"})]}),t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-phone mr-1 text-green-500"}),"연락처*"]}),t("input",{type:"tel",id:"guardianPhone",required:!0,class:"w-full p-3 border rounded-lg",placeholder:"010-0000-0000"})]})]}),t("div",{class:"grid md:grid-cols-2 gap-6",children:[t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-user-injured mr-1 text-purple-500"}),"환자 이름*"]}),t("input",{type:"text",id:"patientName",required:!0,class:"w-full p-3 border rounded-lg"})]}),t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-calendar mr-1 text-orange-500"}),"환자 나이*"]}),t("input",{type:"number",id:"patientAge",required:!0,class:"w-full p-3 border rounded-lg",placeholder:"예: 75"})]})]}),t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-map-marker-alt mr-1 text-red-500"}),"지역*"]}),t("input",{type:"text",id:"region",required:!0,class:"w-full p-3 border rounded-lg",placeholder:"예: 서울시 강남구"})]}),t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-notes-medical mr-1 text-teal-500"}),"상세 요청사항"]}),t("textarea",{id:"requirements",rows:"4",class:"w-full p-3 border rounded-lg",placeholder:"필요한 간병 서비스나 특별한 요구사항을 적어주세요"})]}),t("div",{class:"text-center pt-6",children:t("button",{type:"submit",class:"bg-gradient-to-r from-green-600 to-emerald-600 text-white px-12 py-4 rounded-lg hover:from-green-700 hover:to-emerald-700 transform hover:scale-105 font-bold",children:[t("i",{class:"fas fa-heart mr-2"}),"가족 간병 등록 신청"]})})]})})]})}),t("script",{dangerouslySetInnerHTML:{__html:`
        document.getElementById('familyCareForm').addEventListener('submit', async (e) => {
          e.preventDefault();
          const data = {
            guardianName: document.getElementById('guardianName').value,
            guardianPhone: document.getElementById('guardianPhone').value,
            patientName: document.getElementById('patientName').value,
            patientAge: document.getElementById('patientAge').value,
            region: document.getElementById('region').value,
            requirements: document.getElementById('requirements').value,
          };
          
          try {
            const response = await axios.post('/api/family-care', data);
            alert(response.data.message);
            window.location.href = '/';
          } catch (error) {
            alert('등록 중 오류가 발생했습니다.');
          }
        });
        `}})]})));T.get("/facilities",e=>e.render(t("div",{children:[t("link",{rel:"stylesheet",href:"https://unpkg.com/leaflet@1.9.4/dist/leaflet.css",integrity:"sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=",crossorigin:""}),t("script",{src:"https://unpkg.com/leaflet@1.9.4/dist/leaflet.js",integrity:"sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=",crossorigin:""}),t("header",{class:"bg-white shadow-sm border-b sticky top-0 z-10",children:t("div",{class:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:t("div",{class:"flex justify-between items-center h-16",children:[t("a",{href:"/",class:"flex items-center",children:[t("img",{src:"https://page.gensparksite.com/v1/base64_upload/b39dca8586af1dacd6d8417554313896",alt:"케어조아 로고",class:"h-8 w-auto mr-3"}),t("h1",{class:"text-2xl font-bold text-teal-600",children:"케어조아"})]}),t("a",{href:"/",class:"text-gray-600 hover:text-gray-900",children:[t("i",{class:"fas fa-home mr-1"}),"홈으로"]})]})})}),t("section",{class:"min-h-screen bg-gray-50 py-8",children:t("div",{class:"max-w-7xl mx-auto px-4",children:[t("div",{class:"text-center mb-8",children:[t("h2",{class:"text-4xl font-bold text-gray-900 mb-4",children:[t("i",{class:"fas fa-search-location text-purple-600 mr-3"}),"전국 요양시설 찾기"]}),t("p",{class:"text-lg text-gray-600",id:"facilityCountHeader",children:"전국 요양시설 정보를 확인하세요"})]}),t("div",{class:"bg-white rounded-xl shadow-lg p-6 mb-6",children:[t("div",{class:"grid md:grid-cols-4 gap-4",children:[t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-map-marker-alt mr-1 text-blue-500"}),"시/도"]}),t("select",{id:"filterSido",class:"w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500",children:t("option",{value:"",children:"전체"})})]}),t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-map-marker-alt mr-1 text-green-500"}),"시/군/구"]}),t("select",{id:"filterSigungu",class:"w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500",disabled:!0,children:t("option",{value:"",children:"전체"})})]}),t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-hospital mr-1 text-purple-500"}),"시설 유형"]}),t("select",{id:"filterType",class:"w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500",children:[t("option",{value:"",children:"전체"}),t("option",{value:"요양병원",children:"요양병원"}),t("option",{value:"요양원",children:"요양원"}),t("option",{value:"재가복지센터",children:"재가복지센터"}),t("option",{value:"주야간보호",children:"주야간보호"})]})]}),t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-search mr-1 text-orange-500"}),"시설명 검색"]}),t("input",{type:"text",id:"searchKeyword",class:"w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500",placeholder:"시설명 입력"})]})]}),t("div",{class:"flex gap-3 mt-4",children:[t("button",{onclick:"searchFacilities()",class:"flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-lg hover:from-purple-700 hover:to-pink-700 font-bold",children:[t("i",{class:"fas fa-search mr-2"}),"검색"]}),t("button",{onclick:"resetSearch()",class:"px-6 bg-gray-500 text-white py-3 rounded-lg hover:bg-gray-600 font-bold",children:[t("i",{class:"fas fa-redo mr-2"}),"초기화"]})]})]}),t("div",{class:"bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl p-4 mb-6",children:t("div",{class:"flex items-center justify-between",children:[t("div",{children:[t("p",{class:"text-purple-100 text-sm",children:"검색 결과"}),t("p",{class:"text-3xl font-bold",id:"resultCount",children:"0"})]}),t("i",{class:"fas fa-hospital text-5xl text-purple-200"})]})}),t("div",{class:"grid lg:grid-cols-2 gap-6",children:[t("div",{class:"bg-white rounded-xl shadow-lg overflow-hidden",children:[t("div",{class:"bg-gradient-to-r from-purple-600 to-pink-600 text-white p-4",children:t("h3",{class:"text-xl font-bold",children:[t("i",{class:"fas fa-list mr-2"}),"시설 목록"]})}),t("div",{id:"facilityList",class:"h-[600px] overflow-y-auto p-4",children:t("div",{class:"text-center text-gray-500 py-20",children:[t("i",{class:"fas fa-search text-6xl mb-4"}),t("p",{class:"text-lg font-medium",children:["검색 조건을 선택하고",t("br",{}),"검색 버튼을 클릭하세요"]})]})})]}),t("div",{class:"bg-white rounded-xl shadow-lg overflow-hidden",children:[t("div",{class:"bg-gradient-to-r from-purple-600 to-pink-600 text-white p-4",children:t("h3",{class:"text-xl font-bold",children:[t("i",{class:"fas fa-map-marked-alt mr-2"}),"지도로 보기"]})}),t("div",{id:"map",class:"w-full h-[600px] bg-gray-100"})]})]}),t("div",{id:"loadingSpinner",class:"hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center",children:t("div",{class:"bg-white rounded-xl p-8 text-center",children:[t("div",{class:"animate-spin rounded-full h-16 w-16 border-b-4 border-purple-600 mx-auto mb-4"}),t("p",{class:"text-lg font-bold text-gray-900",children:"데이터 로딩 중..."}),t("p",{class:"text-sm text-gray-600 mt-2",children:"잠시만 기다려주세요"})]})})]})}),t("script",{dangerouslySetInnerHTML:{__html:`
        // 전국 시도 및 시군구 데이터
        const regionData = {
          "서울특별시": ["강남구", "강동구", "강북구", "강서구", "관악구", "광진구", "구로구", "금천구", "노원구", "도봉구", "동대문구", "동작구", "마포구", "서대문구", "서초구", "성동구", "성북구", "송파구", "양천구", "영등포구", "용산구", "은평구", "종로구", "중구", "중랑구"],
          "부산광역시": ["강서구", "금정구", "기장군", "남구", "동구", "동래구", "부산진구", "북구", "사상구", "사하구", "서구", "수영구", "연제구", "영도구", "중구", "해운대구"],
          "대구광역시": ["남구", "달서구", "달성군", "동구", "북구", "서구", "수성구", "중구"],
          "인천광역시": ["강화군", "계양구", "남동구", "동구", "미추홀구", "부평구", "서구", "연수구", "옹진군", "중구"],
          "광주광역시": ["광산구", "남구", "동구", "북구", "서구"],
          "대전광역시": ["대덕구", "동구", "서구", "유성구", "중구"],
          "울산광역시": ["남구", "동구", "북구", "울주군", "중구"],
          "세종특별자치시": ["세종시"],
          "경기도": ["가평군", "고양시", "과천시", "광명시", "광주시", "구리시", "군포시", "김포시", "남양주시", "동두천시", "부천시", "성남시", "수원시", "시흥시", "안산시", "안성시", "안양시", "양주시", "양평군", "여주시", "연천군", "오산시", "용인시", "의왕시", "의정부시", "이천시", "파주시", "평택시", "포천시", "하남시", "화성시"],
          "강원특별자치도": ["강릉시", "고성군", "동해시", "삼척시", "속초시", "양구군", "양양군", "영월군", "원주시", "인제군", "정선군", "철원군", "춘천시", "태백시", "평창군", "홍천군", "화천군", "횡성군"],
          "충청북도": ["괴산군", "단양군", "보은군", "영동군", "옥천군", "음성군", "제천시", "증평군", "진천군", "청주시", "충주시"],
          "충청남도": ["계룡시", "공주시", "금산군", "논산시", "당진시", "보령시", "부여군", "서산시", "서천군", "아산시", "예산군", "천안시", "청양군", "태안군", "홍성군"],
          "전북특별자치도": ["고창군", "군산시", "김제시", "남원시", "무주군", "부안군", "순창군", "완주군", "익산시", "임실군", "장수군", "전주시", "정읍시", "진안군"],
          "전라남도": ["강진군", "고흥군", "곡성군", "광양시", "구례군", "나주시", "담양군", "목포시", "무안군", "보성군", "순천시", "신안군", "여수시", "영광군", "영암군", "완도군", "장성군", "장흥군", "진도군", "함평군", "해남군", "화순군"],
          "경상북도": ["경산시", "경주시", "고령군", "구미시", "군위군", "김천시", "문경시", "봉화군", "상주시", "성주군", "안동시", "영덕군", "영양군", "영주시", "영천시", "예천군", "울릉군", "울진군", "의성군", "청도군", "청송군", "칠곡군", "포항시"],
          "경상남도": ["거제시", "거창군", "고성군", "김해시", "남해군", "밀양시", "사천시", "산청군", "양산시", "의령군", "진주시", "창녕군", "창원시", "통영시", "하동군", "함안군", "함양군", "합천군"],
          "제주특별자치도": ["서귀포시", "제주시"]
        };

        let allFacilities = [];
        let filteredFacilities = [];
        let map = null;
        let markers = [];

        // Leaflet 지도 초기화
        function initLeafletMap() {
          console.log('🗺️ Leaflet 지도 초기화 시작');
          
          // 지도 생성 (서울 중심)
          map = L.map('map').setView([37.5665, 126.9780], 7);
          
          // OpenStreetMap 타일 레이어 추가
          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 19
          }).addTo(map);
          
          console.log('✅ Leaflet 지도 초기화 완료');
        }

        // 지도에 마커 표시
        function displayMarkersOnMap() {
          // 기존 마커 제거
          markers.forEach(marker => map.removeLayer(marker));
          markers = [];

          // 최대 100개 마커 표시
          const displayList = filteredFacilities.slice(0, 100);
          
          if (displayList.length === 0) return;

          // 시설 유형별 마커 색상
          const typeColors = {
            '요양병원': '#ef4444',    // 빨강
            '요양원': '#3b82f6',       // 파랑
            '재가복지센터': '#10b981', // 초록
            '주야간보호': '#f59e0b'    // 주황
          };

          displayList.forEach(facility => {
            if (!facility.lat || !facility.lng) return;

            // 커스텀 마커 아이콘
            const markerColor = typeColors[facility.type] || '#6b7280';
            const markerIcon = L.divIcon({
              className: 'custom-marker',
              html: \`<div style="background-color: \${markerColor}; width: 24px; height: 24px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>\`,
              iconSize: [24, 24],
              iconAnchor: [12, 12]
            });

            // 마커 생성
            const marker = L.marker([facility.lat, facility.lng], {
              icon: markerIcon
            }).addTo(map);

            // 팝업 내용
            const popupContent = \`
              <div style="min-width:200px;">
                <div style="font-weight:bold;margin-bottom:5px;color:\${markerColor};font-size:12px;">
                  \${facility.type}
                </div>
                <div style="font-size:14px;margin-bottom:5px;font-weight:600;">
                  \${facility.name}
                </div>
                <div style="font-size:12px;color:#666;">
                  📍 \${facility.address}
                </div>
                <div style="font-size:11px;color:#999;margin-top:5px;">
                  \${facility.sido} \${facility.sigungu}
                </div>
              </div>
            \`;

            marker.bindPopup(popupContent);
            markers.push(marker);
          });

          // 첫 번째 시설로 지도 중심 이동
          if (displayList.length > 0 && displayList[0].lat && displayList[0].lng) {
            map.setView([displayList[0].lat, displayList[0].lng], 12);
          }
          
          console.log(\`📍 \${displayList.length}개 마커 표시 완료\`);
        }

        // 데이터베이스에서 시설 데이터 로드
        async function loadFacilitiesData() {
          try {
            document.getElementById('loadingSpinner').classList.remove('hidden');
            
            // 데이터베이스 API 호출
            const response = await fetch('/api/facilities-from-db');
            const data = await response.json();
            
            if (!data.success || !data.facilities) {
              throw new Error('데이터 로드 실패');
            }
            
            // 데이터베이스에서 가져온 데이터 변환
            allFacilities = data.facilities.map((f, idx) => ({
              id: f.id || idx + 1,
              type: f.facility_type || '',
              name: f.name || '',
              address: f.address || '',
              sido: f.sido || '',
              sigungu: f.sigungu || '',
              lat: parseFloat(f.latitude) || 0,
              lng: parseFloat(f.longitude) || 0
            }));
            
            console.log('✅ 로드된 시설 수:', allFacilities.length);
            
            // 데이터 검증 - 처음 5개 샘플 출력
            console.log('📋 데이터 샘플 (처음 5개):');
            allFacilities.slice(0, 5).forEach((f, idx) => {
              console.log(\`  \${idx + 1}. \${f.name} | \${f.sido} \${f.sigungu} | \${f.type}\`);
            });
            
            filteredFacilities = allFacilities;
            
            // 헤더 텍스트 업데이트 (시설 수 숨김)
            const headerElement = document.getElementById('facilityCountHeader');
            if (headerElement) {
              headerElement.textContent = \`전국 요양시설 정보를 확인하세요\`;
            }
            
            document.getElementById('loadingSpinner').classList.add('hidden');
            displayResults();
          } catch (error) {
            console.error('❌ 데이터 로드 실패:', error);
            document.getElementById('loadingSpinner').classList.add('hidden');
            alert('데이터를 불러오는데 실패했습니다.');
          }
        }

        // 시도 선택 옵션 생성
        const sidoSelect = document.getElementById('filterSido');
        Object.keys(regionData).forEach(sido => {
          const option = document.createElement('option');
          option.value = sido;
          option.textContent = sido;
          sidoSelect.appendChild(option);
        });

        // 시도 변경 시 시군구 로드
        sidoSelect.addEventListener('change', function() {
          const sigunguSelect = document.getElementById('filterSigungu');
          sigunguSelect.innerHTML = '<option value="">전체</option>';
          
          if (this.value) {
            sigunguSelect.disabled = false;
            regionData[this.value].forEach(sigungu => {
              const option = document.createElement('option');
              option.value = sigungu;
              option.textContent = sigungu;
              sigunguSelect.appendChild(option);
            });
          } else {
            sigunguSelect.disabled = true;
          }
        });

        // 검색 실행
        function searchFacilities() {
          const sido = document.getElementById('filterSido').value;
          const sigungu = document.getElementById('filterSigungu').value;
          const type = document.getElementById('filterType').value;
          const keyword = document.getElementById('searchKeyword').value.trim().toLowerCase();

          console.log('🔍 검색 조건:', { sido, sigungu, type, keyword });
          console.log('📊 전체 시설 수:', allFacilities.length);

          filteredFacilities = allFacilities.filter(facility => {
            if (sido && facility.sido !== sido) return false;
            if (sigungu && facility.sigungu !== sigungu) return false;
            if (type && facility.type !== type) return false;
            if (keyword && !facility.name.toLowerCase().includes(keyword)) return false;
            return true;
          });

          console.log('✅ 필터링 결과:', filteredFacilities.length);
          
          // 필터링 결과가 0개이고 조건이 있을 때 샘플 데이터 확인
          if (filteredFacilities.length === 0 && (sido || sigungu || type)) {
            console.log('⚠️ 검색 결과 없음. 샘플 데이터 확인:');
            const samples = allFacilities.slice(0, 3);
            samples.forEach(s => {
              console.log('샘플:', {
                name: s.name,
                sido: s.sido,
                sigungu: s.sigungu,
                type: s.type
              });
            });
          }

          displayResults();
        }

        // 검색 초기화
        function resetSearch() {
          document.getElementById('filterSido').value = '';
          document.getElementById('filterSigungu').value = '';
          document.getElementById('filterSigungu').disabled = true;
          document.getElementById('filterType').value = '';
          document.getElementById('searchKeyword').value = '';
          
          filteredFacilities = allFacilities;
          displayResults();
        }

        // 결과 표시
        function displayResults() {
          // 결과 수 업데이트 (전체 시설 수 숨김 - 검색 결과만 표시)
          const resultCountElement = document.getElementById('resultCount');
          if (resultCountElement) {
            // 필터 요소들이 존재하는지 확인 후 값 가져오기
            const sidoElement = document.getElementById('sidoFilter');
            const sigunguElement = document.getElementById('sigunguFilter');
            const typeElement = document.getElementById('typeFilter');
            const keywordElement = document.getElementById('searchKeyword');
            
            const sido = sidoElement ? sidoElement.value : '';
            const sigungu = sigunguElement ? sigunguElement.value : '';
            const type = typeElement ? typeElement.value : '';
            const keyword = keywordElement ? keywordElement.value.trim() : '';
            
            if (sido || sigungu || type || keyword) {
              resultCountElement.textContent = filteredFacilities.length.toLocaleString();
            } else {
              resultCountElement.textContent = '전체';
            }
          }

          // 지도에 마커 표시
          displayMarkersOnMap();

          // 리스트 표시 (최대 100개)
          const facilityList = document.getElementById('facilityList');
          const displayList = filteredFacilities.slice(0, 100);
          
          if (displayList.length === 0) {
            facilityList.innerHTML = \`
              <div class="text-center text-gray-500 py-20">
                <i class="fas fa-search text-6xl mb-4"></i>
                <p class="text-lg font-medium">검색 결과가 없습니다</p>
                <p class="text-sm mt-2">다른 조건으로 검색해보세요</p>
              </div>
            \`;
          } else {
            facilityList.innerHTML = displayList.map((facility, index) => \`
              <div class="border-b border-gray-200 py-4 hover:bg-purple-50 px-3 rounded-lg transition-colors">
                <div class="flex items-start justify-between">
                  <div class="flex-1">
                    <h4 class="font-bold text-lg text-gray-900 mb-2">
                      <span class="inline-block bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded mr-2">
                        \${facility.type}
                      </span>
                      \${facility.name}
                    </h4>
                    <p class="text-sm text-gray-600 mb-1">
                      <i class="fas fa-map-marker-alt text-red-500 mr-1"></i>
                      \${facility.address}
                    </p>
                    <p class="text-xs text-gray-500">
                      <i class="fas fa-map text-blue-500 mr-1"></i>
                      \${facility.sido} \${facility.sigungu}
                    </p>
                  </div>
                  <button onclick="showOnMap(\${facility.lat}, \${facility.lng}, '\${facility.name.replace(/'/g, "\\\\'")}')" 
                    class="ml-3 bg-purple-500 text-white px-4 py-2 rounded-lg hover:bg-purple-600 text-sm flex-shrink-0">
                    <i class="fas fa-map-marker-alt mr-1"></i>지도
                  </button>
                </div>
              </div>
            \`).join('');
            
            if (filteredFacilities.length > 100) {
              facilityList.innerHTML += \`
                <div class="text-center py-6 text-gray-500">
                  <p class="text-sm">상위 100개만 표시됩니다</p>
                  <p class="text-xs mt-1">더 정확한 검색을 위해 필터를 사용하세요</p>
                </div>
              \`;
            }
          }
        }

        // 특정 시설을 지도에 표시
        function showOnMap(lat, lng, name) {
          if (!map) {
            alert('지도를 초기화하는 중입니다. 잠시 후 다시 시도해주세요.');
            return;
          }

          // 지도 중심 이동 및 확대
          map.setView([lat, lng], 16);

          // 해당 위치 마커 찾기 및 팝업 열기
          markers.forEach(marker => {
            const markerLatLng = marker.getLatLng();
            if (Math.abs(markerLatLng.lat - lat) < 0.0001 && Math.abs(markerLatLng.lng - lng) < 0.0001) {
              marker.openPopup();
            }
          });
          
          console.log(\`🎯 지도 이동: \${name}\`);
        }

        // Leaflet 로드 대기 및 초기화
        function waitForLeaflet() {
          if (typeof L !== 'undefined') {
            console.log('✅ Leaflet 로드 완료');
            initLeafletMap();
            loadFacilitiesData();
          } else {
            console.log('⏳ Leaflet 로딩 중...');
            setTimeout(waitForLeaflet, 100);
          }
        }

        // 페이지 로드 시 Leaflet 로드 대기
        if (document.readyState === 'loading') {
          document.addEventListener('DOMContentLoaded', waitForLeaflet);
        } else {
          waitForLeaflet();
        }
        `}})]})));T.get("/admin",async e=>await M(e)?e.redirect("/admin/dashboard"):e.render(t("div",{class:"min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 to-gray-800",children:[t("div",{class:"bg-white p-8 rounded-2xl shadow-2xl w-full max-w-md",children:[t("div",{class:"text-center mb-8",children:[t("div",{class:"w-20 h-20 bg-gradient-to-r from-gray-800 to-gray-900 rounded-full flex items-center justify-center mx-auto mb-4",children:t("i",{class:"fas fa-shield-alt text-3xl text-white"})}),t("h2",{class:"text-3xl font-bold text-gray-900",children:"관리자 로그인"}),t("p",{class:"text-gray-600 mt-2",children:"케어조아 관리 시스템"})]}),t("form",{id:"adminLoginForm",class:"space-y-6",children:[t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-2",children:[t("i",{class:"fas fa-lock mr-1 text-gray-600"}),"비밀번호"]}),t("input",{type:"password",id:"password",required:!0,class:"w-full p-4 border-2 border-gray-300 rounded-lg focus:border-gray-900 focus:outline-none",placeholder:"관리자 비밀번호를 입력하세요"})]}),t("button",{type:"submit",class:"w-full bg-gradient-to-r from-gray-800 to-gray-900 text-white py-4 rounded-lg hover:from-gray-900 hover:to-black transform hover:scale-105 transition-all duration-300 font-bold",children:[t("i",{class:"fas fa-sign-in-alt mr-2"}),"로그인"]})]}),t("div",{class:"mt-6 text-center",children:t("a",{href:"/",class:"text-gray-600 hover:text-gray-900 text-sm",children:[t("i",{class:"fas fa-arrow-left mr-1"}),"메인 페이지로 돌아가기"]})})]}),t("script",{dangerouslySetInnerHTML:{__html:`
        document.getElementById('adminLoginForm').addEventListener('submit', async (e) => {
          e.preventDefault();
          const password = document.getElementById('password').value;
          
          try {
            const response = await axios.post('/api/admin/login', { password });
            if (response.data.success) {
              window.location.href = '/admin/dashboard';
            } else {
              alert(response.data.message || '로그인 실패');
            }
          } catch (error) {
            alert('로그인 중 오류가 발생했습니다.');
          }
        });
        `}})]})));T.get("/admin/dashboard",async e=>await M(e)?e.render(t("div",{class:"min-h-screen bg-gray-100",children:[t("header",{class:"bg-white shadow-sm border-b",children:t("div",{class:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:t("div",{class:"flex justify-between items-center h-16",children:[t("div",{class:"flex items-center",children:[t("i",{class:"fas fa-shield-alt text-2xl text-gray-900 mr-3"}),t("h1",{class:"text-2xl font-bold text-gray-900",children:"케어조아 관리자"})]}),t("div",{class:"flex items-center space-x-4",children:[t("a",{href:"/admin/dashboard",class:"text-gray-700 hover:text-gray-900 px-3 py-2 rounded-lg hover:bg-gray-100",children:[t("i",{class:"fas fa-home mr-2"}),"대시보드"]}),t("a",{href:"/admin/facilities",class:"text-gray-700 hover:text-gray-900 px-3 py-2 rounded-lg hover:bg-gray-100",children:[t("i",{class:"fas fa-hospital mr-2"}),"시설 관리"]}),t("button",{id:"logoutBtn",class:"bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700",children:[t("i",{class:"fas fa-sign-out-alt mr-2"}),"로그아웃"]})]})]})})}),t("div",{class:"max-w-7xl mx-auto px-4 py-8",children:[t("div",{class:"grid md:grid-cols-2 gap-8 mb-8",children:[t("div",{class:"bg-gradient-to-r from-blue-500 to-blue-600 p-6 rounded-xl shadow-lg text-white",children:t("div",{class:"flex items-center justify-between",children:[t("div",{children:[t("p",{class:"text-blue-100 mb-1",children:"파트너 신청"}),t("p",{class:"text-4xl font-bold",id:"partnerCount",children:"0"})]}),t("i",{class:"fas fa-handshake text-5xl text-blue-300"})]})}),t("div",{class:"bg-gradient-to-r from-green-500 to-green-600 p-6 rounded-xl shadow-lg text-white",children:t("div",{class:"flex items-center justify-between",children:[t("div",{children:[t("p",{class:"text-green-100 mb-1",children:"가족 간병 신청"}),t("p",{class:"text-4xl font-bold",id:"familyCareCount",children:"0"})]}),t("i",{class:"fas fa-heart text-5xl text-green-300"})]})})]}),t("div",{class:"bg-white rounded-xl shadow-lg p-6 mb-8",children:[t("h3",{class:"text-2xl font-bold mb-6 flex items-center",children:[t("i",{class:"fas fa-handshake text-blue-600 mr-3"}),"파트너 신청 목록",t("span",{class:"ml-4 text-sm text-gray-500 font-normal",children:"(지역별 대표 상담센터로 지정하려면 체크하세요 - 최대 4개)"})]}),t("div",{class:"overflow-x-auto",children:t("table",{class:"w-full",children:[t("thead",{class:"bg-gray-50",children:t("tr",{children:[t("th",{class:"px-4 py-3 text-left",children:"선택"}),t("th",{class:"px-4 py-3 text-left",children:"시설명"}),t("th",{class:"px-4 py-3 text-left",children:"유형"}),t("th",{class:"px-4 py-3 text-left",children:"시설 주소"}),t("th",{class:"px-4 py-3 text-left",children:"담당자"}),t("th",{class:"px-4 py-3 text-left",children:"연락처"}),t("th",{class:"px-4 py-3 text-left",children:"지역 설정"}),t("th",{class:"px-4 py-3 text-left",children:"신청일"})]})}),t("tbody",{id:"partnerList"})]})})]}),t("div",{class:"bg-white rounded-xl shadow-lg p-6",children:[t("h3",{class:"text-2xl font-bold mb-6 flex items-center",children:[t("i",{class:"fas fa-heart text-green-600 mr-3"}),"가족 간병 신청 목록"]}),t("div",{class:"overflow-x-auto",children:t("table",{class:"w-full",children:[t("thead",{class:"bg-gray-50",children:t("tr",{children:[t("th",{class:"px-4 py-3 text-left",children:"보호자"}),t("th",{class:"px-4 py-3 text-left",children:"연락처"}),t("th",{class:"px-4 py-3 text-left",children:"환자명"}),t("th",{class:"px-4 py-3 text-left",children:"나이"}),t("th",{class:"px-4 py-3 text-left",children:"지역"}),t("th",{class:"px-4 py-3 text-left",children:"요청사항"}),t("th",{class:"px-4 py-3 text-left",children:"신청일"})]})}),t("tbody",{id:"familyCareList"})]})})]})]}),t("script",{src:"https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"}),t("script",{dangerouslySetInnerHTML:{__html:`
        // 지역 데이터
        const regionData = {
          "서울특별시": ["강남구", "강동구", "강북구", "강서구", "관악구", "광진구", "구로구", "금천구", "노원구", "도봉구", "동대문구", "동작구", "마포구", "서대문구", "서초구", "성동구", "성북구", "송파구", "양천구", "영등포구", "용산구", "은평구", "종로구", "중구", "중랑구"],
          "부산광역시": ["강서구", "금정구", "기장군", "남구", "동구", "동래구", "부산진구", "북구", "사상구", "사하구", "서구", "수영구", "연제구", "영도구", "중구", "해운대구"],
          "대구광역시": ["남구", "달서구", "달성군", "동구", "북구", "서구", "수성구", "중구"],
          "인천광역시": ["강화군", "계양구", "남동구", "동구", "미추홀구", "부평구", "서구", "연수구", "옹진군", "중구"],
          "광주광역시": ["광산구", "남구", "동구", "북구", "서구"],
          "대전광역시": ["대덕구", "동구", "서구", "유성구", "중구"],
          "울산광역시": ["남구", "동구", "북구", "울주군", "중구"],
          "세종특별자치시": ["세종시"],
          "경기도": ["가평군", "고양시", "과천시", "광명시", "광주시", "구리시", "군포시", "김포시", "남양주시", "동두천시", "부천시", "성남시", "수원시", "시흥시", "안산시", "안성시", "안양시", "양주시", "양평군", "여주시", "연천군", "오산시", "용인시", "의왕시", "의정부시", "이천시", "파주시", "평택시", "포천시", "하남시", "화성시"],
          "강원도": ["강릉시", "고성군", "동해시", "삼척시", "속초시", "양구군", "양양군", "영월군", "원주시", "인제군", "정선군", "철원군", "춘천시", "태백시", "평창군", "홍천군", "화천군", "횡성군"],
          "충청북도": ["괴산군", "단양군", "보은군", "영동군", "옥천군", "음성군", "제천시", "증평군", "진천군", "청주시", "충주시"],
          "충청남도": ["계룡시", "공주시", "금산군", "논산시", "당진시", "보령시", "부여군", "서산시", "서천군", "아산시", "예산군", "천안시", "청양군", "태안군", "홍성군"],
          "전라북도": ["고창군", "군산시", "김제시", "남원시", "무주군", "부안군", "순창군", "완주군", "익산시", "임실군", "장수군", "전주시", "정읍시", "진안군"],
          "전라남도": ["강진군", "고흥군", "곡성군", "광양시", "구례군", "나주시", "담양군", "목포시", "무안군", "보성군", "순천시", "신안군", "여수시", "영광군", "영암군", "완도군", "장성군", "장흥군", "진도군", "함평군", "해남군", "화순군"],
          "경상북도": ["경산시", "경주시", "고령군", "구미시", "군위군", "김천시", "문경시", "봉화군", "상주시", "성주군", "안동시", "영덕군", "영양군", "영주시", "영천시", "예천군", "울릉군", "울진군", "의성군", "청도군", "청송군", "칠곡군", "포항시"],
          "경상남도": ["거제시", "거창군", "고성군", "김해시", "남해군", "밀양시", "사천시", "산청군", "양산시", "의령군", "진주시", "창녕군", "창원시", "통영시", "하동군", "함안군", "함양군", "합천군"],
          "제주특별자치도": ["서귀포시", "제주시"]
        };
        
        async function loadData() {
          try {
            const response = await axios.get('/api/admin/data');
            const { partners, familyCare, regionalCenters } = response.data;
            
            document.getElementById('partnerCount').textContent = partners.length;
            document.getElementById('familyCareCount').textContent = familyCare.length;
            
            const partnerList = document.getElementById('partnerList');
            partnerList.innerHTML = partners.map((p, index) => {
              const regionKey = p.regionKey || '';
              const isRegionalCenter = Object.values(regionalCenters).some(centers => 
                centers.some(c => c.id === p.id)
              );
              
              const fullAddress = p.facilitySido && p.facilitySigungu 
                ? \`\${p.facilitySido} \${p.facilitySigungu} \${p.facilityAddress || ''}\`
                : '미입력';
              
              return \`
              <tr class="border-t hover:bg-gray-50" id="partner-\${index}">
                <td class="px-4 py-3">
                  <input type="checkbox" 
                         class="w-5 h-5 text-green-600" 
                         \${isRegionalCenter ? 'checked' : ''}
                         onchange="toggleRegionalCenter(\${index}, '\${p.id}', this.checked)" />
                </td>
                <td class="px-4 py-3">\${p.facilityName}</td>
                <td class="px-4 py-3">\${p.facilityType}</td>
                <td class="px-4 py-3">
                  <div class="text-sm">\${fullAddress}</div>
                </td>
                <td class="px-4 py-3">\${p.managerName}</td>
                <td class="px-4 py-3">\${p.managerPhone}</td>
                <td class="px-4 py-3">
                  <div class="flex gap-2" id="region-selector-\${index}">
                    <select class="text-sm p-2 border rounded" id="sido-\${index}">
                      <option value="">시/도</option>
                    </select>
                    <select class="text-sm p-2 border rounded" id="sigungu-\${index}" disabled>
                      <option value="">시/군/구</option>
                    </select>
                    <button onclick="saveRegion(\${index})" class="bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600">
                      저장
                    </button>
                  </div>
                  <div class="text-sm text-gray-600 mt-1" id="current-region-\${index}">
                    \${regionKey ? regionKey.replace('_', ' > ') : '미설정'}
                  </div>
                </td>
                <td class="px-4 py-3">\${new Date(p.createdAt).toLocaleDateString('ko-KR')}</td>
              </tr>
              \`;
            }).join('') || '<tr><td colspan="8" class="px-4 py-8 text-center text-gray-500">신청 내역이 없습니다</td></tr>';
            
            // 시도 옵션 생성
            partners.forEach((p, index) => {
              const sidoSelect = document.getElementById('sido-' + index);
              if (sidoSelect) {
                Object.keys(regionData).forEach(sido => {
                  const option = document.createElement('option');
                  option.value = sido;
                  option.textContent = sido;
                  sidoSelect.appendChild(option);
                });
                
                // 시도 변경 이벤트
                sidoSelect.addEventListener('change', function() {
                  const sigunguSelect = document.getElementById('sigungu-' + index);
                  sigunguSelect.innerHTML = '<option value="">시/군/구</option>';
                  sigunguSelect.disabled = false;
                  
                  if (this.value) {
                    regionData[this.value].forEach(sigungu => {
                      const option = document.createElement('option');
                      option.value = sigungu;
                      option.textContent = sigungu;
                      sigunguSelect.appendChild(option);
                    });
                  } else {
                    sigunguSelect.disabled = true;
                  }
                });
              }
            });
            
            const familyCareList = document.getElementById('familyCareList');
            familyCareList.innerHTML = familyCare.map(f => \`
              <tr class="border-t hover:bg-gray-50">
                <td class="px-4 py-3">\${f.guardianName}</td>
                <td class="px-4 py-3">\${f.guardianPhone}</td>
                <td class="px-4 py-3">\${f.patientName}</td>
                <td class="px-4 py-3">\${f.patientAge}세</td>
                <td class="px-4 py-3">\${f.region}</td>
                <td class="px-4 py-3">\${f.requirements || '-'}</td>
                <td class="px-4 py-3">\${new Date(f.createdAt).toLocaleDateString('ko-KR')}</td>
              </tr>
            \`).join('') || '<tr><td colspan="7" class="px-4 py-8 text-center text-gray-500">신청 내역이 없습니다</td></tr>';
          } catch (error) {
            console.error('데이터 로드 실패:', error);
          }
        }
        
        // 지역 저장 함수
        window.saveRegion = async function(index) {
          const sido = document.getElementById('sido-' + index).value;
          const sigungu = document.getElementById('sigungu-' + index).value;
          
          if (!sido || !sigungu) {
            alert('시/도와 시/군/구를 모두 선택해주세요.');
            return;
          }
          
          const regionKey = sido + '_' + sigungu;
          
          try {
            const response = await axios.post('/api/admin/set-region', {
              partnerIndex: index,
              regionKey: regionKey
            });
            
            if (response.data.success) {
              alert('지역이 설정되었습니다.');
              loadData();
            }
          } catch (error) {
            alert('지역 설정 실패');
          }
        };
        
        // 대표 상담센터 토글
        window.toggleRegionalCenter = async function(index, partnerId, isChecked) {
          try {
            const response = await axios.post('/api/admin/toggle-regional-center', {
              partnerIndex: index,
              isChecked: isChecked
            });
            
            if (response.data.success) {
              if (!isChecked) {
                alert('대표 상담센터에서 제거되었습니다.');
              } else if (response.data.message) {
                alert(response.data.message);
                loadData(); // 체크 해제를 위해 다시 로드
              } else {
                alert('대표 상담센터로 지정되었습니다. (지역을 설정해주세요)');
              }
            }
          } catch (error) {
            alert('설정 실패');
            loadData();
          }
        };
        
        document.getElementById('logoutBtn').addEventListener('click', async () => {
          try {
            await axios.post('/api/admin/logout');
            window.location.href = '/admin';
          } catch (error) {
            console.error('로그아웃 실패:', error);
          }
        });
        
        loadData();
        setInterval(loadData, 30000);
        `}})]})):e.redirect("/admin"));T.get("/admin/facilities",async e=>await M(e)?e.render(t("div",{class:"min-h-screen bg-gray-100",children:[t("header",{class:"bg-white shadow-sm border-b",children:t("div",{class:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:t("div",{class:"flex justify-between items-center h-16",children:[t("div",{class:"flex items-center",children:[t("i",{class:"fas fa-shield-alt text-2xl text-gray-900 mr-3"}),t("h1",{class:"text-2xl font-bold text-gray-900",children:"케어조아 관리자"})]}),t("div",{class:"flex items-center space-x-4",children:[t("a",{href:"/admin/dashboard",class:"text-gray-700 hover:text-gray-900 px-3 py-2 rounded-lg hover:bg-gray-100",children:[t("i",{class:"fas fa-home mr-2"}),"대시보드"]}),t("a",{href:"/admin/facilities",class:"bg-gray-200 text-gray-900 px-3 py-2 rounded-lg",children:[t("i",{class:"fas fa-hospital mr-2"}),"시설 관리"]}),t("button",{id:"logoutBtn",class:"bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700",children:[t("i",{class:"fas fa-sign-out-alt mr-2"}),"로그아웃"]})]})]})})}),t("div",{class:"max-w-7xl mx-auto px-4 py-8",children:[t("div",{class:"bg-white rounded-xl shadow-lg p-6 mb-6",children:[t("div",{class:"flex justify-between items-center mb-6",children:[t("div",{children:[t("h2",{class:"text-2xl font-bold text-gray-900",children:[t("i",{class:"fas fa-hospital text-blue-600 mr-2"}),"요양시설 정보 관리"]}),t("p",{class:"text-gray-600 mt-1",children:["총 ",t("span",{id:"totalCount",class:"font-bold text-blue-600",children:"0"}),"개 시설"]})]}),t("div",{class:"flex flex-wrap gap-2",children:[t("button",{id:"downloadExcelBtn",class:"bg-teal-600 text-white px-4 py-2 rounded-lg hover:bg-teal-700",children:[t("i",{class:"fas fa-download mr-2"}),"엑셀 다운로드"]}),t("button",{id:"uploadExcelBtn",class:"bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700",children:[t("i",{class:"fas fa-upload mr-2"}),"엑셀 업로드"]}),t("button",{id:"importCsvBtn",class:"bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700",children:[t("i",{class:"fas fa-file-upload mr-2"}),"CSV 임포트"]}),t("button",{id:"addFacilityBtn",class:"bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700",children:[t("i",{class:"fas fa-plus mr-2"}),"시설 추가"]})]})]}),t("div",{class:"grid grid-cols-1 md:grid-cols-5 gap-4",children:[t("input",{type:"text",id:"searchInput",placeholder:"시설명 또는 주소 검색...",class:"px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"}),t("select",{id:"sidoFilter",class:"px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500",children:t("option",{value:"",children:"전체 시도"})}),t("select",{id:"sigunguFilter",class:"px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500",children:t("option",{value:"",children:"전체 시군구"})}),t("select",{id:"typeFilter",class:"px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500",children:[t("option",{value:"",children:"전체 유형"}),t("option",{value:"요양병원",children:"요양병원"}),t("option",{value:"요양원",children:"요양원"}),t("option",{value:"재가복지센터",children:"재가복지센터"}),t("option",{value:"주야간보호",children:"주야간보호"})]}),t("button",{id:"searchBtn",class:"bg-gray-800 text-white px-6 py-2 rounded-lg hover:bg-gray-900",children:[t("i",{class:"fas fa-search mr-2"}),"검색"]})]})]}),t("div",{class:"bg-white rounded-xl shadow-lg overflow-hidden",children:[t("div",{class:"overflow-x-auto",children:t("table",{class:"w-full",children:[t("thead",{class:"bg-gray-50 border-b",children:t("tr",{children:[t("th",{class:"px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase",children:"ID"}),t("th",{class:"px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase",children:"시설 유형"}),t("th",{class:"px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase",children:"시설명"}),t("th",{class:"px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase",children:"전화번호"}),t("th",{class:"px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase",children:"주소"}),t("th",{class:"px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase",children:"시도"}),t("th",{class:"px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase",children:"시군구"}),t("th",{class:"px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase",children:"관리"})]})}),t("tbody",{id:"facilitiesTableBody",class:"divide-y divide-gray-200",children:t("tr",{children:t("td",{colspan:"8",class:"px-4 py-8 text-center text-gray-500",children:[t("i",{class:"fas fa-spinner fa-spin text-2xl mb-2"}),t("p",{children:"데이터를 불러오는 중..."})]})})})]})}),t("div",{class:"bg-gray-50 px-4 py-3 border-t flex items-center justify-between",children:[t("div",{class:"text-sm text-gray-700",children:t("span",{id:"paginationInfo",children:"페이지 1 / 1"})}),t("div",{class:"flex space-x-2",id:"paginationButtons",children:[t("button",{id:"prevPageBtn",class:"px-3 py-1 bg-white border rounded hover:bg-gray-50 disabled:opacity-50",disabled:!0,children:t("i",{class:"fas fa-chevron-left"})}),t("button",{id:"nextPageBtn",class:"px-3 py-1 bg-white border rounded hover:bg-gray-50 disabled:opacity-50",disabled:!0,children:t("i",{class:"fas fa-chevron-right"})})]})]})]})]}),t("div",{id:"facilityModal",class:"hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50",children:t("div",{class:"bg-white rounded-xl shadow-2xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto",children:t("div",{class:"p-6",children:[t("div",{class:"flex justify-between items-center mb-6",children:[t("h3",{id:"modalTitle",class:"text-2xl font-bold",children:"시설 추가"}),t("button",{id:"closeModalBtn",class:"text-gray-500 hover:text-gray-700",children:t("i",{class:"fas fa-times text-2xl"})})]}),t("form",{id:"facilityForm",class:"space-y-4",children:[t("input",{type:"hidden",id:"facilityId"}),t("div",{class:"grid grid-cols-2 gap-4",children:[t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-1",children:"시설 유형 *"}),t("select",{id:"facilityType",required:!0,class:"w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500",children:[t("option",{value:"",children:"선택하세요"}),t("option",{value:"요양병원",children:"요양병원"}),t("option",{value:"요양원",children:"요양원"}),t("option",{value:"재가복지센터",children:"재가복지센터"}),t("option",{value:"주야간보호",children:"주야간보호"})]})]}),t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-1",children:"시설명 *"}),t("input",{type:"text",id:"facilityName",required:!0,class:"w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"})]})]}),t("div",{class:"grid grid-cols-2 gap-4",children:[t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-1",children:"전화번호"}),t("input",{type:"tel",id:"facilityPhone",placeholder:"02-1234-5678",class:"w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"})]}),t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-1",children:"우편번호"}),t("input",{type:"text",id:"facilityPostalCode",class:"w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"})]})]}),t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-1",children:"주소 *"}),t("input",{type:"text",id:"facilityAddress",required:!0,class:"w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"})]}),t("div",{class:"grid grid-cols-2 gap-4",children:[t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-1",children:"시도 *"}),t("select",{id:"facilitySido",required:!0,class:"w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500",children:t("option",{value:"",children:"선택하세요"})})]}),t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-1",children:"시군구 *"}),t("select",{id:"facilitySigungu",required:!0,class:"w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500",children:t("option",{value:"",children:"선택하세요"})})]})]}),t("div",{class:"grid grid-cols-2 gap-4",children:[t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-1",children:"위도 *"}),t("input",{type:"number",id:"facilityLatitude",required:!0,step:"any",class:"w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"})]}),t("div",{children:[t("label",{class:"block text-sm font-medium text-gray-700 mb-1",children:"경도 *"}),t("input",{type:"number",id:"facilityLongitude",required:!0,step:"any",class:"w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"})]})]}),t("div",{class:"flex justify-end space-x-3 pt-4",children:[t("button",{type:"button",id:"cancelBtn",class:"px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50",children:"취소"}),t("button",{type:"submit",class:"px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700",children:[t("i",{class:"fas fa-save mr-2"}),"저장"]})]})]})]})})}),t("script",{src:"https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"}),t("script",{dangerouslySetInnerHTML:{__html:`
        // 간편 견적 폼 제출
        document.addEventListener('DOMContentLoaded', function() {
          const quickEstimateForm = document.getElementById('quickEstimateForm');
          if (quickEstimateForm) {
            quickEstimateForm.addEventListener('submit', async function(e) {
              e.preventDefault();
              
              const name = document.getElementById('quickName').value.trim();
              const phone = document.getElementById('quickPhone').value.trim();
              const region = document.getElementById('quickRegion').value;
              const facilityType = document.getElementById('quickFacilityType').value || '미정';
              
              if (!name || !phone || !region) {
                alert('필수 항목을 모두 입력해주세요.');
                return;
              }
              
              // 전화번호 형식 검증
              const phoneRegex = /^01[0-9]-?[0-9]{3,4}-?[0-9]{4}$/;
              if (!phoneRegex.test(phone)) {
                alert('올바른 전화번호 형식을 입력해주세요. (예: 010-0000-0000)');
                return;
              }
              
              try {
                // 제출 버튼 비활성화
                const submitBtn = quickEstimateForm.querySelector('button[type="submit"]');
                const originalText = submitBtn.innerHTML;
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>처리중...';
                
                // API 호출
                const response = await axios.post('/api/family-care', {
                  guardian_name: name,
                  guardian_phone: phone,
                  patient_name: '환자정보 미입력',
                  patient_age: 0,
                  region: region,
                  requirements: '간편 견적 신청 / 원하는 시설: ' + facilityType
                });
                
                if (response.data.success) {
                  // GA4 이벤트 트래킹
                  if (window.trackEvent) {
                    window.trackEvent('quick_estimate_success', {
                      region: region,
                      facility_type: facilityType
                    });
                  }
                  
                  alert('✅ 견적 신청이 완료되었습니다!\\n\\n전문 상담사가 곧 연락드리겠습니다.\\n감사합니다.');
                  quickEstimateForm.reset();
                } else {
                  throw new Error('신청 실패');
                }
                
                // 버튼 복원
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
                
              } catch (error) {
                console.error('견적 신청 오류:', error);
                alert('❌ 신청 중 오류가 발생했습니다.\\n\\n잠시 후 다시 시도해주시거나\\n전화(0507-1310-5873)로 문의해주세요.');
                
                // 버튼 복원
                const submitBtn = quickEstimateForm.querySelector('button[type="submit"]');
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
              }
            });
          }
        });
        `}}),t("script",{dangerouslySetInnerHTML:{__html:`
        // 지역 데이터
        const regionData = {
          "서울특별시": ["강남구", "강동구", "강북구", "강서구", "관악구", "광진구", "구로구", "금천구", "노원구", "도봉구", "동대문구", "동작구", "마포구", "서대문구", "서초구", "성동구", "성북구", "송파구", "양천구", "영등포구", "용산구", "은평구", "종로구", "중구", "중랑구"],
          "부산광역시": ["강서구", "금정구", "기장군", "남구", "동구", "동래구", "부산진구", "북구", "사상구", "사하구", "서구", "수영구", "연제구", "영도구", "중구", "해운대구"],
          "대구광역시": ["남구", "달서구", "달성군", "동구", "북구", "서구", "수성구", "중구"],
          "인천광역시": ["강화군", "계양구", "남동구", "동구", "미추홀구", "부평구", "서구", "연수구", "옹진군", "중구"],
          "광주광역시": ["광산구", "남구", "동구", "북구", "서구"],
          "대전광역시": ["대덕구", "동구", "서구", "유성구", "중구"],
          "울산광역시": ["남구", "동구", "북구", "울주군", "중구"],
          "세종특별자치시": ["세종시"],
          "경기도": ["가평군", "고양시", "과천시", "광명시", "광주시", "구리시", "군포시", "김포시", "남양주시", "동두천시", "부천시", "성남시", "수원시", "시흥시", "안산시", "안성시", "안양시", "양주시", "양평군", "여주시", "연천군", "오산시", "용인시", "의왕시", "의정부시", "이천시", "파주시", "평택시", "포천시", "하남시", "화성시"],
          "강원도": ["강릉시", "고성군", "동해시", "삼척시", "속초시", "양구군", "양양군", "영월군", "원주시", "인제군", "정선군", "철원군", "춘천시", "태백시", "평창군", "홍천군", "화천군", "횡성군"],
          "충청북도": ["괴산군", "단양군", "보은군", "영동군", "옥천군", "음성군", "제천시", "증평군", "진천군", "청주시", "충주시"],
          "충청남도": ["계룡시", "공주시", "금산군", "논산시", "당진시", "보령시", "부여군", "서산시", "서천군", "아산시", "예산군", "천안시", "청양군", "태안군", "홍성군"],
          "전라북도": ["고창군", "군산시", "김제시", "남원시", "무주군", "부안군", "순창군", "완주군", "익산시", "임실군", "장수군", "전주시", "정읍시", "진안군"],
          "전라남도": ["강진군", "고흥군", "곡성군", "광양시", "구례군", "나주시", "담양군", "목포시", "무안군", "보성군", "순천시", "신안군", "여수시", "영광군", "영암군", "완도군", "장성군", "장흥군", "진도군", "함평군", "해남군", "화순군"],
          "경상북도": ["경산시", "경주시", "고령군", "구미시", "군위군", "김천시", "문경시", "봉화군", "상주시", "성주군", "안동시", "영덕군", "영양군", "영주시", "영천시", "예천군", "울릉군", "울진군", "의성군", "청도군", "청송군", "칠곡군", "포항시"],
          "경상남도": ["거제시", "거창군", "고성군", "김해시", "남해군", "밀양시", "사천시", "산청군", "양산시", "의령군", "진주시", "창녕군", "창원시", "통영시", "하동군", "함안군", "함양군", "합천군"],
          "제주특별자치도": ["서귀포시", "제주시"]
        };

        let currentPage = 1;
        let currentFilters = {};
        let editingFacilityId = null;

        // 초기화
        document.addEventListener('DOMContentLoaded', function() {
          loadFacilities();
          initFilters();
          initModals();
          initFormHandlers();
        });

        // 시설 목록 로드
        async function loadFacilities(page = 1) {
          currentPage = page;
          
          const params = new URLSearchParams({
            page,
            limit: 50,
            ...currentFilters
          });

          try {
            const response = await axios.get('/api/admin/facilities?' + params);
            const { facilities, total, totalPages } = response.data;

            document.getElementById('totalCount').textContent = total;
            document.getElementById('paginationInfo').textContent = \`페이지 \${page} / \${totalPages}\`;

            const tbody = document.getElementById('facilitiesTableBody');
            if (facilities.length === 0) {
              tbody.innerHTML = '<tr><td colspan="8" class="px-4 py-8 text-center text-gray-500">등록된 시설이 없습니다.</td></tr>';
              return;
            }

            tbody.innerHTML = facilities.map(f => \`
              <tr class="hover:bg-gray-50">
                <td class="px-4 py-3 text-sm">\${f.id}</td>
                <td class="px-4 py-3">
                  <span class="px-2 py-1 text-xs font-semibold rounded-full \${getTypeColor(f.facility_type)}">
                    \${f.facility_type}
                  </span>
                </td>
                <td class="px-4 py-3 text-sm font-medium">\${f.name}</td>
                <td class="px-4 py-3 text-sm">\${f.phone || '-'}</td>
                <td class="px-4 py-3 text-sm text-gray-600">\${f.address.substring(0, 30)}\${f.address.length > 30 ? '...' : ''}</td>
                <td class="px-4 py-3 text-sm">\${f.sido}</td>
                <td class="px-4 py-3 text-sm">\${f.sigungu}</td>
                <td class="px-4 py-3 text-sm">
                  <button onclick="editFacility(\${f.id})" class="text-blue-600 hover:text-blue-800 mr-3">
                    <i class="fas fa-edit"></i>
                  </button>
                  <button onclick="deleteFacility(\${f.id}, '\${f.name}')" class="text-red-600 hover:text-red-800">
                    <i class="fas fa-trash"></i>
                  </button>
                </td>
              </tr>
            \`).join('');

            // 페이지네이션 버튼
            document.getElementById('prevPageBtn').disabled = page <= 1;
            document.getElementById('nextPageBtn').disabled = page >= totalPages;
          } catch (error) {
            console.error('Load facilities error:', error);
            alert('시설 목록을 불러오는 중 오류가 발생했습니다.');
          }
        }

        function getTypeColor(type) {
          const colors = {
            '요양병원': 'bg-red-100 text-red-800',
            '요양원': 'bg-blue-100 text-blue-800',
            '재가복지센터': 'bg-green-100 text-green-800',
            '주야간보호': 'bg-yellow-100 text-yellow-800'
          };
          return colors[type] || 'bg-gray-100 text-gray-800';
        }

        // 필터 초기화
        function initFilters() {
          const sidoFilter = document.getElementById('sidoFilter');
          const sidoModal = document.getElementById('facilitySido');
          
          Object.keys(regionData).forEach(sido => {
            sidoFilter.add(new Option(sido, sido));
            sidoModal.add(new Option(sido, sido));
          });

          sidoFilter.addEventListener('change', function() {
            const sigunguFilter = document.getElementById('sigunguFilter');
            sigunguFilter.innerHTML = '<option value="">전체 시군구</option>';
            
            if (this.value && regionData[this.value]) {
              regionData[this.value].forEach(sigungu => {
                sigunguFilter.add(new Option(sigungu, sigungu));
              });
            }
          });

          document.getElementById('facilitySido').addEventListener('change', function() {
            const sigunguModal = document.getElementById('facilitySigungu');
            sigunguModal.innerHTML = '<option value="">선택하세요</option>';
            
            if (this.value && regionData[this.value]) {
              regionData[this.value].forEach(sigungu => {
                sigunguModal.add(new Option(sigungu, sigungu));
              });
            }
          });

          document.getElementById('searchBtn').addEventListener('click', function() {
            currentFilters = {
              search: document.getElementById('searchInput').value,
              sido: document.getElementById('sidoFilter').value,
              sigungu: document.getElementById('sigunguFilter').value,
              type: document.getElementById('typeFilter').value
            };
            loadFacilities(1);
          });

          document.getElementById('prevPageBtn').addEventListener('click', () => loadFacilities(currentPage - 1));
          document.getElementById('nextPageBtn').addEventListener('click', () => loadFacilities(currentPage + 1));
        }

        // 모달 초기화
        function initModals() {
          const modal = document.getElementById('facilityModal');
          
          document.getElementById('addFacilityBtn').addEventListener('click', function() {
            editingFacilityId = null;
            document.getElementById('modalTitle').textContent = '시설 추가';
            document.getElementById('facilityForm').reset();
            modal.classList.remove('hidden');
          });

          document.getElementById('closeModalBtn').addEventListener('click', () => modal.classList.add('hidden'));
          document.getElementById('cancelBtn').addEventListener('click', () => modal.classList.add('hidden'));
        }

        // 폼 핸들러
        function initFormHandlers() {
          document.getElementById('facilityForm').addEventListener('submit', async function(e) {
            e.preventDefault();

            const data = {
              facility_type: document.getElementById('facilityType').value,
              name: document.getElementById('facilityName').value,
              phone: document.getElementById('facilityPhone').value,
              postal_code: document.getElementById('facilityPostalCode').value,
              address: document.getElementById('facilityAddress').value,
              sido: document.getElementById('facilitySido').value,
              sigungu: document.getElementById('facilitySigungu').value,
              latitude: parseFloat(document.getElementById('facilityLatitude').value),
              longitude: parseFloat(document.getElementById('facilityLongitude').value)
            };

            try {
              if (editingFacilityId) {
                await axios.put(\`/api/admin/facilities/\${editingFacilityId}\`, data);
                alert('시설 정보가 수정되었습니다.');
              } else {
                await axios.post('/api/admin/facilities', data);
                alert('시설이 추가되었습니다.');
              }
              
              document.getElementById('facilityModal').classList.add('hidden');
              loadFacilities(currentPage);
            } catch (error) {
              console.error('Save facility error:', error);
              alert('저장 중 오류가 발생했습니다.');
            }
          });

          // 엑셀 다운로드
          document.getElementById('downloadExcelBtn').addEventListener('click', async function() {
            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>다운로드 중...';
            
            try {
              // 현재 필터 조건으로 모든 시설 데이터 가져오기
              const params = new URLSearchParams({
                page: '1',
                limit: '100000', // 모든 데이터
                search: currentFilters.search || '',
                sido: currentFilters.sido || '',
                sigungu: currentFilters.sigungu || '',
                type: currentFilters.type || ''
              });
              
              const response = await axios.get(\`/api/admin/facilities?\${params}\`);
              const facilities = response.data.facilities;
              
              if (facilities.length === 0) {
                alert('다운로드할 시설이 없습니다.');
                return;
              }
              
              // CSV 형식으로 변환
              const headers = ['ID', '시설유형', '시설명', '우편번호', '주소', '전화번호', '위도', '경도', '시도', '시군구', '비고'];
              const csvRows = [headers.join(',')];
              
              facilities.forEach(f => {
                const row = [
                  f.id,
                  f.facility_type,
                  \`"\${f.name}"\`,
                  f.postal_code || '',
                  \`"\${f.address}"\`,
                  f.phone || '',
                  f.latitude,
                  f.longitude,
                  f.sido,
                  f.sigungu,
                  \`"\${f.notes || ''}"\`
                ];
                csvRows.push(row.join(','));
              });
              
              // CSV 파일 다운로드
              const csvContent = '\\uFEFF' + csvRows.join('\\n'); // UTF-8 BOM 추가 (엑셀 한글 깨짐 방지)
              const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
              const link = document.createElement('a');
              const url = URL.createObjectURL(blob);
              
              const filename = \`facilities_\${new Date().toISOString().split('T')[0]}.csv\`;
              link.setAttribute('href', url);
              link.setAttribute('download', filename);
              link.style.display = 'none';
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
              
              alert(\`\${facilities.length}개 시설 데이터가 다운로드되었습니다.\\n파일명: \${filename}\`);
            } catch (error) {
              console.error('Download error:', error);
              alert('다운로드 중 오류가 발생했습니다.');
            } finally {
              this.disabled = false;
              this.innerHTML = '<i class="fas fa-download mr-2"></i>엑셀 다운로드';
            }
          });

          // 엑셀 업로드
          document.getElementById('uploadExcelBtn').addEventListener('click', function() {
            const fileInput = document.createElement('input');
            fileInput.type = 'file';
            fileInput.accept = '.csv,.xlsx,.xls';
            
            fileInput.onchange = async function(e) {
              const file = e.target.files[0];
              if (!file) return;
              
              if (!confirm(\`\${file.name} 파일을 업로드하여 시설 정보를 업데이트하시겠습니까?\\n\\n주의: 동일한 ID가 있으면 덮어쓰기됩니다.\`)) {
                return;
              }
              
              const btn = document.getElementById('uploadExcelBtn');
              btn.disabled = true;
              btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>업로드 중...';
              
              try {
                const reader = new FileReader();
                
                reader.onload = async function(event) {
                  try {
                    const text = event.target.result;
                    const lines = text.split('\\n').filter(line => line.trim());
                    
                    if (lines.length < 2) {
                      alert('파일에 데이터가 없습니다.');
                      return;
                    }
                    
                    // 헤더 확인 (첫 번째 줄 건너뛰기)
                    const facilities = [];
                    
                    for (let i = 1; i < lines.length; i++) {
                      const cols = parseCSVLine(lines[i]);
                      if (cols.length < 10) continue;
                      
                      const [id, facilityType, name, postalCode, address, phone, lat, lng, sido, sigungu, notes] = cols;
                      
                      facilities.push({
                        id: parseInt(id) || null,
                        facility_type: facilityType.replace(/^"|"$/g, ''),
                        name: name.replace(/^"|"$/g, ''),
                        postal_code: postalCode.replace(/^"|"$/g, ''),
                        address: address.replace(/^"|"$/g, ''),
                        phone: phone.replace(/^"|"$/g, ''),
                        latitude: parseFloat(lat) || 0,
                        longitude: parseFloat(lng) || 0,
                        sido: sido.replace(/^"|"$/g, ''),
                        sigungu: sigungu.replace(/^"|"$/g, ''),
                        notes: notes ? notes.replace(/^"|"$/g, '') : ''
                      });
                    }
                    
                    if (facilities.length === 0) {
                      alert('유효한 시설 데이터가 없습니다.');
                      return;
                    }
                    
                    // 서버로 전송
                    const response = await axios.post('/api/admin/upload-facilities', { facilities });
                    
                    if (response.data.success) {
                      alert(\`업로드 완료!\\n업데이트: \${response.data.updated}개\\n신규추가: \${response.data.inserted}개\\n실패: \${response.data.failed}개\`);
                      loadFacilities(1);
                    }
                  } catch (error) {
                    console.error('Parse error:', error);
                    alert('파일 파싱 중 오류가 발생했습니다.');
                  }
                };
                
                reader.readAsText(file, 'UTF-8');
              } catch (error) {
                console.error('Upload error:', error);
                alert('업로드 중 오류가 발생했습니다.');
              } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-upload mr-2"></i>엑셀 업로드';
              }
            };
            
            fileInput.click();
          });

          // DB 초기화
          // CSV 임포트
          document.getElementById('importCsvBtn').addEventListener('click', async function() {
            // 파일 입력 생성
            const fileInput = document.createElement('input');
            fileInput.type = 'file';
            fileInput.accept = '.csv';
            
            fileInput.onchange = async (e) => {
              const file = e.target.files[0];
              if (!file) return;
              
              if (!confirm(\`📄 파일: \${file.name}\\n크기: \${(file.size / 1024 / 1024).toFixed(2)}MB\\n\\nCSV 데이터를 임포트하시겠습니까?\\n(진행 상황이 표시됩니다)\`)) return;
              
              const btn = document.getElementById('importCsvBtn');
              btn.disabled = true;
              btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>파일 읽는 중...';
              
              try {
                // 파일 읽기
                const text = await file.text();
                btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>데이터 파싱 중...';
                
                // CSV 파싱
                const lines = text.split('\\n').filter(line => line.trim());
                const facilities = [];
                
                for (let i = 1; i < lines.length; i++) {
                  const cols = parseCSVLine(lines[i]);
                  if (cols.length < 9) continue;
                  
                  const facilityType = cols[0] || cols[1];
                  const name = cols[1] || cols[2];
                  const postalCode = cols[2] || cols[3];
                  const address = cols[3] || cols[4];
                  const phone = cols[4] || cols[5] || '';
                  const lat = cols[5] || cols[6];
                  const lng = cols[6] || cols[7];
                  const sido = cols[7] || cols[8];
                  const sigungu = cols[8] || cols[9];
                  
                  const latitude = parseFloat(lat);
                  const longitude = parseFloat(lng);
                  
                  if (!name || !address || !sido || !sigungu) continue;
                  
                  facilities.push({
                    facility_type: String(facilityType).replace(/^"|"$/g, '').trim(),
                    name: String(name).replace(/^"|"$/g, '').trim(),
                    postal_code: String(postalCode).replace(/^"|"$/g, '').trim(),
                    address: String(address).replace(/^"|"$/g, '').trim(),
                    phone: String(phone).replace(/^"|"$/g, '').trim(),
                    latitude: isNaN(latitude) ? 0 : latitude,
                    longitude: isNaN(longitude) ? 0 : longitude,
                    sido: String(sido).replace(/^"|"$/g, '').trim(),
                    sigungu: String(sigungu).replace(/^"|"$/g, '').trim()
                  });
                }
                
                if (facilities.length === 0) {
                  alert('❌ 유효한 시설 데이터가 없습니다.');
                  return;
                }
                
                btn.innerHTML = \`<i class="fas fa-upload mr-2"></i>0 / \${facilities.length} 업로드 중...\`;
                
                // 배치 업로드 (100개씩)
                const BATCH_SIZE = 100;
                let successCount = 0;
                let errorCount = 0;
                
                for (let i = 0; i < facilities.length; i += BATCH_SIZE) {
                  const batch = facilities.slice(i, i + BATCH_SIZE);
                  
                  try {
                    const response = await axios.post('/api/admin/import-csv', { facilities: batch });
                    
                    if (response.data.success) {
                      successCount += response.data.successCount || batch.length;
                      errorCount += response.data.errorCount || 0;
                    } else {
                      errorCount += batch.length;
                    }
                  } catch (error) {
                    console.error('Batch upload error:', error);
                    errorCount += batch.length;
                  }
                  
                  // 진행 상황 업데이트
                  const progress = Math.min(i + batch.length, facilities.length);
                  const percentage = Math.round((progress / facilities.length) * 100);
                  btn.innerHTML = \`<i class="fas fa-upload mr-2"></i>\${progress} / \${facilities.length} (\${percentage}%)\`;
                }
                
                alert(\`✅ 임포트 완료!\\n\\n성공: \${successCount.toLocaleString()}개\\n실패: \${errorCount.toLocaleString()}개\\n전체: \${facilities.length.toLocaleString()}개\`);
                loadFacilities(1);
                
              } catch (error) {
                console.error('Import CSV error:', error);
                alert('❌ CSV 임포트 중 오류가 발생했습니다.');
              } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-file-upload mr-2"></i>CSV 임포트';
              }
            };
            
            fileInput.click();
          });

          // 요양병원 교체 (엑셀 파일 업로드)
          // 로그아웃
          document.getElementById('logoutBtn').addEventListener('click', async function() {
            try {
              await axios.post('/api/admin/logout');
              window.location.href = '/admin';
            } catch (error) {
              window.location.href = '/admin';
            }
          });
        }

        // CSV 파싱 함수
        function parseCSVLine(line) {
          const result = [];
          let current = '';
          let inQuotes = false;
          
          for (let i = 0; i < line.length; i++) {
            const char = line[i];
            
            if (char === '"') {
              inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
              result.push(current.trim());
              current = '';
            } else {
              current += char;
            }
          }
          
          result.push(current.trim());
          return result;
        }

        // 시설 편집
        async function editFacility(id) {
          try {
            const response = await axios.get(\`/api/admin/facilities/\${id}\`);
            const facility = response.data.facility;
            
            editingFacilityId = id;
            document.getElementById('modalTitle').textContent = '시설 수정';
            
            document.getElementById('facilityId').value = facility.id;
            document.getElementById('facilityType').value = facility.facility_type;
            document.getElementById('facilityName').value = facility.name;
            document.getElementById('facilityPhone').value = facility.phone || '';
            document.getElementById('facilityPostalCode').value = facility.postal_code || '';
            document.getElementById('facilityAddress').value = facility.address;
            document.getElementById('facilitySido').value = facility.sido;
            
            // 시군구 로드
            const sigunguSelect = document.getElementById('facilitySigungu');
            sigunguSelect.innerHTML = '<option value="">선택하세요</option>';
            if (regionData[facility.sido]) {
              regionData[facility.sido].forEach(sigungu => {
                sigunguSelect.add(new Option(sigungu, sigungu));
              });
            }
            sigunguSelect.value = facility.sigungu;
            
            document.getElementById('facilityLatitude').value = facility.latitude;
            document.getElementById('facilityLongitude').value = facility.longitude;
            
            document.getElementById('facilityModal').classList.remove('hidden');
          } catch (error) {
            console.error('Load facility error:', error);
            alert('시설 정보를 불러오는 중 오류가 발생했습니다.');
          }
        }

        // 시설 삭제
        async function deleteFacility(id, name) {
          if (!confirm(\`"\${name}" 시설을 삭제하시겠습니까?\`)) return;
          
          try {
            await axios.delete(\`/api/admin/facilities/\${id}\`);
            alert('시설이 삭제되었습니다.');
            loadFacilities(currentPage);
          } catch (error) {
            console.error('Delete facility error:', error);
            alert('시설 삭제 중 오류가 발생했습니다.');
          }
        }
        `}})]})):e.redirect("/admin"));T.post("/api/partner",async e=>{try{const{DB:r}=e.env,i=await e.req.json(),s="partner_"+Date.now()+"_"+Math.random().toString(36).substring(2),a=new Date().toISOString(),n=i.facilitySido&&i.facilitySigungu?`${i.facilitySido}_${i.facilitySigungu}`:"";return await r.prepare(`
      INSERT INTO partners (
        id, facility_name, facility_type, facility_sido, facility_sigungu, 
        facility_address, manager_name, manager_phone, region_key, 
        is_regional_center, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(s,i.facilityName,i.facilityType,i.facilitySido||null,i.facilitySigungu||null,i.facilityAddress||null,i.managerName,i.managerPhone,n,0,a).run(),e.json({success:!0,message:"파트너 등록이 완료되었습니다!"})}catch(r){return console.error("Partner registration error:",r),e.json({success:!1,message:"등록 실패"},500)}});T.post("/api/family-care",async e=>{try{const{DB:r}=e.env,i=await e.req.json(),s="family_"+Date.now()+"_"+Math.random().toString(36).substring(2),a=new Date().toISOString();return await r.prepare(`
      INSERT INTO family_care (
        id, guardian_name, guardian_phone, patient_name, patient_age, 
        region, requirements, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(s,i.guardianName,i.guardianPhone,i.patientName,parseInt(i.patientAge),i.region,i.requirements||null,a).run(),e.json({success:!0,message:"가족 간병 신청이 완료되었습니다!"})}catch(r){return console.error("Family care registration error:",r),e.json({success:!1,message:"신청 실패"},500)}});T.post("/api/admin/login",async e=>{try{const{DB:r}=e.env,{password:i}=await e.req.json();try{await r.prepare(`
        CREATE TABLE IF NOT EXISTS admin_sessions (
          session_id TEXT PRIMARY KEY,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          expires_at DATETIME NOT NULL
        )
      `).run()}catch{console.log("Table creation skipped or already exists")}if(i===e.env.ADMIN_PASSWORD){const s=Cs(),a=new Date().toISOString(),n=new Date(Date.now()+3600*1e3).toISOString();return await r.prepare(`
        INSERT INTO admin_sessions (session_id, created_at, expires_at)
        VALUES (?, ?, ?)
      `).bind(s,a,n).run(),Xr(e,rt.sessionKey,s,{httpOnly:!0,maxAge:3600}),e.json({success:!0})}return e.json({success:!1,message:"비밀번호가 올바르지 않습니다."},401)}catch(r){return console.error("Admin login error:",r),e.json({success:!1,message:"로그인 실패"},500)}});T.post("/api/admin/logout",async e=>{try{const{DB:r}=e.env,i=Hr(e,rt.sessionKey);return i&&await r.prepare("DELETE FROM admin_sessions WHERE session_id = ?").bind(i).run(),Xr(e,rt.sessionKey,"",{maxAge:0}),e.json({success:!0})}catch(r){return console.error("Admin logout error:",r),e.json({success:!0})}});T.get("/api/admin/data",async e=>{if(!await M(e))return e.json({error:"Unauthorized"},401);try{const{DB:r}=e.env,i=await r.prepare("SELECT * FROM partners ORDER BY created_at DESC").all(),s=await r.prepare("SELECT * FROM family_care ORDER BY created_at DESC").all(),a=await r.prepare("SELECT * FROM regional_centers ORDER BY created_at DESC").all(),n=i.results.map(l=>({id:l.id,facilityName:l.facility_name,facilityType:l.facility_type,facilitySido:l.facility_sido,facilitySigungu:l.facility_sigungu,facilityAddress:l.facility_address,managerName:l.manager_name,managerPhone:l.manager_phone,regionKey:l.region_key,isRegionalCenter:l.is_regional_center===1,createdAt:l.created_at})),o=s.results.map(l=>({id:l.id,guardianName:l.guardian_name,guardianPhone:l.guardian_phone,patientName:l.patient_name,patientAge:l.patient_age,region:l.region,requirements:l.requirements,createdAt:l.created_at})),c={};return a.results.forEach(l=>{c[l.region_key]||(c[l.region_key]=[]),c[l.region_key].push({id:l.partner_id,facilityName:l.facility_name,facilityType:l.facility_type,managerName:l.manager_name,managerPhone:l.manager_phone})}),e.json({partners:n,familyCare:o,regionalCenters:c})}catch(r){return console.error("Admin data fetch error:",r),e.json({error:"Data fetch failed"},500)}});T.post("/api/admin/set-region",async e=>{if(!await M(e))return e.json({error:"Unauthorized"},401);try{const{DB:r}=e.env,{partnerIndex:i,regionKey:s}=await e.req.json(),a=await r.prepare("SELECT id FROM partners ORDER BY created_at DESC").all();if(i>=0&&i<a.results.length){const n=a.results[i].id;return await r.prepare("UPDATE partners SET region_key = ?, updated_at = ? WHERE id = ?").bind(s,new Date().toISOString(),n).run(),e.json({success:!0})}return e.json({success:!1,message:"파트너를 찾을 수 없습니다."},404)}catch(r){return console.error("Set region error:",r),e.json({success:!1,message:"설정 실패"},500)}});T.post("/api/admin/toggle-regional-center",async e=>{if(!await M(e))return e.json({error:"Unauthorized"},401);try{const{DB:r}=e.env,{partnerIndex:i,isChecked:s}=await e.req.json(),a=await r.prepare("SELECT * FROM partners ORDER BY created_at DESC").all();if(i<0||i>=a.results.length)return e.json({success:!1,message:"파트너를 찾을 수 없습니다."},404);const n=a.results[i],o=n.region_key;if(s){if(!o)return e.json({success:!0,message:"먼저 지역을 설정해주세요."});const c=await r.prepare("SELECT COUNT(*) as count FROM regional_centers WHERE region_key = ?").bind(o).first();if(c&&c.count>=4)return e.json({success:!1,message:"해당 지역은 이미 4개의 대표 상담센터가 등록되어 있습니다. 다른 센터를 제거한 후 추가해주세요."});await r.prepare("SELECT id FROM regional_centers WHERE region_key = ? AND partner_id = ?").bind(o,n.id).first()||(await r.prepare(`
          INSERT INTO regional_centers (
            region_key, partner_id, facility_name, facility_type, 
            manager_name, manager_phone, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?)
        `).bind(o,n.id,n.facility_name,n.facility_type,n.manager_name,n.manager_phone,new Date().toISOString()).run(),await r.prepare("UPDATE partners SET is_regional_center = 1, updated_at = ? WHERE id = ?").bind(new Date().toISOString(),n.id).run())}else o&&(await r.prepare("DELETE FROM regional_centers WHERE region_key = ? AND partner_id = ?").bind(o,n.id).run(),await r.prepare("UPDATE partners SET is_regional_center = 0, updated_at = ? WHERE id = ?").bind(new Date().toISOString(),n.id).run());return e.json({success:!0})}catch(r){return console.error("Toggle regional center error:",r),e.json({success:!1,message:"설정 실패"},500)}});T.get("/api/regional-centers",async e=>{const r=e.req.query("region");if(!r)return e.json({centers:[]});try{const{DB:i}=e.env,a=(await i.prepare("SELECT * FROM regional_centers WHERE region_key = ? ORDER BY created_at ASC LIMIT 4").bind(r).all()).results.map(n=>({facilityName:n.facility_name,facilityType:n.facility_type,managerName:n.manager_name,managerPhone:n.manager_phone}));return e.json({centers:a})}catch(i){return console.error("Regional centers fetch error:",i),e.json({centers:[]})}});T.post("/api/admin/init-db",async e=>{try{const{DB:r}=e.env;return console.log("🔧 데이터베이스 초기화 시작..."),await r.prepare(`
      CREATE TABLE IF NOT EXISTS admin_sessions (
        session_id TEXT PRIMARY KEY,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        expires_at DATETIME NOT NULL
      )
    `).run(),console.log("✅ admin_sessions 테이블 생성"),await r.prepare(`
      CREATE TABLE IF NOT EXISTS partners (
        id TEXT PRIMARY KEY,
        facility_name TEXT NOT NULL,
        facility_type TEXT NOT NULL,
        facility_sido TEXT,
        facility_sigungu TEXT,
        facility_address TEXT,
        manager_name TEXT NOT NULL,
        manager_phone TEXT NOT NULL,
        region_key TEXT,
        is_regional_center INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `).run(),console.log("✅ partners 테이블 생성"),await r.prepare(`
      CREATE TABLE IF NOT EXISTS family_care (
        id TEXT PRIMARY KEY,
        guardian_name TEXT NOT NULL,
        guardian_phone TEXT NOT NULL,
        patient_name TEXT NOT NULL,
        patient_age INTEGER,
        region TEXT,
        requirements TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `).run(),console.log("✅ family_care 테이블 생성"),await r.prepare(`
      CREATE TABLE IF NOT EXISTS regional_centers (
        id TEXT PRIMARY KEY,
        region_key TEXT NOT NULL,
        partner_id TEXT NOT NULL,
        facility_name TEXT NOT NULL,
        facility_type TEXT NOT NULL,
        manager_name TEXT NOT NULL,
        manager_phone TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `).run(),console.log("✅ regional_centers 테이블 생성"),await r.prepare(`
      CREATE TABLE IF NOT EXISTS facilities (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        facility_type TEXT NOT NULL,
        name TEXT NOT NULL,
        postal_code TEXT,
        address TEXT NOT NULL,
        phone TEXT,
        latitude REAL NOT NULL,
        longitude REAL NOT NULL,
        sido TEXT NOT NULL,
        sigungu TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `).run(),console.log("✅ facilities 테이블 생성"),await r.prepare("CREATE INDEX IF NOT EXISTS idx_facilities_sido ON facilities(sido)").run(),await r.prepare("CREATE INDEX IF NOT EXISTS idx_facilities_sigungu ON facilities(sigungu)").run(),await r.prepare("CREATE INDEX IF NOT EXISTS idx_facilities_type ON facilities(facility_type)").run(),await r.prepare("CREATE INDEX IF NOT EXISTS idx_partners_region ON partners(region_key)").run(),await r.prepare("CREATE INDEX IF NOT EXISTS idx_regional_centers_region ON regional_centers(region_key)").run(),console.log("✅ 인덱스 생성 완료"),console.log("🎉 데이터베이스 초기화 완료!"),e.json({success:!0,message:"데이터베이스 초기화 완료 (5개 테이블 생성)",tables:["admin_sessions","partners","family_care","regional_centers","facilities"]})}catch(r){return console.error("❌ 데이터베이스 초기화 실패:",r),e.json({success:!1,error:r.message},500)}});T.post("/api/admin/import-csv",async e=>{try{const{facilities:r}=await e.req.json(),{DB:i}=e.env;if(!Array.isArray(r)||r.length===0)return e.json({success:!1,error:"유효한 시설 데이터가 없습니다"},400);console.log(`Starting import of ${r.length} facilities...`);let s=0,a=0;for(let n=0;n<r.length;n+=500){const o=r.slice(n,n+500),c=[];for(const l of o)try{c.push(i.prepare(`
              INSERT INTO facilities (facility_type, name, postal_code, address, phone, latitude, longitude, sido, sigungu)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            `).bind(l.facilityType,l.name,l.postalCode||"",l.address,l.phone||"",l.latitude,l.longitude,l.sido,l.sigungu))}catch(d){console.error("Prepare error:",d),a++}try{await i.batch(c),s+=c.length,console.log(`Batch ${Math.floor(n/500)+1}: Imported ${c.length} facilities (Total: ${s})`)}catch(l){console.error("Batch import error:",l),a+=c.length}}return console.log(`Import completed: ${s} success, ${a} failed`),e.json({success:!0,imported:s,failed:a,total:r.length})}catch(r){return console.error("Import CSV error:",r),e.json({success:!1,error:r.message},500)}});T.get("/api/admin/facilities",async e=>{try{const{DB:r}=e.env,i=parseInt(e.req.query("page")||"1"),s=parseInt(e.req.query("limit")||"50"),a=e.req.query("search")||"",n=e.req.query("sido")||"",o=e.req.query("sigungu")||"",c=e.req.query("type")||"",l=(i-1)*s;let d="1=1";const u=[];a&&(d+=" AND (name LIKE ? OR address LIKE ?)",u.push(`%${a}%`,`%${a}%`)),n&&(d+=" AND sido = ?",u.push(n)),o&&(d+=" AND sigungu = ?",u.push(o)),c&&(d+=" AND facility_type = ?",u.push(c));const g=await r.prepare(`SELECT COUNT(*) as total FROM facilities WHERE ${d}`).bind(...u).first(),p=await r.prepare(`SELECT * FROM facilities WHERE ${d} ORDER BY id DESC LIMIT ? OFFSET ?`).bind(...u,s,l).all();return e.json({success:!0,facilities:p.results,total:(g==null?void 0:g.total)||0,page:i,limit:s,totalPages:Math.ceil(((g==null?void 0:g.total)||0)/s)})}catch(r){return e.json({success:!1,error:r.message},500)}});T.get("/api/admin/facilities/:id",async e=>{try{const{DB:r}=e.env,i=e.req.param("id"),s=await r.prepare("SELECT * FROM facilities WHERE id = ?").bind(i).first();return s?e.json({success:!0,facility:s}):e.json({success:!1,error:"시설을 찾을 수 없습니다"},404)}catch(r){return e.json({success:!1,error:r.message},500)}});T.put("/api/admin/facilities/:id",async e=>{try{const{DB:r}=e.env,i=e.req.param("id"),s=await e.req.json();return await r.prepare(`
      UPDATE facilities SET
        facility_type = ?,
        name = ?,
        postal_code = ?,
        address = ?,
        phone = ?,
        latitude = ?,
        longitude = ?,
        sido = ?,
        sigungu = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(s.facility_type,s.name,s.postal_code||"",s.address,s.phone||"",s.latitude,s.longitude,s.sido,s.sigungu,i).run(),e.json({success:!0,message:"시설 정보가 수정되었습니다"})}catch(r){return e.json({success:!1,error:r.message},500)}});T.delete("/api/admin/facilities/:id",async e=>{try{const{DB:r}=e.env,i=e.req.param("id");return await r.prepare("DELETE FROM facilities WHERE id = ?").bind(i).run(),e.json({success:!0,message:"시설이 삭제되었습니다"})}catch(r){return e.json({success:!1,error:r.message},500)}});T.post("/api/admin/upload-facilities",async e=>{try{const{facilities:r}=await e.req.json(),{DB:i}=e.env;if(!Array.isArray(r)||r.length===0)return e.json({success:!1,error:"유효한 시설 데이터가 없습니다"},400);console.log(`📤 엑셀 업로드 시작: ${r.length}개`);let s=0,a=0,n=0;for(let o=0;o<r.length;o+=500){const c=r.slice(o,o+500);for(const l of c)try{l.id?(await i.prepare(`
              UPDATE facilities 
              SET facility_type = ?, name = ?, postal_code = ?, address = ?, phone = ?, 
                  latitude = ?, longitude = ?, sido = ?, sigungu = ?, notes = ?,
                  updated_at = CURRENT_TIMESTAMP
              WHERE id = ?
            `).bind(l.facility_type,l.name,l.postal_code||"",l.address,l.phone||"",l.latitude||0,l.longitude||0,l.sido,l.sigungu,l.notes||"",l.id).run()).meta.changes>0?s++:(await i.prepare(`
                INSERT INTO facilities (facility_type, name, postal_code, address, phone, latitude, longitude, sido, sigungu, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
              `).bind(l.facility_type,l.name,l.postal_code||"",l.address,l.phone||"",l.latitude||0,l.longitude||0,l.sido,l.sigungu,l.notes||"").run(),a++):(await i.prepare(`
              INSERT INTO facilities (facility_type, name, postal_code, address, phone, latitude, longitude, sido, sigungu, notes)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `).bind(l.facility_type,l.name,l.postal_code||"",l.address,l.phone||"",l.latitude||0,l.longitude||0,l.sido,l.sigungu,l.notes||"").run(),a++)}catch(d){console.error("Facility update/insert error:",d),n++}console.log(`📦 Batch ${Math.floor(o/500)+1}: 업데이트=${s}, 신규=${a}, 실패=${n}`)}return console.log(`✅ 업로드 완료: 업데이트=${s}, 신규=${a}, 실패=${n}`),e.json({success:!0,updated:s,inserted:a,failed:n,total:r.length})}catch(r){return console.error("Upload facilities error:",r),e.json({success:!1,error:r.message},500)}});T.post("/api/admin/replace-hospitals",async e=>{try{const{hospitals:r}=await e.req.json(),{DB:i}=e.env;if(!Array.isArray(r)||r.length===0)return e.json({success:!1,error:"유효한 병원 데이터가 없습니다"},400);console.log(`🏥 요양병원 데이터 교체 시작: ${r.length}개`);const s=await i.prepare("DELETE FROM facilities WHERE facility_type = '요양병원'").run();console.log(`✅ 기존 요양병원 삭제 완료: ${s.meta.changes}개`);let a=0,n=0;for(let o=0;o<r.length;o+=500){const c=r.slice(o,o+500),l=[];for(const d of c)try{l.push(i.prepare(`
              INSERT INTO facilities (facility_type, name, postal_code, address, phone, latitude, longitude, sido, sigungu, notes)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `).bind("요양병원",d.name,"",d.address,d.phone||"",0,0,d.sido,d.sigungu,d.notes||""))}catch(u){console.error("Prepare error:",u),n++}try{await i.batch(l),a+=l.length,console.log(`📦 Batch ${Math.floor(o/500)+1}: ${l.length}개 삽입 (총: ${a}개)`)}catch(d){console.error("Batch import error:",d),n+=l.length}}return console.log(`🎉 교체 완료: ${a}개 성공, ${n}개 실패`),e.json({success:!0,deleted:s.meta.changes,imported:a,failed:n,total:r.length})}catch(r){return console.error("Replace hospitals error:",r),e.json({success:!1,error:r.message},500)}});T.post("/api/admin/facilities",async e=>{try{const{DB:r}=e.env,i=await e.req.json(),s=await r.prepare(`
      INSERT INTO facilities (facility_type, name, postal_code, address, phone, latitude, longitude, sido, sigungu)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(i.facility_type,i.name,i.postal_code||"",i.address,i.phone||"",i.latitude,i.longitude,i.sido,i.sigungu).run();return e.json({success:!0,id:s.meta.last_row_id,message:"시설이 추가되었습니다"})}catch(r){return e.json({success:!1,error:r.message},500)}});T.get("/api/facilities-from-db",async e=>{try{const{DB:r}=e.env,i=e.req.query("sido")||"",s=e.req.query("sigungu")||"",a=e.req.query("type")||"",n=e.req.query("keyword")||"";let o="1=1";const c=[];i&&(o+=" AND sido = ?",c.push(i)),s&&(o+=" AND sigungu = ?",c.push(s)),a&&(o+=" AND facility_type = ?",c.push(a)),n&&(o+=" AND name LIKE ?",c.push(`%${n}%`));const l=await r.prepare(`SELECT * FROM facilities WHERE ${o}`).bind(...c).all();return e.json({success:!0,facilities:l.results})}catch(r){return console.error("DB query error:",r),e.json({success:!1,error:r.message},500)}});T.get("/api/admin/facilities",async e=>{if(!await M(e))return e.json({error:"Unauthorized"},401);try{const{DB:r}=e.env,i=parseInt(e.req.query("page")||"1"),s=parseInt(e.req.query("limit")||"50"),a=e.req.query("search")||"",n=e.req.query("sido")||"",o=e.req.query("sigungu")||"",c=e.req.query("type")||"";let l="1=1";const d=[];a&&(l+=" AND (name LIKE ? OR address LIKE ?)",d.push(`%${a}%`,`%${a}%`)),n&&(l+=" AND sido = ?",d.push(n)),o&&(l+=" AND sigungu = ?",d.push(o)),c&&(l+=" AND facility_type = ?",d.push(c));const u=await r.prepare(`SELECT COUNT(*) as total FROM facilities WHERE ${l}`).bind(...d).first(),g=(u==null?void 0:u.total)||0,p=Math.ceil(g/s),m=(i-1)*s,y=await r.prepare(`SELECT * FROM facilities WHERE ${l} ORDER BY id DESC LIMIT ? OFFSET ?`).bind(...d,s,m).all();return e.json({facilities:y.results,total:g,page:i,totalPages:p,limit:s})}catch(r){return console.error("Facilities fetch error:",r),e.json({error:r.message},500)}});T.post("/api/admin/init-db",async e=>{if(!await M(e))return e.json({error:"Unauthorized"},401);try{const{DB:r}=e.env;return await r.prepare("DELETE FROM facilities").run(),e.json({success:!0,message:"모든 시설 정보가 삭제되었습니다."})}catch(r){return console.error("DB init error:",r),e.json({success:!1,message:"초기화 실패: "+r.message},500)}});T.post("/api/admin/import-csv",async e=>{if(!await M(e))return e.json({error:"Unauthorized"},401);try{const{DB:r}=e.env,{facilities:i}=await e.req.json();if(!i||!Array.isArray(i))return e.json({success:!1,message:"잘못된 데이터 형식입니다."},400);const s=100;let a=0,n=0;for(let o=0;o<i.length;o+=s){const c=i.slice(o,o+s);try{const l=c.map(d=>`('${d.facility_type.replace(/'/g,"''")}', '${d.name.replace(/'/g,"''")}', '${d.postal_code||""}', '${d.address.replace(/'/g,"''")}', '${d.phone||""}', ${d.latitude||0}, ${d.longitude||0}, '${d.sido.replace(/'/g,"''")}', '${d.sigungu.replace(/'/g,"''")}')`).join(", ");await r.prepare(`
          INSERT INTO facilities (facility_type, name, postal_code, address, phone, latitude, longitude, sido, sigungu)
          VALUES ${l}
        `).run(),a+=c.length}catch(l){console.error("Batch error:",l),n+=c.length}}return e.json({success:!0,message:`임포트 완료: 성공 ${a}개, 실패 ${n}개`,successCount:a,errorCount:n})}catch(r){return console.error("CSV import error:",r),e.json({success:!1,message:"임포트 실패: "+r.message},500)}});T.post("/api/admin/facility",async e=>{if(!await M(e))return e.json({error:"Unauthorized"},401);try{const{DB:r}=e.env,i=await e.req.json();return await r.prepare(`
      INSERT INTO facilities (facility_type, name, postal_code, address, phone, latitude, longitude, sido, sigungu, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(i.facility_type,i.name,i.postal_code||"",i.address,i.phone||"",i.latitude,i.longitude,i.sido,i.sigungu,new Date().toISOString(),new Date().toISOString()).run(),e.json({success:!0,message:"시설이 추가되었습니다."})}catch(r){return console.error("Facility add error:",r),e.json({success:!1,message:"추가 실패: "+r.message},500)}});T.put("/api/admin/facility/:id",async e=>{if(!await M(e))return e.json({error:"Unauthorized"},401);try{const{DB:r}=e.env,i=e.req.param("id"),s=await e.req.json();return await r.prepare(`
      UPDATE facilities 
      SET facility_type = ?, name = ?, postal_code = ?, address = ?, phone = ?, 
          latitude = ?, longitude = ?, sido = ?, sigungu = ?, updated_at = ?
      WHERE id = ?
    `).bind(s.facility_type,s.name,s.postal_code||"",s.address,s.phone||"",s.latitude,s.longitude,s.sido,s.sigungu,new Date().toISOString(),i).run(),e.json({success:!0,message:"시설 정보가 수정되었습니다."})}catch(r){return console.error("Facility update error:",r),e.json({success:!1,message:"수정 실패: "+r.message},500)}});T.delete("/api/admin/facility/:id",async e=>{if(!await M(e))return e.json({error:"Unauthorized"},401);try{const{DB:r}=e.env,i=e.req.param("id");return await r.prepare("DELETE FROM facilities WHERE id = ?").bind(i).run(),e.json({success:!0,message:"시설이 삭제되었습니다."})}catch(r){return console.error("Facility delete error:",r),e.json({success:!1,message:"삭제 실패: "+r.message},500)}});T.get("/api/admin/facility/:id",async e=>{if(!await M(e))return e.json({error:"Unauthorized"},401);try{const{DB:r}=e.env,i=e.req.param("id"),s=await r.prepare("SELECT * FROM facilities WHERE id = ?").bind(i).first();return s?e.json({facility:s}):e.json({error:"시설을 찾을 수 없습니다."},404)}catch(r){return console.error("Facility fetch error:",r),e.json({error:r.message},500)}});const Gt=new jr,Rs=Object.assign({"/src/index.tsx":T});let Kr=!1;for(const[,e]of Object.entries(Rs))e&&(Gt.all("*",r=>{let i;try{i=r.executionCtx}catch{}return e.fetch(r.req.raw,r.env,i)}),Gt.notFound(r=>{let i;try{i=r.executionCtx}catch{}return e.fetch(r.req.raw,r.env,i)}),Kr=!0);if(!Kr)throw new Error("Can't import modules from ['/src/index.ts','/src/index.tsx','/app/server.ts']");export{Gt as default};
